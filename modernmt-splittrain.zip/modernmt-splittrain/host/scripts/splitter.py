import re
import os
import sys
import glob
import json
import argparse
import shutil
from tqdm import tqdm
from pathlib import Path
from collections import defaultdict
import random
import numpy as np

class Splitter:
    def __write__(self, lines, subdir, name):
        p = Path(f'{self.dest}/{subdir}')
        p.mkdir(parents=True, exist_ok=True)
        with open(os.path.join(p, name), 'w') as f:
            for line in lines:
                f.write(line + os.linesep)
    def __split__(self, srctgt):
        exts    = [*srctgt.keys()]
        lens    = [len(srctgt[ext]) for ext in exts]
        assert np.mean(lens) == lens[0], f'lengths do not match for {exts} {lens}'
        ids     = [*range(lens[0])]
        random.shuffle(ids) # it is important to shuffle ids before train-test split so that tests include samples from all datasets
        ids_tests = ids[-self.tests:]
        ids_train = ids[:-self.tests]
        ids_train = np.array(ids_train)
        ids_train = np.array_split(ids_train, 2**int(self.split))
        self.datagen_folders = [
            f'{self.dest}/train/{subdir}'
            for subdir in range(len(ids_train))
        ] 
        self.tests_folder = f'{self.dest}/tests'
        with tqdm(desc=f"writing") as tkdm:
            for idx, ids_train_section in enumerate(ids_train):
                size = 0
                for ext in exts:
                    lines = [
                        srctgt[ext][tid]
                        for tid in ids_train_section
                    ]
                    size += sum([len(line) for line in lines])
                    self.__write__(lines, f'train/{idx}', f'{idx}.{ext}')
                tkdm.set_postfix({'idx': idx, 'size (mb)': np.round(size*1e-6, 2)})
                tkdm.update(1)
        for ext in exts:
            lines = [
                srctgt[ext][idx]
                for idx in ids_tests
            ]
            self.__write__(lines, 'tests', f'test.{ext}')
    def __init__(self, root, split=0, tests=100):
        self.split = split
        self.tests = tests
        self.dest  = os.path.join(os.path.dirname(root), 'split')
        shutil.rmtree(self.dest, ignore_errors=True)
        files  = defaultdict(dict)
        for path in glob.glob(f'{root}/*.*'):
            if os.path.isdir(path):
                continue
            name = path.split("/")[-1].split('.')
            title = ".".join(name[:-1])
            extension = name[-1]
            files[title][extension] = ".".join(name)
        srctgt = defaultdict(list)
        with tqdm(desc=f"reading") as tkdm:
            for title, pair in files.items():
                for extension, filename in pair.items():
                    with open(f'{root}/{filename}', "r") as f:
                        lines = f.readlines()
                        temps = []
                        carry = ""
                        for line in lines:
                            if (
                                (line.startswith("\"") and not line.endswith("\""))
                                or (
                                    line.endswith(":")
                                    or line.endswith(",")
                                    or line.startswith("-")
                                )
                            ): # AssertionError: lengths do not match for ['pl', 'uk'] [2574498, 2607803]
                                carry += line.strip()
                            else:
                                temps += [carry]
                                carry  = "" + line
                        temps += [carry]
                        srctgt[extension] += temps
                    tkdm.set_postfix({'filename': filename})
                    tkdm.update(1)
        self.__split__(srctgt)
        

if __name__ == '__main__':
    argparser = argparse.ArgumentParser()
    argparser.add_argument(
        "--root", 
        required=True, 
        help="root of the data that contains src, tgt language files"
    )
    argparser.add_argument(
        "--split", 
        required=False,
        type=int,
        default=1,
        help="the exponent using which to split the dataset, i.e. split=2 splits the database into 2**2=4 sections"
    )
    argparser.add_argument(
        "--tests", 
        required=False, 
        type=int,
        default=100,
        help="the number of lines for testing"
    )
    args = argparser.parse_args()
    splitter = Splitter(args.root, args.split, args.tests)