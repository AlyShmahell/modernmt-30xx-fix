import re
import os
import sys
import glob
import json
import argparse
import shutil
import time
from tqdm import tqdm
from pathlib import Path
from collections import defaultdict
import random
from subprocess import PIPE, STDOUT, Popen

class colors:
    red = '\033[91m'
    blu = '\033[94m'
    end = '\033[0m'
    @staticmethod
    def command(string):
        print(colors.red + string + colors.end)
    @staticmethod
    def question(string):
        return colors.blu + string + colors.end

oneliner = lambda x: re.sub(r'\s+', ' ', x.replace("\n", " ")).strip()

class System:
    def __init__(self, path, logname):
        self.path = os.path.join(path, logname)
    def __call__(self, cmd):
        output  = ""
        with Popen(cmd, stdout=PIPE, stderr=STDOUT, shell=True, text=True) as proc:
            output = proc.stdout.read()
        with open(self.path, "a") as f:
            f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} ')
            f.write(output)
            f.write("\n")
        print(output)

class Execute:
    def __init__(self, path, logname):
        self.path = os.path.join(path, logname)
    def __call__(self, y, cmd="", exe=os.system):
        print(flush=True)
        colors.command(f'{time.strftime("%Y-%m-%d %H:%M:%S")} {cmd}')
        with open(self.path, "a") as f:
            f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} ')
            f.write(cmd)
            f.write("\n")
        if y:
            with open(self.path, "a") as f:
                f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} ')
                f.write("y")
                f.write("\n")
            print(flush=True)
            exe(cmd)
            return
        while True:
            ans = input(colors.question(f'{time.strftime("%Y-%m-%d %H:%M:%S")} Do you want to execute the above command? [y/n]: '))
            print(flush=True)
            with open(self.path, "a") as f:
                f.write(f'{time.strftime("%Y-%m-%d %H:%M:%S")} ')
                f.write(ans)
                f.write("\n")
            if ans == 'y':
                exe(cmd)
                return
            if ans == 'n':
                return

def main():
    argparser = argparse.ArgumentParser()

    argparser.add_argument(
        "--datadir", 
        required=True, 
        help="directory of the data that contains src, tgt language files"
    )
    argparser.add_argument(
        "--saveto", 
        required=True, 
        help="path to the folder where you want to save the engine"
    )
    argparser.add_argument(
        "--language_pair", 
        required=True, 
        help="language pair separated by `:` only, no spaces"
    )
    argparser.add_argument(
        "--model_name", 
        required=True, 
        help="model name"
    )
    argparser.add_argument(
        "--train_steps", 
        required=False, 
        type=int,
        default=100,
        help="the number of training steps"
    )
    argparser.add_argument(
        "--unifiedmemory", 
        required=False, 
        action='store_true',
        default = False,
        help="use unified memory for all corpora (instead of separate memory for each)"
    )
    argparser.add_argument(
        "-y", 
        required=False, 
        action='store_true',
        default = False,
        help="do not ask if I want to continue"
    )
    # Preprocess Arguments
    args      = argparser.parse_args()
    src, tgt  = args.language_pair.split(":")
    logname   = f'log_{time.strftime("%Y-%m-%d_%H-%M-%S")}.txt'
    system    = System(args.saveto, logname)
    execute   = Execute(args.saveto, logname)
    execute(args.y, "nvidia-smi", system)
    check_cmd = oneliner("""
    awk '$3=="kB"{$2=$2/1024/1024;$3="GB"} 1' /proc/meminfo | awk -vOFS='\t' '{ print $1, $2, $3 }' | grep MemAvailable && nvidia-smi | grep MiB
    """)
    execute(args.y, check_cmd, system)
    # Create & Train Engine
    train_cmd = oneliner(
        f"""
        ./mmt create {src} {tgt} {args.datadir}/train
        -e {args.model_name}  --train-steps {args.train_steps} 
        --no-test --delete
        """
    )
    execute(args.y, train_cmd, system)
    # Start Engine
    start_cmd = f"./mmt start -e {args.model_name}"
    execute(args.y, start_cmd, system)
    # Evaluate Egnine
    eval_cmds  = [
        f"./mmt evaluate -e {args.model_name} --path {path}"
        for path in glob.glob(f'{args.datadir}/tests/*')
        if os.path.isdir(path)
    ]
    for eval_cmd in eval_cmds:
        execute(args.y, eval_cmd, system)
    # List Memory Files
    memfiles  = defaultdict(dict)
    for path in glob.glob(f'{args.datadir}/memory/*.*'):
        if os.path.isdir(path):
            continue
        name = path.split("/")[-1].split('.')
        title = ".".join(name[:-1])
        extension = name[-1]
        memfiles[title][extension] = path
    # Import Memory Files
    uid = None
    if args.unifiedmemory:
        memory_cmd = oneliner(
            f"""
                 ./mmt memory create unified
                 -e {args.model_name}
             """
        )
        execute(args.y, memory_cmd, system)
        uid = os.popen(f"./mmt memory list -e {args.model_name} | grep unified | sed 's/[^0-9]*//g'").read().split('\n')[0]
        try:
            uid = int(uid)
        except:
            uid = None
        print(colors.question(f"uid: {uid}"))
    for idx, (title, pair) in enumerate(memfiles.items()):
        # import Memory
        memory_cmd = oneliner(
            f"""
                 ./mmt memory import -p 
                 {pair[src]} {pair[tgt]}
                 -e {args.model_name}
             """
        )
        if args.unifiedmemory and uid is not None:
            memory_cmd = f"{memory_cmd} --id {uid}"
        execute(args.y, memory_cmd, system)
        # Evaluate Engine
        for eval_cmd in eval_cmds:
            execute(args.y, eval_cmd, system)
    # List Memories
    memlist_cmd = f"./mmt memory list -e {args.model_name}"
    execute(args.y, memlist_cmd, system)
    # Stop Engine
    stop_cmd  = f"./mmt stop -e {args.model_name}"
    execute(args.y, stop_cmd, system)
    # Copy Engine to Host
    p = Path(f'{args.saveto}')
    p.mkdir(parents=True, exist_ok=True)
    delt_cmd  = f"rm -rf {args.saveto}/{args.model_name}"
    execute(args.y, delt_cmd, system)
    copy_cmd  = f"mv engines/{args.model_name} {args.saveto}"
    execute(args.y, copy_cmd, system)



if __name__ == '__main__':
    main()