Ciała Olgi i Oleksandra leżały w masowym grobie, Igora - w kanale.
Ciała kilku rozebranych kobiet owiniętych w koce znaleziono po obu stronach autostrady, 20 km od Kijowa.
Rosjanie próbowali je spalić.
Jeśli pójdę, w domu nikogo nie będzie.
Zamówiłem paczkę z Niemiec przez DHL.
Miała być dostarczona wczoraj, ale nikt się ze mną nie kontaktował i paczka nie została dostarczona. Strona DHL mówi, że nie można było odnaleźć odbiorcy.
W związku z tym paczka została wysłana na pocztę i wskazany został adres tego oddziału.
Jak mogę ją odebrać?
Jak byłam mała mogłam kilka razy dziennie chodzić nad rzekę, rzeka jest bardzo blisko domu, ale teraz rzadko tam chodzę, nie mam czasu, a czasem nawet nie chcę iść, chodzę tylko z moją siostrą) 🙂
Proszę, powiedz mi, czy to mieszkanie, które mi wysłałeś, jest przez kogoś wynajmowane, czy jak?
Zostałam poproszona o pójście ze znajomymi przyjaciela na wystawę, aby pomóc im w uzyskaniu wiz ochronnych.
Spędziłem tam prawie cały dzień. Zmęczyłem się trochę ludźmi.
To ładny dom i sami możemy go bardzo dobrze posprzątać.
Jak zrozumieć, czy w klubie są wolne miejsca, czy nie?
⚡️Rosja ogłosi niewypłacalność swojego zadłużenia zagranicznego - informuje CNN powołując się na agencję Standard & Poor's.
Dobry wieczór! Wyjeżdżam o 20:00, czy Ci to pasuje?
Ich szkoła dobrze zorganizowała nauczanie na odległość, codziennie od 7 do 12, więc może uczyć się z domu
Pasuje tylko połowa tego, ale nadal nie mogę zmieścić kolejnej suszarki.
Będę w stanie zapłacić 12 tysięcy miesięcznie, najlepiej już z rachunkami
Mam nadzieję, że nie będzie problemu. Dziękuję.
Czy mogę prosić o pomoc przy opłaceniu obiadów szkolnych dla mojej córki?
To jasne... Powinienem napisać to tutaj lub przynieść jutro na kartce
To powiedzenie jest na miejscu
Widzisz, mamy coś wspólnego, lubimy eksperymentować z jedzeniem
No, żeby chociaż mieć pracę i sklep
Dzień dobry, właśnie zaproponowano mi posadę dentysty w Pradze, więc bardzo dziękuję za troskę i przepraszam.
Jest bardzo nieostrożna i trochę nieodpowiedzialna.
Albo spóźnia się na przystanek, albo zostawia telefon, albo nie odbiera telefonu. I nie napisała do mnie, że jest w szkole i że wszystko jest w porządku, tak jak teraz.
I martwię się o nią, bo przecież nie ma jej w domu, tylko w innym, jeszcze nie do końca znajomym stanie
Mam nadzieję, że dobrze obliczyłem
Chyba nie myślałeś, że wciąż jestem dzieckiem
A praca jest oczywiście również ciekawa.
Jednak, jeśli nie jest to bardzo wymagające fizycznie, bo nie jestem w tak dobrej formie fizycznej
Mógłbym zapłacić za mieszkanie w umiarkowanej cenie, gdyby ktoś udostępnił mi pokój.
Jesteś bardzo komunikatywny, może kogoś poznasz
Dzień dobry, tak, jesteśmy bardzo zainteresowani pracą, ale nie mówimy po czesku
O której godzinie możemy włożyć rzeczy do prania?
Organizacja charytatywna Archidiecezjalna Caritas Olomouc chce zorganizować projekt, który zainteresuje Ukraińców mieszkających w Czechach, w mieście Ołomuniec.
Wyobraź sobie, że Rosjanie gwałcą kobiety, a ich dzieci są zmuszane do oglądania tego.
Potem mogą gwałcić, okaleczać ciała, a dzieci to wszystko widzą.
Dzień dobry, mówię do was w myślach - muszę się nauczyć czeskiego i nie mogę oderwać się od wiadomości.
Bardzo często komunikuję się z Wami w myślach. Wydaje mi się, że słyszysz moje myśli.
Prezydent Wołodymyr Zełenski stwierdził, że niektóre rodzaje broni dostarczone przez zachodnich partnerów dotarły za późno.
Powiedział to w wywiadzie dla Associated Press, którego fragmenty opublikowało Biuro Prezydenta, pisze "European Truth".
„Cały sprzęt, wszystko, co już wysłali, na niektóre rodzaje sprzętu jest już za późno. Bo kiedy mówimy na przykład o Mariupolu, gdzie tracisz tysiące ludzi, co dalej? Od przywódców niektórych krajów widzę 100 procent poparcia, to prawda. I niektórzy europejscy przywódcy zmienili swoje stanowisko, ale widać cenę tych zmian - powiedział Zełenski.
Zapytany, czy Ukraina otrzymała wystarczającą ilość broni, aby zmienić wojnę, prezydent odpowiedział: „Jeszcze nie, jeszcze nie”.
Prezydent powiedział też, że gdyby Ukraina była członkiem NATO, do tej wojny by nie doszło, albo przybrałaby inną formę.
„Potoczyłoby się to inaczej, mielibyśmy ramię bliskich sąsiadów, moglibyśmy razem walczyć. Ale jestem pewien, że wojny by jednak nie było” – dodał.
Wiadomo, że premier Wielkiej Brytanii obiecał Ukrainie nową pomoc wojskową, która obejmuje pojazdy opancerzone i broń przeciwokrętową.
Mam sen, że wojna się skończyła i mogę wrócić do domu
napisz do mnie o wszystkim, co będzie potrzebne, proszę
Chciałam was zapytać, może wiecie skąd wziął się blender w naszej kuchni?
Destrukcyjne działania w postaci rozpowszechniania kłamstw i dezinformacji mają na celu wywołanie paniki i dezorganizacji, które są wrażliwe dla bezpieczeństwa publicznego.
Jestem z Ukrainy, teraz jestem w Pilznie.
Przed wojną na Ukrainie pracowałam przez 20 lat jako projektant odzieży damskiej i dziecięcej z różnych materiałów, umiem też szyć na specjalistycznym sprzęcie i robić obróbkę cieplną na mokro.
Bardzo chcę pracować w swoim zawodzie, chętnie podzielę się swoją wiedzą i zdobędę nowe doświadczenie w tej dziedzinie.
Oczywiście to dobrze, że chcesz się spotkać. Tylko żartowałem
Tak, możesz to zrobić też w ten sposób.
Dziś przeczytałem, że sami muszą wejść do systemu.
Trzeba im o tym powiedzieć i zrobić to z nimi.
Świetnie, w takim razie napiszę jutro i ustalimy dokładny termin
Zrób mi zdjęcie przykładów, które rozwiązałeś, proszę
Czy to dobry deputowany?
Poszliśmy pod ten adres zapytać, czy nie potrzebujemy czegoś do szkoły, może zeszytów, ale nie dotarliśmy
A modlitwa matki jest najpotężniejsza.
Dużo słyszę - wojna toczy się na 10% terytorium Ukrainy.
Dlaczego ludzie uciekają?
Dlaczego nie mieszkają na terytorium, na którym nie ma wojny?
Czy postradałeś zmysły??
Żyłeś w stanie wojny?
Kiedy ceny wzrosły o 100-200%.
Kiedy większość przedsiębiorstw NIE PRACUJE.
Kiedy nie ma gdzie zarabiać.
Kiedy dzieci słyszą ogień artylerii przeciwlotniczej?
Czy żyłeś w ten sposób?
Nie masz pojęcia.
I nie daj Boże, żebyś miał.
Jeśli ty też się dowiesz - to będzie STRASZNE.
Właśnie dlatego uciekamy.
Niektórzy z nas są zdezorientowani telefonami… resztkami z naszego innego życia… tak, niektórzy nie przystosowali się w ciągu miesiąca.
I czy ty potrafiłbyś zaadaptować się od zera w miesiąc?
Tak, państwo daje nam 5000 koron.
Czy byłbyś w stanie żyć z tych funduszy?
Wiele fundacji daje żywność.
Czy próbowałeś dojechać metrem z dziećmi do fundacji?
Kiedy w jednej szukasz jedzenia, w drugiej ubrania, a nie ma wystarczająco czasu żeby iść do trzeciej.
A jutro znowu musisz iść... bo jedzenie, które ci dali wystarczy tylko na jeden dzień.
CHCESZ zarabiać na własną rękę… ale co zrobić z dziećmi?
Jak żyć bez znajomości języka?
Kiedy nawet nie możesz poprosić o pomoc.
Tak - są darmowe kursy… ale który wybrać?
Szukasz pracy, jedzenia, ubrań lub kursów?
W miesiąc mam więcej pytań niż odpowiedzi.
Ale moje dzieci nie mogą tu być.
Po prostu - zrozum nas.
Przychodzisz do ratusza, jeśli nie wskazano Ci numeru drzwi i drogi na dole w recepcji mówisz, że szukasz pani Krzkowskiej.
Będzie napisane na jego drzwiach, że to jest kierownik działu.
Jeśli nie możesz się zgodzić, zadzwoń do Dominique, ale wierzę, że wszystko pójdzie gładko.
Jeśli pani Krzhkovska jeszcze nie przyszła, poczekaj na nią chwilę, powiedziała, że ma wcześniej spotkanie, więc może trochę się spóźni, ale wie o tobie, zapisała cię dokładnie na 9:00 właśnie po to, żebyś trafiła do lekarza.
Tak, oczywiście, byłoby bardzo miło spędzić razem czas
Proszę, pociesz mnie miłym słowem, jesteś dla mnie jak ukojenie.....
jest łatwy w użyciu i nie drogi
Naprawdę potrzebuję internetu do pracy.
Jak mogę podłączyć internet?
Może ktoś już był zajęty, dlatego nie odpowiada
Dobry wieczór! Zapomnieliśmy napisać o tych kursach języka czeskiego!?
Ominęliśmy już pierwszy😉🙄
Trochę tego żałuję, bo naprawdę rozumiem, jak bardzo tego potrzebuję
Nigdy nie rozmawiałem o relacji, nigdy nie mówiłem ani nie spodziewałem się żadnej relacji.
Zuzana, lekarz dał nam te papiery. Pomóż mi zapisać, co jest potrzebne, proszę😅😊
OK, poczekam, idę spać, dobranoc 😘
Otacza Cię przyroda i pogodni sąsiedzi)
Znalazłem mieszkanie, ale nie ma w nim mebli i naczyń. Czy mógłbyś mi pomóc znaleźć używane meble? Dziękuję.
Pierwszego dnia choroby można przygotować dietę w czystych przyniesionych naczyniach (jedzenie).
W inne dni Państwowa Służba Produkcji i Konsumentów nie ma prawa do żywności dotowanej przez państwo.
Po zabraniu jedzenia do domu obsługa kuchni nie odpowiada za jakość i zdrowie.
Cześć. Martin, sprawdź czy lodówka działa. Proszę.
Z wielką przyjemnością się z nią spotkamy!
Naprawdę doceniam to wsparcie!
Anita wspomniała też dzisiaj o piątku, zaproponowała, że odwiedzi wasze centrum razem z Anną po jej szkole.
Nieoczekiwana znajomość z polskimi towarzyszami na początku działań wojennych przerodziła się w dobrą przyjaźń)
To bardzo fajne i miłe znaleźć bratnie dusze tam, gdzie się ich nie spodziewałeś lub nie szukałeś)
Bank wystąpi o pożyczkę w poniedziałek.
Przy okazji, jeśli chodzi o powrót.
Wczoraj powiedziałeś, że jesteś gotowy traktować mnie jako swojego partnera. Jako twój partner nie chcę zwrotu pieniędzy.
Co moje to i twoje.
I bardzo dobrze to wiesz.
Zawsze chętnie poznam nowych ludzi)
Bo tak naprawdę zawsze jestem niepewny swoich możliwości, a takich słów mi potrzeba!
W domu byliśmy o 15:00. Pojechaliśmy z Kristiną i jej rodziną na Zamek Wyszehradzki.
Jutro cały dzień będę pracować, do 12 we Fpoint, potem mam wykłady z angielskiego, a wieczorem muszę iść do sekretariatu szkoły językowej po klucze do biura.
Wybacz mi, proszę.
Błagam, czy możesz w czwartek?
Dziękuję, dzisiaj czuję się dużo lepiej🙏🏻
Poszedłem do sklepu z mamą i siostrą.
Wróciliśmy, ugotowaliśmy jedzenie, porozmawialiśmy.
I went out to the yard to get some fresh air, cleaned up a little in the yard, because being constantly in the house you can 🤪
Gdybym wiedział, poszedłbym z tobą
Sprawdziłem na mapie, to tylko 3 kilometry do nich.
Mógłbym iść pieszo, inaczej musiałbym jechać z Brna)))) Szukam dogodnej trasy
Tak będzie dobrez. Dziękuję. Jeśli USG coś pokaże, to zobaczymy.
Chętnie Cię odwiedzimy!
4. Jakie inne zajęcia poza nauką w szkole pomogłyby Twojemu dziecku przystosować się do czeskiego środowiska? (rekreacja i edukacja)
Cóż, byłoby bardzo dobrze jeśli jest coś dla mnie.
Napisz do nauczyciela, aby zrobił jej zdjęcie, żeby była pamiątka)
OK, dziękuję, w takim razie zamówię dzisiaj na cały tydzień. Czy przy zamawianiu muszę wpisać nazwisko dziecka, czy nie?
Każdy to zrobi, masz jedno?
Do 21 roku życia studiowałem w Charkowie na wydziale prawa, a potem poszedłem do pracy w prokuraturze.
Mój brat ma przyjść do mojego domu, aby pomóc przy dzieciach, żebym mogła iść do pracy.
W ciągu dnia było ciepło, a wieczorem wiał zimny wiatr.
Dlaczego? Jesteś młody i na pewno masz wiele dziewczyn.
Wszystko ma swoje plusy i minusy.
Zawsze chciałem zwiedzić Pragę.
Grishko już poszedł do żłobka, ale to nie takie proste… Dużo płacze.
Dzisiaj nowa dziewczynka z Ukrainy przyszła do przedszkola.
Nawet nie dotknąłem drzwi, a już dzwonią.
Jeśli dobrze zrozumiałem dyrektora, powiedział, że jeśli pracuję w ogrodzie, to w niektóre dni mogę przychodzić do pracy na tyle godzin, ile tylko mogę.
Jeśli tak, to będę mógł chodzić do pracy np. kilka dni w tygodniu na kilka godzin.
Na ile dokładnie godzin i w jakie dni – zobaczę jak to będzie, żebym mogła też sprzątać w apartamentach, tam za sprzątanie płacą więcej, więc nie chcę rezygnować z tej pracy.
Jestem technologem wodociągów, więc smak wody czuję od razu.
Powiedziała, że są tam niedrogie i pyszne ciasta
Ale generalnie wszystko jest dobre.
Przy okazji, czy mogę w tych dniach zrobić testy?
Może pójdę na żywo wieczorem, jeśli pozwolą mi wyjść z domu na noc!) Zobaczysz mnie😇
Jest nas jeszcze trójka (ja i dzieci, 3 lata i 17 lat), może później mąż się do nas wprowadzi, bo nadal mieszka w hostelu.
Jak długo trwają kursy i jakiego poziomu językowego można się spodziewać po ich ukończeniu?
Świetnie, tak, jestem wolny w poniedziałek.
I to byłoby dla mnie bardzo dobre.
Przygotuję wszystkie materiały.
Mam super książkę, z której krok po kroku można uczyć się języka czeskiego.
Jedyny moment, w którym bardzo bym chciał, jeśli to oczywiście możliwe, to godzina 13:00-14:00. Ponieważ pracuję do 12:30.
By dotrzeć w to miejsce na czas. Czy tak będzie dobrze?
Żaden po wojnie. Żaden, o którym nie pomyślałeś.
Odpowiedz mi wprost.
Chcesz być ze mną?
Co do mnie czujesz?
Co mogę zrobić żeby Cię przekonać?
Możesz przychodzić co weekend i nigdy się nie znudzę.
Powiesz mi jak dojść do sklepu?
Tak, Czesi są bardzo mili, przyjechałam na wakacje do moich dzieci w wieku 10 i 15 lat i do mojej babci (są w Mariánské Lázně).
Tych kobiet nie da się zrozumieć
Oferujemy darmowe zakwaterowanie.
Mieszkamy na wsi w dużym rodzinnym domu z dużym ogrodem i zamkniętym podwórkiem między Yihlava a Havlichkuv Brod.
Mamy dwoje małych dzieci.
Zapewnimy pokój.
Kuchnia, łazienka i inne udogodnienia są wspólne.
Ale najpierw miesiąc próbny, który rozpocznie się 13 kwietnia.
Na stronie internetowej, na zdjęciu jest telewizor. Proszę spytaj czy jest możliwość przyjść dzisiaj.
Mówi, że jest mu wygodnie na kanapie, nie martw się.
W razie czego coś wymyślimy.
Bardzo dziękuję za Twoją troskę.
Możemy spotykać się regularnie.
Mój mąż może przynieść to do twojego domu jutro lub w sobotę. Jeśli ci to odpowiada.
Nie dzwonił, chłopaki mijali go jeden po drugim. Wiem na pewno, że Bóg jest z nim.
Ok, to możemy iść na plac zabaw niedaleko rzeki.
Wszystko w swoim czasie. Jeśli nie masz teraz rodziny, to znaczy, że to nie jest na to czas, co oznacza, że kiedy ją będziesz mieć, będzie 10 razy większa i bliższa niż powinna.
Nie mogę pobrać, mam stary telefon. Nie znam niemieckiego.
Myślę, że szukają cukiernika, który mówi po angielsku.
Ale aby wydrukować ten dokument tak, jak go zrobiłem, należy go najpierw pobrać na komputer.
Powinien tak wyglądać.
Daj nam odkurzacz na jutro, żebyśmy mogli posprzątać.
A potem musisz zapytać… to nadal zależy od wagi i rozmiaru…
Dziękuję, nauczyliśmy się już czegoś podobnego.
Wszystko jest dobrze, poszliśmy na spacer, jestem bardzo zmęczony.
Więc jeśli nikt nie może przyjść, to nie będzie wielkiego problemu?
Wysłałem dokumenty na adres e-mail
Ale w jakim statusie spędziliśmy ten czas razem.....
Mam wyrzuty do samego siebie, a jest ich wiele.... I nie mogę sobie pomóc..
Możesz przygotować dla nas dokumenty - umowę o pracę
Ten robot jest duży, żółty i silny. Ma trzydzieści dwa lata.
Wysłałem drugą wiadomość do mojej matki.
Dziękuję, potrzebuję czegoś, ale nie mogę już nigdzie iść.. Muszę gotować i uczyć się słówek.. a może jutro o wpół do 9.. byliśmy zapisani na kursy o 11.
Marina, ale naprawdę, jeśli potrzebujesz pomocy w ogrodzie, ja i mój mąż pomożemy.
Mój przyjaciel i ja piekliśmy wczoraj, spróbuj jeśli chcesz.
Wszyscy byli chorzy i mieli objawy, ale nie pojechaliśmy do szpitala.
Przed chwilą zadzwoniła do mnie pani z DameJidlo i powiedziała, że wysłali mi mailem informacje o dalszych działaniach, ale nie odpowiedziałem na to.
Mówiła po czesku i tak ją zrozumiałem.
Ale nie mam listu od DameJidlo na moim mailu.
Potrzebuję małych szczypiec, żeby wyłożyć dip na talerz.
Rodzaj lub rodzaje działalności gospodarczej.
Poszukujemy gosposi do regularnego sprzątania domów tutaj na wsi.
Oferta 150 koron/godzinę. 
Kolejna współpraca w zależności od zadowolenia.
Sam umówisz datę z panią.
Jasne, ale wprowadzam cię w błąd.
Mężczyźni również mają wiele niuansów
Był bardzo bogatym człowiekiem, ale lubił mnie, bo miałam własny punkt widzenia na życie. Spotykałam się z nim, a potem go zostawiłam.
Był bardzo bogatym człowiekiem. Jakiś czas później zadzwonił do mnie i powiedział, że przeszedł operację serca.
Poprosił mnie tylko żebym z nim porozmawiała i wspierała go, było mi go żal.
Był bardzo bogatym człowiekiem i myślał, że może jestem jego zabawką i może potrzebuję jego pieniędzy.
Później oświadczył mi się.
Na moim podwórku stał samochód, wyglądał jak krokodyl i odpalał "grady".
I trzymali mnie w domu, potem zabrali mnie do piwnicy i tam było dużo ludzi, około 400 osób, nie mogłem oddychać.
A co z mieszkaniem? Wysłałeś zdjęcie.
Właściwie jeszcze tam nie dotarłem.
Ministerstwo Edukacji i Nauki Ukrainy już zdementowało to kłamstwo.
Obejrzę dwa ostatnie filmiki kiedy internet będzie dobrze działał.
Czy w pracy obowiązuje dress code czy nie, czy mogę nosić to, co mam?
W porządku, on tam podejdzie i je weźmie.
Nie jestem chciwy na wszystko.
Rozumiem, że nie mogę z tobą zostać, muszę pracować.
Rozumiem. Dziękuję, ale wcale nie potrzebujemy 1+1 i ukraińskiej telewizji.
Widzę wszystkie wiadomości w internecie.
A 1+1 to proprezydencki, propagandowy kanał, który w ogóle mnie nie interesuje.
Co stało się na przystanku autobusowym z tym mężczyzną, że przyjechała policja i karetka? Czy wszystko z nim w porządku?
Diana mi nie odpowiedziała i ty też.
Ok, muszę tylko wydrukować kolorowanki dla dzieci. Więc byłoby dobrze. Kiedy możemy przyjść?
Ale może potrzebujesz bardziej szczegółowej znajomości języka czeskiego.
Martwię się, czy będziesz zadowolony z mojej pracy.
W tym przypadku znam dziewczynę, która jest Ukrainką, ale studiuje w Czechach na kierunku turystyka.
Naprawdę nie chcesz przyjść na chwilę w pokoju z dziećmi i babcią.
Chcę żebyś był ze mną. Żeby budzić się obok Ciebie.
Ogólnie ciężko jest żyć w obcym kraju, każdego dnia coraz bardziej chcę wrócić do domu.
Pani Agato, jeśli potrzebuje Pani tego zdjęcia, zrobię zdjęcie sama.
Dziękujemy za starania, aby nasze życie tutaj było jak najlepsze.
Będę pamiętać Cię do końca mojego życia.
A ja będę pamiętać i uśmiechać się ☺️❤️❤️❤️
Anya, bardzo dziękuję Ci za wytyczenie trasy w geolokalizacji na telefonie, żebyśmy mogli szybciej dotrzeć na miejsce.
Muszę zapłacić taryfę, muszę to kontrolować.
Jak mogę zobaczyć ile użyłem?
I jak mam zapłacić?
Mówię jej, że „naprawa odbiornika telewizyjnego i radiowego” została opóźniona z powodu importowanych części, a przyjaciele i znajomi zostali ostrzeżeni, aby nie zdradzać, kiedy dzwonią”.
'Przez cały miesiąc ukrywaliśmy przed teściową informacje o wojnie. Do tej pory to działa. Jednakże, Plyamka (kot - UP) straciła sierść na brzuchu i tylnych łapach - może to być spowodowane stresem, zmianą karmy i brakiem witamin. Dwa ostatnie powody zostały wyeliminowane, ale stres niestety nie zależy ode mnie. Plyamka, w przeciwieństwie do teściowej, nie jest głucha, słyszy zarówno syreny, jak i wybuchy.''
„Ze względu na to, że Olga jest niedosłysząca i większość czasu spędza w swoim pokoju, jej synowa od miesiąca mieszka ze swoim „incognito” w mieszkaniu. A 1 kwietnia 93- letnia Oksana Poleva po raz pierwszy w swoim życiu wzięła do ręki broń”.
A 1 kwietnia 93-letnia Oksana Poleva po raz pierwszy w swoim życiu wzięła do ręki broń.
'Od 33 dni, jako partyzantka, mieszkam z nią w mieszkaniu. Ukrywali przed nią i wojnę, i fakt, że jestem w pobliżu - formalnie przyjechała jak zwykle na kilka godzin. Ale kiedy jej przyjaciółka się wymknęła, dałam jej odbiornik – słuchała przez 4 godziny, potem śpiewała przez 2 godziny.''
Radio zawsze było przy łóżku.
Teściowa większość czasu spędza w swoim pokoju.
Ona jest niedosłysząca – to pozwoliło mi być dla niej niewidzialnym.
Jeśli słyszałem odgłos jej kroków, chowałem się w swoim pokoju.
Przede wszystkim schowałem przed nią odbiornik i telewizor.
Potem zadzwoniłem do wszystkich, którzy się z nią komunikują. To 6-7 osób.
Poprosiłem, żeby z nią porozmawiać o wszystkim, tylko nie o wojnie.
Zapytam przyjaciółkę, była tam od początku do końca
Jest 17 kwietnia - mam 2 mieszkania do posprzątania :)
Dobry wieczór, jakoś o tym nie pomyślałem
Cześć, jeśli jutro nadal będziesz potrzebować naszej pomocy, będziemy mogli przyjść
Trzeba zamówić lunch, czy można zabrać lunch z domu? Te dokumenty trzeba wydrukować, czy będą drukowane na miejscu i ja je podpiszę?
Oferuję strzyżenie męskie, damskie, dziecięce na miejscu u Państwa, wszystkich zainteresowanych zapraszam do pisania w wiadomości prywatnej, cena:
Rozumiem Cię i nie narzekam, ale w mojej sytuacji na razie tu zajrzę.
Mówię ci, ambasady są tylko tutaj,
Brytyjczyk, który bronił Mariupola w szeregach Sił Zbrojnych Ukrainy, mówi, że jest gotów poddać się Rosjanom
Brytyjczyk, który jest członkiem brygady piechoty morskiej Sił Zbrojnych Ukrainy, która bierze udział w obronie Mariupola, powiedział swoim przyjaciołom i rodzinie, że złożą broń i poddadzą się rosyjskiemu okupantowi.
Źródło: Twitter Aidina Aslina, Brytyjczyka, który służył w Siłach Zbrojnych od 2018 roku, BBC w odniesieniu do członków rodziny i przyjaciół Aslina, Atlas News w odniesieniu do słów znajomego Aslina, który z nim rozmawiał
Cytat z Twittera Aslina: „Otrzymaliśmy od niego wiadomość: „Minęło 48 dni, staraliśmy się jak najlepiej bronić Mariupola, ale nie mamy innego wyboru, jak poddać się siłom rosyjskim”.
Nie mamy jedzenia ani amunicji.
Dziękuję wam wszystkim, mam nadzieję, że wojna niedługo się zakończy.''
Szczegóły: Aslid służył w w 36. oddzielnej brygadzie piechoty morskiej Sił Zbrojnych Ukrainy, która uczestniczy w operacji obronnej Mariupola.
BBC skontaktowało się z matką żołnierza Anne Wood, która potwierdziła, że jej syn powiedział jej przez telefon, że planują poddanie się.
Przyjaciel żołnierza, Brennan Phillips, również potwierdził dziennikarzom, że w ostatniej rozmowie telefonicznej Aslin powiedział im o planach poddania się ich jednostki.
Według niego w brygadzie zabrakło amunicji i żywności.
Dziennikarze Atlas News skontaktowali się z jego przyjacielem, który powiedział, że oddział Aslina zamierza poddać się oddziałom rosyjskim, aby nie wpaść w ręce oddziałów tak zwanych „kadyrowców” pozbawionych broni i kul.
W sieciach społecznościowych krążyło również nagranie dźwiękowe rozmowy telefonicznej, w której Aslin rzekomo rozmawia ze swoim amerykańskim przyjacielem, który planuje wyjazd na Ukrainę.
W tej rozmowie Aslin powiedział, że próbowali wydostać się z miasta w cywilnych ubraniach, ale im się to nie udało.
Wcześniej Brytyjczyk powiedział, że przedstawiciele prywatnej firmy wojskowej „Wagner” grozili mu na Instagramie.
Aslin był pracownikiem socjalnym w mieście Newark-on-Trent w Nottinghamshire, ale w latach 2015-2017 wyjechał, by wziąć udział w walkach z terrorystami tak zwanego „Państwa Islamskiego” w Syrii.
W 2018 roku oficjalnie wstąpił do Sił Zbrojnych Ukrainy i złożył przysięgę.
Aslin był nazywany Johnny przez swoich przyjaciół i krewnych, w sieciach społecznościowych jest bardziej znany pod pseudonimem Cossack Gundi.
Proszę, wiem, że to dla ciebie trudne. Ale też chciałbym wiedzieć. Czy jesteśmy razem czy nie.
Ale to nie będzie łatwe, musisz go znaleźć…
Zaproponowałeś, że pójdę z tobą, zgodziłem się, jeśli wszystko pójdzie dobrze
Dziękuję, teraz nie ma takiej potrzeby, już dużo dla nas zrobiłeś, jesteśmy Ci bardzo wdzięczni
Jeśli nie chcesz do mnie więcej pisać, poczekam
Cześć Natalya, proszę podlej kwiaty na zewnątrz, obok drzwi wejściowych. Dziękuję.
Chciałabym też uczyć się czeskiego
Chciałbym, żebyś chociaż trochę odpoczął i pomyślał o sobie.
Koniecznie nałóż dziś krem do twarzy)
Tak.. Jestem ci bardzo wdzięczny. Nawet nie spodziewałam się, że znajdę taką osobę, zdrowia i powodzenia!!!!
Czy mały Duszan już się nie wstydzi?
Ondrzej przyjechał do nas z ojcem.
Nikt inny nie przyszedł, chociaż ulicą spacerowało wielu kolędników.
Jesteśmy dzisiaj w domu.
Dzieci odrobiły lekcje, teraz się bawią.
Po obiedzie muszę iść do Lidla kupić jedzenie.
Masz mnie.
Wiesz, że Cię kocham.
Zrobię dla Ciebie wszystko.
Jak mam to udowodnić, moje kochanie?
Chcę żebyśmy mieli szansę być razem.
Żeby Ci wszystko udowodnić.
Być może przeżyłeś wiele rozczarowań.
Pozwól mi Cię uszczęśliwić.
Babcia nie będzie w stanie, bardzo bolą ją nogi i dolna część pleców.
A ile kosztuje wynajęcie dwupokojowego mieszkania w Pradze?
Wszyscy rodzice przyjdą?
Klimat jest prawie taki sam.
Rodzina ma się dobrze, mam tutaj mamę, trzech braci i męża.
Jeden brat poszedł na wojnę w Mariupolu, drugi jest w Zaporożu, a męża przewieziono dziś z Kijowa do Charkowa.
Dzwonią do mnie codziennie i mówią, że wszystko jest w porządku, ale kto wie, i tak nie powiedzą prawdy.
Chciałem przyjść do ciebie, ale wciąż chciałem wyprostować pewną sprawę. Kiedy
Zapytam męża rano czy ma jutro czas.
Kiedy wrócisz do domu, napisz do mnie, proszę, musiałbym porozmawiać z Daniilem.
Bolszewiccy atakujący w pełni odrobili straty poniesione w bitwie.
Zastrzelili nauczyciela Dmytra Pawłyckiego, jego krewnego o nieznanym nazwisku, młodzieńca Borysa Oleksienko.
Ich ciała wrzucono do „głębokiego doła, który zasypano ziemią”.
Według wspomnień „w mieście panowała jakby grobowa cisza”.
Czasami któryś z mieszkańców biegał w pośpiechu od domu do domu.
Ciała torturowanych przez bolszewików nieustannie znajdowano na ulicach.
I może naprawdę pójdę za tobą. Potrzebuję cię. Nie mogę bez Ciebie.
3. Które z twoich własnych biznesów/działań pomogłyby tobie lub twoim przyjaciołom lepiej przystosować się do życia w Czechach?
Ale tam nie dojedziesz, ponieważ tory kolejowe są przebudowywane i wjazd jest zamknięty.
Dotrzesz do mostu, na którym trwa przebudowa, powiedz mi, że dotarłeś, a ja przyjdę do ciebie
Czeka nas najlepsza przyszłość
Lena, czy mogę dać ci rzeczy, które nie pasowały na nas rozmiarem, czy mogę je dać Katyi?
Tak, przestałem budzić się w środku nocy.
Po prostu budzę się bardzo wcześnie rano bez budzika.
Na razie śpię 4-5 godzin, ale przynajmniej mogę już spać.
Marina nie mogła mnie dzisiaj obudzić kiedy przyjechali)) Ale to wymaga czasu, muszę to przeboleć.
Jeśli dobrze zrozumiałem, szkoła wyśle nam list z wejściówką na zamówienia menu
Cóż, spróbujemy to wziąć, we wtorek idziemy do opieki społecznej
Następnie, gdy farsz ostygnie, a ciasto wyrośnie, robimy pierożki i smażymy je na małym ogniu na oleju.
OK, na pewno go zapytam.
Jak tylko wprowadzimy się jutro wieczorem, zadzwonię do niego o wtorek.
Chciałbym podziękować wszystkim, którzy nam pomogli, bo to była naprawdę ostatnia nadzieja.
Nie boję się pracy, bo też mieszkałam na wsi, więc mogę i lubię pracować fizycznie.
Kiedy mogę przynieść Ci te rzeczy?
Macie bardzo ciekawą tradycję, my robimy to na Święta.
W ubiegłym tygodniu Rada Najwyższa przyjęła projekt ustawy nr 7176, który nosi tytuł „O monitorowaniu potencjalnych zagrożeń bezpieczeństwa narodowego Ukrainy w sferze gospodarczej”.
To ciekawe, że tak naprawdę jedynym potencjalnym zagrożeniem dla bezpieczeństwa narodowego Ukrainy w sferze gospodarczej okazało się... miejsce spotkań członków rad nadzorczych spółek państwowych i banków państwowych.
Pomysłodawcy projektu ustawy uważają, że podjęcie decyzji przez radę nadzorczą państwowej spółki, powiedzmy, w Kijowie, może w jakiś sposób rozwiązać problemy bezpieczeństwa narodowego Ukrainy.
Wiemy o wielu nowych zagrożeniach dla spółek Skarbu Państwa, ale jak dotąd nie znamy żadnej spółki, która musiałaby fizycznie odbyć posiedzenie rady nadzorczej pod wskazanym adresem.
Potencjalne zagrożenie ze strony takiej ustawy jest oczywiste – stanowi doskonałą podstawę do „zburzenia” wszelkich aktywów w trudnej reformie przedsiębiorstw państwowych po Rewolucji Godności, w tym niezależnych rad nadzorczych, a następnie ustanowieniu ręcznego zarządzania.
Istniał do 2015 roku.
Po co spółkom Skarbu Państwa rady nadzorcze i kto powinien w nich zasiadać?
Co więcej, jeśli pod patriotycznymi hasłami „wyjdzie” jeden szkodliwy projekt ustawy, to jutro mogą wyjść inne – na przykład system zamówień publicznych przez ProZorro czy niezależność NBU mogą zostać zburzone.
Wojnie można przypisać wiele.
Nawiasem mówiąc, inicjatywa ta pojawiła się jeszcze przed rozpoczęciem wojny i projektem ustawy 7176.
Tak więc, 22 lutego ta norma została uwzględniona w tabeli porównawczej projektu ustawy 5397.
I generalnie, chęć rozproszenia rad nadzorczych w taki czy inny sposób krąży wśród niektórych deputowanych od dawna.
Nie dla krytyki jako takiej, ale dla ukazania możliwych konsekwencji projektu ustawy przeanalizujemy argumenty wykorzystywane do wyjaśnienia potrzeby jej przyjęcia.
A potem przedstawimy nasze propozycje, jak rozwiązać problem zarządzania przedsiębiorstwami państwowymi w czasie wojny.
Pierwszy wiceminister gospodarki, Denys Kudin tłumaczył potrzebę takiej innowacji zagrożeniami utraty Internetu i innych środków komunikacji, co uniemożliwiłoby zdalną pracę rad nadzorczych.
Innymi słowami, istnieje ryzyko, że rada nadzorcza nie będzie w stanie podjąć niezbędnych decyzji, co może sparaliżować pracę spółki.
Zgadzamy się, że takie ryzyko istnieje, ale czy uda się mu zapobiec poprzez przeniesienie członków rad nadzorczych na Ukrainę?
Wyobraźmy sobie dość cyniczną sytuację, gdzie niezależni członkowie rad nadzorczych (którzy stanowią większość całego składu) przedłożą swoje bezpieczeństwo osobiste ponad interes spółki i odmówią przyjazdu na Ukrainę.
W takim przypadku, zgodnie z projektem ustawy, można ich odwołać.
A wtedy najprawdopodobniej doprowadzi to do utraty kworum niezbędnego do podejmowania przez radę nadzorczą jakichkolwiek decyzji.
Jednocześnie nie będzie możliwe szybkie powołanie nowych niezależnych członków rady nadzorczej, ponieważ prawo przewiduje konieczność wyboru w drodze konkursu, który trwa średnio 3-4 miesiące.
Zatem decyzja proponowana w projekcie ustawy 7176 najprawdopodobniej nie będzie w stanie uchronić rady nadzorczej przed utratą zdolności do podejmowania decyzji, a wręcz przeciwnie, do tego doprowadzi!
Poseł ludowy, autor projektu ustawy Dmytro Natalukha, przytacza inne argumenty na jej poparcie.
W szczególności zauważa, że: „wiele przedsiębiorstw, w szczególności z kompleksu obronno-przemysłowego, potrzebuje teraz relokacji” i dlatego „trudno sobie wyobrazić, że ktoś może np. z Wiednia przez Zoom omawiać adresy i inne wrażliwe informacje."
Zacznijmy od tego, że w Ukrainie prawie nie ma państwowych przedsiębiorstw przemysłu obronnego, które mają rady nadzorcze w Ukrainie.
Tylko w Ukroboronpromie istnieje rada nadzorcza, która zasadniczo zarządza prawie wszystkimi państwowymi przedsiębiorstwami przemysłu obronnego.
Ale nawet w Ukroboronpromie, zgodnie z przepisami, rada nadzorcza ma dość ograniczone uprawnienia, a wszyscy jej członkowie wykonują swoje obowiązki nieodpłatnie.
Cała władza w Ukroboronromie należy do dyrektora generalnego, który zresztą będzie podejmował decyzje o konieczności przeniesienia tego czy innego przedsiębiorstwa przemysłu obronnego wchodzącego w skład koncernu.
Ponadto taka argumentacja nie wytrzymuje krytyki także dlatego, że projekt ustawy 7176 nie wprowadza w ogóle żadnych zmian w ustawodawstwie regulującym działalność państwowych przedsiębiorstw przemysłu obronnego.
Na swojej stronie na Facebooku Dmytro podaje również argumenty, które można zaklasyfikować jako „emocjonalne”.
Takie argumenty z reguły nie mają nic wspólnego ze zwiększeniem efektywności państwowych spółek i państwowych banków, ale spróbujmy przeanalizować niektóre z nich: „szanowani zagraniczni eksperci na pierwsze słowo „wojna”opuścili Ukrainę w 2021 , ale jednocześnie pozostali członkami rad nadzorczych w państwowych przedsiębiorstwach Ukrainy z pełną pensją w wysokości kilkuset tysięcy hrywien, podczas gdy sama Ukraina naprawdę cierpi z powodu wojny”.
Przede wszystkim jest to manipulacja – większość z tych członków rad nadzorczych nigdy nie mieszkała na Ukrainie i przyjeżdżała tu tylko od czasu do czasu.
Dlatego stwierdzenie, że „opuścili Ukrainę” jest, delikatnie mówiąc, niesprawiedliwe.
Po drugie, w wyniku pandemii koronawirusa zarówno zagraniczni, jak i ukraińscy członkowie rad nadzorczych od dawna uciekają się do praktyki odbywania spotkań online.
To narzędzie od dawna jest szeroko rozpowszechnione w światowej praktyce i to w zupełnie innych obszarach: biznesie, edukacji, ochronie zdrowia itp.
Nie należy również zapominać, że członkostwo w radzie nadzorczej nie jest pracą na pełen etat.
Z reguły takie osoby wykonują także inne zawody, a elektroniczne środki komunikacji im w tym pomagają.
Po trzecie, wszystkie te wypowiedzi odczytywane są wyłącznie jako roszczenia wobec cudzoziemców.
Zastanawiam się, dlaczego Dmytro nie wysuwa podobnych roszczeń wobec członków rad nadzorczych, którzy są Ukraińcami?
Przecież oni też nie są zlokalizowani w miejscu swoich firm.
Nawiasem mówiąc, daleko temu do pierwszej populistycznej próby usunięcia cudzoziemców z rad nadzorczych przez deputowanych, a wojna to tylko kolejny pretekst.
Cześć. Jestem w Ukrainie. Poszukuję możliwych opcji tymczasowego schronienia z rodziną. Mam ze sobą 2 dzieci.
5 pocisków trafiło w moje rodzinne miasto Lwów
Moja dusza jest wypełniona cichą radością. Patrzę na Zhozy i widzę jej szczęście, pewność jej kroków.
Proszę, powiedz mi, czy Viktor będzie mógł jutro pomóc nam z lodówką? Ponieważ sami nie będziemy w stanie jej przenieść.
W tym tygodniu mógłbym przyjść w środę, a w przyszłym tygodniu myślę, że mógłbym przyjść w czwartek.
Tak, rozumiem, co musi być zrobione.
Będę również wdzięczna za wskazówki na początku, żebym zrobiła wszystko tak, jak potrzebujesz😊
Zwykle wymagają paszportu jednej z dorosłych osób
W rejonach Browarskim, Wyszogrodzkim i Buczańskim obwodu kijowskiego, które zostały wyzwolone spod okupacji, na 2 dni zostanie wprowadzona zaostrzona godzina policyjna.
Bezpośrednie przemówienie Pavlyuka: „W miejscowościach rejonów Browarskiego, Wyszogrodzkiego i Buczańskiego, które były pod okupacją rosyjską i zostały wyzwolone przez ukraińskie siły zbrojne, zaostrzono godzinę policyjną!
Na terenie tych miast i wsi ograniczenia obowiązywać będą od 2 kwietnia godziny 21:00. do 5 kwietnia godziny 6:00.
Szczegóły: Według szefa regionalnej administracji wojskowej, w tym czasie obowiązuje całkowity zakaz poruszania się po ulicach obszarów mieszkalnych i w innych miejscach publicznych, poruszania się pojazdami i pieszo.
Mieszkańcy mogą wyjść na zewnątrz tylko podczas alarmu przeciwlotniczego, aby udać się do schronu.
Takie ograniczenia wprowadza się w celu usunięcia skutków rosyjskiej agresji – oczyszczenia i rozminowania terytoriów.
Omelanyuk zaapelował do osób, które opuściły te tereny, aby na razie powstrzymały się od powrotu do domu.
Na pozostałym obszarze obwodu kijowskiego godzina policyjna obowiązywać będzie od godz. 21 do 6 rano każdego dnia.
Jeszcze nic nie zostało do mnie wysłane ze szkoły, mam tylko dowód wpłaty
1. Brakuje Ci ważnych informacji? Jeśli tak, jakiego rodzaju?
Przygotowaliśmy dla Was pierogi do spróbowania. Należy je gotować przez 7 minut
2. Stołówka w przedszkolu zapewnia posiłki prawidłowo przyjętym dzieciom w wieku od 2 do 6 lat, dzieciom z odroczonym terminem nauki (7 lat) oraz posiłki dla personelu przedszkola.
Powiem szczerze, że zawsze pierwszy zostawiałem kogoś, ale potem prosili mnie o przebaczenie, próbowali odbudować związek.
Ale już tego nie potrzebowałem, jeśli zawiodłem się na kimś, to na zawsze.
Jest nas czterech, dwie osoby dorosłe i dwójka dzieci, to jest bardzo małe mieszkanie, potrzebujemy jeszcze jednego pokoju z łóżkiem.
Cześć, idziemy jutro do kawiarni?
Czy możesz mi podać kod pocztowy?
Mój telefon jest zepsuty. Nie można go naładować. Do wtorku będziemy w kontakcie przez komórkę Oleksija.
Zamówiliśmy już obrączki, chcesz je zobaczyć?
Słyszeliśmy, że już poszedłeś do szkoły.
Weź mnie do swojego rządu
Przyszedłem ponownie wcześnie w poniedziałek i włączył się alarm
Potrzebuję mieszkania, przeprowadzimy się, znaleźliśmy mieszkanie, ale nie ma w nim mebli, lodówki, pralki....
Dlaczego tego zabroniłeś?
To mi nie odpowiada, dojazd do Pragi będzie bardzo kosztowny i czasochłonny, droga zajmie dużo czasu.
Witam, szukam pracy dla mojej żony w służbie zdrowia, jest ratownikiem medycznym lub pielęgniarką.
Rozumiem, że wykorzystałem całą miesięczną ilość GB w trzy dni?
Ostrzegam, będę w stroju sportowym
A jeśli mówię poważnie
Muszę wyjść/odejść
Czy mogę wyprać białe prześcieradła, a potem wrócić po 14:00, wyprasować je i powiesić?
Super, napiszę jak wyjdę
Więc pomoc w transporcie pierwszy raz jest bardzo potrzebna, do czasu aż poznamy teren i będziemy mogli sami poruszać się komunikacją miejską
Kiedy poprosiłam Katię, żeby zadzwoniła do straży granicznej, powiedziała, że nie może
Umowa, ale dopiero po 20:00 bo do tego czasu będę zajęty
Dziękuję Bogu, że nie widzi tej wojny.
Instytucja szkolnictwa wyższego, w skrócie „ZVO”, nieoficjalnie „vysh”[1] (przed uchwaleniem Ustawy Ukrainy „O oświacie”[2] używano terminu uczelnia wyższa, a także skrótów „VNZ”[ 3], „vuz”[4]) jest odrębnym typem instytucji, która jest osobą prawną prawa prywatnego lub publicznego, działa zgodnie z wydaną licencją na prowadzenie działalności dydaktycznej na określonych poziomach szkolnictwa wyższego, prowadzi działalność naukową, naukową i technicznej, innowacyjną i/lub metodyczną, zapewnia organizację procesu kształcenia i zdobywania wyższego wykształcenia, kształcenia podyplomowego przez osoby z uwzględnieniem ich powołania, zainteresowań i zdolności[5].
Moja mama nie odważyłaby się tego zrobić, uwielbia długie włosy
Przez te wszystkie dni po prostu spacerowałem z klasą i nauczycielem
To musi być pora na pójście spać.
Nie chcę mieć z tym problemów, już się cieszymy, że się stąd ruszamy, niech oni sobie tu walczą między sobą
Istnieje tłumaczenie tego dokumentu słowo w słowo w języku czeskim.
Dopiero na dole dodano wyjaśnienie, co oznacza inkaso.
Mam już konto. Zrobiłem je w innym banku. Ponieważ potrzebowałem konta do pracy.
Serbski budżet obronny rośnie wykładniczo od kilku lat z rzędu.
W sumie, w ciągu ostatnich sześciu lat Serbia zainwestowała ponad dwa miliardy euro w modernizację armii, odnowienie sprzętu wojskowego i zakup nowoczesnych systemów, awansując o 22 miejsca wyżej na liście najpotężniejszych militarnie państw w świat.
Po zmasowanej agresji Federacji Rosyjskiej na Ukrainę kraje zachodnie dość poważnie potraktowały prognozę ewentualnej eskalacji na Bałkanach.
Dla Ukrainy oznacza to, że dyplomatyczne rozwiązanie konfliktu rosyjsko-ukraińskiego staje się coraz bardziej skomplikowane i globalne.
Jeśli nie masz nic przeciwko, przyjdę
Tak, zarejestrowaliśmy się, ale jest to trudne, mieszkamy tutaj w hostelu i nie jest to zbyt wygodne dla mojego syna. Chciałbym pojechać na wieś.
Czekamy na Ciebie następnym razem
Dzień dobry, zrobiliśmy testy i zarówno my, jak i lekarz zostaniemy poinformowani o wynikach
Jeśli jesteś w Czechach bez prawa jazdy, masz zakaz prowadzenia samochodu.
Inne często zadawane pytania dotyczące prawa jazdy:
👉Mam prawo jazdy ważne na Ukrainie, czy mogę z nim jeździć po Czechach?
Jeśli jednak będziesz w Czechach dłużej niż rok, musisz wymienić je w gminie na czeskie prawo jazdy.
👉Prawo jazdy straciło ważność, co z tym zrobić?
• Jeśli straciło ważność po 1.01.2022 – zachowuje ważność.
• Jeśli straciło ważność przed 1.01.2022 r. – jest nieważne i należy zdać egzamin,
👉Posiadam ważne ukraińskie prawo jazdy i chcę je wymienić na czeskie:
• pobyt w Czechach trwa co najmniej 185 dni w roku kalendarzowym.
• istnieje możliwość wymiany w gminie zgodnie z miejscem zamieszkania.
👉Nie mam ważnego prawa jazdy, a chcę czeskie:
• Wymagane jest ukończenie nauki w szkole nauki jazdy i zdanie egzaminu na prawo jazdy.
Zapytaj nas o procedurę egzaminu 😎
Nie otrzymałem karty pocztą, chociaż minął ponad tydzień. Możesz pomóc?
Inaczej tam nie dotrę (
Rozmawiałem z Wołodymyrem o mieszkaniu, pytałem o radę, co robić, czy czekać, czy iść na stację metra Muzeyna i tam zapytać, poradził mi, abym poszedł do Muzeyny. Waszym zdaniem, co powinienem zrobić?
Umówiłem się z panią Marketą, że mnie zatrudni.
A teraz szukam pracy dla pani Swietłany.
Może pracować jako piekarz, cukiernik, wyrabiacz wyrobów piekarniczych oraz pomoc kucharska.
Ale nic nie jest potrzebne.
Czy możemy się spotkać i porozmawiać osobiście?
Od maja szukam mieszkania, najlepiej za darmo, dla siebie, mamy i dwójki dzieci.
Najlepiej niedaleko Karlowych Warów
Czasami dzwonią do mnie, żebym została modelką
A jeśli nie doładuję dziś mojego konta, to czy jutro mój numer nie zostanie zablokowany?
Czy możemy zatem zmienić pakiet jutro, jeśli miesięczna taryfa już wygasła?
Nie zrozumiałem, czy przez dwa miesiące, czy przez jeden, nie zrozumiałem ich
Potrzebujemy pigułki na chorobę lokomocyjną
Wielka Brytania chce eksmisji wszystkich Rosjan ze swojego terytorium wraz z konfiskatą całego mienia!
Dzień dobry, czy macie pudełko na zabawki?
Dużo podróżowałem po mieście transportem, samochodem.
Jednak nie znam dobrze nazw.
To jest w sumie ok, bo moje myśli skupiły się na czymś zupełnie innym.
Obecnie jestem psychicznie spokojniejsza niż wtedy, kiedy tu przyjechaliśmy
Jak się masz?
Fałszywe informacje o studentach wcielonych do wojska, przygotowaniach do ewakuacji szkół wyższych i zwalnianiu miejsc w domach studenckich krążyły na portalach społecznościowych.
Sztuka pomaga odwrócić uwagę i zmienić
Rozumiem, że Ty jako wolontariusz i po prostu dobry człowiek, szczerze chcesz nam pomóc i nas wesprzeć.
I rozumiem, że potrzebujesz zdjęcia, że pomagasz i tak dalej…
Ale zrozum mnie też. Żyło mi się dobrze na Ukrainie, nie potrzebowałem żadnej pomocy.
I nie chcę, żeby niektórzy z moich znajomych to widzieli i tak dalej. Zrozum mnie dobrze ☺️.
Mogę zadać pytanie?
Czy wiesz, jak potoczyło się życie tych dziewczyn, które cię opuściły?
Czy chciały do ciebie wrócić?
Jak oni zbudowali nową relację?
I są szczęśliwi?
Cześć, jak się czujesz? Co dzisiaj robiłeś?
Dostałem dwie szczepionki Pfizera w Kijowie
Mam certyfikat, ale niedawno stracił ważność i myślę, że potrzebuję dawki przypominającej?
Jeśli to nie problem, czy mogę poznać szczegóły u lekarza?
W niedzielę mam wolne. Często jeździliśmy do Charkowa, było tam pięknie
Mam nadzieję, że wszystko będzie dobrze (( i rozwiążemy nasz problem mieszkaniowy (
Również dzisiaj, jeden człowiek powinien oddzwonić i powiedzieć, czy znalazł coś dla mnie.
Nie wiem jak to jest ze składką na całą rodzinę.
O której godzinie się spotykamy, żeby włożyć rzeczy do prania?
Mam urodziny w środę.
Chciałem, żebyś wydrukował ogłoszenie do kuchni, żeby wszyscy umyli kuchenkę po użyciu.
Zajęto mi miejsce w kolejce.
Generalnie myślę, że nie dam rady jutro bez Ciebie.
Od dawna chciałem zapytać i zawsze zapominałem.
A jak u Was ze szczepieniem na COVID?
Nie miałam czasu, aby w domu otrzymać dawkę przypominającą (trzecią dawkę) szczepionki. Czy to szczepienie jest tutaj płatne?
Będę czekać aż zadzwonisz. Czy powinienem zabrać ze sobą jakieś urządzenia?
Dobrze, że już dotarliście🙏🏻I bardzo dziękuję za miły wieczór i 🌹
Wydrukuję nowy bilet i możesz iść do holu
Kobieta z dwójką dzieci szuka miejsca na pobyt od dwóch do sześciu miesięcy, w zależności od warunków panujących w naszym kraju.
W naszym kraju trwa wojna i musimy przenieść się w bezpieczne miejsce.
Mogę pomóc gospodarzom w pracach domowych, gotować lub sprzątać.
Mogę pracować w ogrodzie, wiem jak uprawiać warzywa i kwiaty.
Mogę zająć się zwierzętami.
Proszę o informacje od porządnej i życzliwej rodziny, która jest gotowa dać nam mieszkanie i wesprzeć nas w naszej sytuacji.
Czekam na twoją odpowiedź.
Żeby być w kontakcie napisz na mój email anonymized@example.com. Dziękuję.
Daj mi znać, jeśli nie wypełniłem tego formularza i nie otrzymałem jeszcze żadnych płatności
Musiałem ci tylko powiedzieć, że się zepsuł
Musiałem zadać złe pytanie.
Nie powinienem jej zabierać ze sobą, usługi opieki nad dziećmi są przeznaczone dla znacznie mniejszych dzieci, czy mogę ją zabrać?
Korzystanie z samochodu służbowego i zwrot kosztów
Nie, tutaj, gdzie byliśmy wieczorem z panem Piotrem, obejrzeliśmy ten dom, pasuje nam, bardzo nam się podobał
Musisz wymyślić swoje hasło
Siły bezpieczeństwa reżimu Łukaszenki zatrzymały trzech Białorusinów w wieku 27 i 28 lat, którzy brali udział w zniszczeniu dwóch szafek przekaźnikowych instalacji sygnalizacyjnej pod Osypowiczami, która zapewnia ruch pociągów kolejowych.
Źródło: „Radio Swaboda”, centrum praw człowieka „Wyasna”, szef policji kryminalnej Ministerstwa Spraw Wewnętrznych Gennadiy Kazakievich, cytowany przez państwową agencję informacyjną „BeITA”
Ministerstwo Spraw Wewnętrznych Białorusi poinformowało, że w nocy 30 marca przy wsparciu sił specjalnych „SOBR” zatrzymano trzech mieszkańców Bobrujska, jeden z nich został ranny.
Według "Vyasny" podczas zatrzymania mężczyźni aktywnie stawiali opór i próbowali uciec.
Siły bezpieczeństwa użyły broni.
Jeden z zatrzymanych został ranny i przebywa w placówce medycznej.
Innym udzielono pomocy na miejscu.
Szef policji kryminalnej Ministerstwa Spraw Wewnętrznych Białorusi Gennady Kazakevich powiedział, że "akty terroryzmu na szynach kolejowych Republiki Białorusi będą bezwzględnie powstrzymywane" przez siły bezpieczeństwa z użyciem broni.
6 kwietnia okazało się, że 30 marca policja zatrzymała kolejnego pracownika Kolei Białoruskich, pracownika baranowickiego oddziału Kolei Białoruskich i administratora zasobów tematycznych Kolei Białoruskich w „VKontakte” i „Odnoklasnikach” Walentyna Samasiuka.
Gdzie on jest teraz i w jakim jest stanie, nie wiadomo, informuje @belzhd_live.
Pod koniec marca na Białorusi zatrzymano co najmniej 40 pracowników kolei za sabotaż.
Dla przypomnienia: formacja BYpol, uznawana przez reżim Łukaszenki za ekstremistyczną, w dalszym ciągu wzywa Białorusinów do przeprowadzania sabotażu na obiektach transportu kolejowego i infrastruktury na Białorusi w ramach planu „Zwycięstwo”.
Białoruscy „kolejowi partyzanci” próbują w ten sposób przeciwstawić się rosyjskiej agresji na Ukrainę.
Jak wiadomo Federacja Rosyjska przekazuje przez Białoruś siłę roboczą i sprzęt do walki na Ukrainie.
Ma to na celu podniesienie samooceny
Czy lubisz czytać książki?
A w święta wielkanocne też nie działają w trybie telefonicznym?
Czy można to zrobić telefonicznie w dowolnym dniu, czy nie?
Uchwalono nawet osobną ustawę w tej sprawie
Jedziemy tu już 4 dni, więc to raczej horror niż droga.
Jechaliśmy przez obwód kijowski, miasto Irpin, potem był horror, strzelanina, syreny.
Też się o nich martwię.
Silvia, Masza nie otrzymała jeszcze pieniędzy od Kletsany, czy mogę do nich zadzwonić?
Tak, powiem im, myślę, że będą w domu.
Są różni muzułmanie. Są fanatycy i są prawdziwi wierzący.
Znaczenie dżihadu jest różnie interpretowane przez różnych muzułmanów.
Ale szczerze mówiąc, czuję się bardzo nieswojo, robiąc to dla pieniędzy.
Zrobiłeś dla mnie dużo dobrego.
Mogę zrobić to za darmo.
Tymczasowo, na czas poszukiwania uczelni, później oczywiście potrzebny będzie stały pobyt.
ale może będzie miała akademik. (szukamy w Pradze, Brnie i innych miastach)
Nie jesteśmy już daleko od Pragi, mamy samochód, jesteśmy gotowi częściowo opłacić zakwaterowanie.
miasto lub wieś – to nie ma znaczenia, najlepiej, żeby było to osobne mieszkanie.
Kliknąłem coś w vodafone i połączyłem dwie niepotrzebne promocje, na które zostały pobrane środki i nie mogę ich wyłączyć 😭
a pieniądze zostały pobrane z karty, na której nie było pieniędzy
i nie rozumiem, dlaczego pieniądze zostały pobrane
Koszty naprawy pokrywa właściciel = Pan Dedina. Powinien pojawić się we wtorek.
We wtorek bądź w domu i czekaj na fachowca.
Czy mogę prosić o jednego papierosa?
Czy możemy zmienić taryfę komórkową, jeśli masz czas? Czy jest już na to za późno?
USA zakazuje inwestycji w Federacji Rosyjskiej i nakłada sankcje na córki Putina.
Stany Zjednoczone wspólnie z G7 i UE wprowadzają nowe sankcje wobec córek prezydenta Rosji, Putina, największych rosyjskich banków Alfa Bank i Sberbank oraz zakazują wszelkich nowych inwestycji w Rosji.
Podano to w komunikacie na stronie internetowej Białego Domu.
Sberbank jest największą rządową instytucją finansową w Rosji, a Alfa-Bank jest największym bankiem prywatnym.
Sankcje zamroziłyby wszystkie ich aktywa, które mają wpływ na system finansowy USA i zakazałyby obywatelom USA prowadzenia z nimi interesów.
Ponadto USA wprowadzi całkowity zakaz nowych inwestycji w Federacji Rosyjskiej.
W tym celu prezydent USA, Joe Biden podpisze nowy dekret, który zawiera zakaz nowych inwestycji w Rosji przez obywateli USA niezależnie od ich lokalizacji.
„Ten krok opiera się na decyzji ponad 600 międzynarodowych firm o wycofaniu się z Rosji. Wyjście sektora prywatnego obejmuje producentów, firmy energetyczne, dużych detalistów, instytucje finansowe i innych usługodawców, takich jak firmy prawnicze i konsultingowe.” - Biały Dom poinformował w oświadczeniu.
Trzecim krokiem nowych sankcji ze strony USA są restrykcje wobec dużych rosyjskich przedsiębiorstw państwowych w strefie krytycznej.
Zabroniłoby to obywatelom USA zawierania transakcji z tymi podmiotami i zamroziłoby wszelkie ich aktywa w jurysdykcji Stanów Zjednoczonych.
Ministerstwo Finansów opublikuje szczegółowe zestawienie następnego dnia, w czwartek.
Ostatnia część pakietu to całkowite zablokowanie majątku pełnoletnich dzieci Putina, żony i córki ministra spraw zagranicznych Ławrowa, a także członków Rady Bezpieczeństwa Rosji, w tym byłego prezydenta i premiera Rosji Dmitrija Miedwiediewa oraz premiera Michaiła Miszustina.
Sankcje odcięły ich od amerykańskiego systemu finansowego i zamroziły wszelkie aktywa, które posiadają w Stanach Zjednoczonych.
Możesz dostać się tylko do tego miejsca, później droga jest zamknięta i przyjadę do Ciebie.
Vera, możemy myć naczynia w zmywarce?
Mam na imię Olga, przed wojną pracowałam jako stewardessa dla SkyUp, moja matka jest szwaczką wyrobów przemysłowych, mój syn Makarchyk poszedł do przedszkola 
Pięknie nam się żyło, ale nawet nie myśleliśmy o tym, że będziemy zmuszeni do ucieczki, bo nie mieliśmy już siły ukrywać się w piwnicy.
Miałam szczęście znaleźć pracę w Pradze w Czechach.
Dlatego mamy nadzieję, że ktoś udzieli nam schronienia na początek) Możemy nawet zapłacić za pokój lub mieszkanie, ale tylko jeśli nas na to stać.
Gwarantujemy czystość i porządek.
Nie mamy złych nawyków.
Będziemy wdzięczni za taką pomoc w tak trudnym dla nas czasie.
Po obiedzie miałem jeden wykład z angielskiego, a potem poszedłem do pracy w pokoju dziecięcym.
Wyjaśniłem tam Margaricie, jak wypełnić wszystkie dokumenty.
Mam nadzieję, że zrozumiała wszystko i wszystko zrobi dobrze.
Spotkałem też panią Lenę i rozmawiałem z nią o pływaniu dla ukraińskich dzieci.
Przyniosła ogłoszenie z basenu.
To darmowe pływanie.
Możesz zadzwonić do szkoły? Kira nie odbiera telefonu, nie odpowiada, nie wiem czy dotarła do szkoły.
Izolują rosyjskie biuro: wstrzymują inwestycje i odcinają dostawy.
Jednakże, nie zrozumieliśmy się.
Wojsko nie zapuściło korzeni w naszym domu.
Nasz dom położony jest w pobliżu jednostki wojskowej i składu ropy naftowej
Pomógł mi tylko dlatego, że sama bym tego nie zrobiła.
Pysznie gotuję, nie proszę o zbyt wiele i daję dobre rady.
Mam się dobrze.
Jest to dla mnie trochę trudne, ale rozumiem, że muszę przejść przez ten etap.
Spotkamy się w czwartek i wszystko ci opowiem.
Ogólnie, wszystko jest dobrze.
Gulya, jak często sprzątasz?
Sprzątam co tydzień.
Niestety nie mam programu, ale spróbuję to rozgryźć.
Marzyłem, żeby zostać nauczycielem.
Moje dziewczynki nie mogą się teraz nigdzie ruszyć, więc nie pisałam do właściciela domu.
Chciałem was prosić, abyście dali mi znać, jeśli usłyszycie informacje o mieszkaniach.
Chciałbym wynająć mieszkanie z porządną dziewczyną.
Jeśli coś wiesz, daj mi znać.
Z mojej strony - nie zawiodę.
Z góry dziękuję.
Nie pisałem do Ciebie o jeszcze jednej osobie – Natalii, 54 lata. Proszę, podaj mi dokładny adres i ile kosztują kursy.
Myślę, że lepiej zrobić kopie naszych paszportów, mają wszystkie informacje.
Nie zmieniłem nazwiska, jest takie same od urodzenia.
Dzień dobry, panie Reirard! Przepraszam, nie widziałem tego. Zrobię to teraz i od razu Ci wyślę.
Pójdziemy teraz na komisję lekarską.
Oznacza to, że Anya musi odpracować tę godzinę innego dnia.
W jakim dniu powinna przyjść wcześniej? (Może w dzień, w który jest trochę więcej pracy?)
Reszty posłucham jutro, internet nie działa dobrze. Dobranoc
Co zamierzasz teraz zrobić?
Dziękuję.. znaleźliśmy trochę rzeczy, ale nie było sprzętu…
Obaj są początkujący i nie znają nic poza alfabetem.
Nic się nie dzieje.
Czy jest to możliwe w poniedziałek, 25 kwietnia?
Możesz zabrać dzieci ze sobą, jest tutaj wystarczająco zabawek.
Zgadłem na temat taty.
Muszę być bardzo naiwny lub bardzo zakochany, ale zrobię coś z tymi pieniędzmi.
Jakoś to zrobimy.
Ale jak to będzie spłacane? Proszę, bez żadnych pożyczek.
Napisz do mnie bezpośrednio, a pomogę.
Jestem twoim partnerem lub nie jestem twoim partnerem.
Już nie wiem.
Czy muszę wziąć ubrania, które mi dano?
Dziś nie jest mój dzień. Żaluzje w salonie były zepsute. Jedna rano. Kolejna – teraz wieczorem
Dostałem coś od ciebie, nie wiem co
Jestem też bardzo smutny.
O fakturze przypomnę później
Czy twój ojciec jest jedyną osobą, która mówi i rozumie rosyjski?
W jaki dzień kolega chce posprzątać dom i ile okien ma ten dom?
Przepraszam, że odciągam cię od twoich zajęć
Dobry wieczór, nie mogę się z wami tym nie podzielić. Nadeszły wieści z Mariupola o synu – żyje i jest w wojsku.
Radzę Ci przeczytać Joe Dispenza, naukowo prowadzi eksperymenty nad wpływem czynników zewnętrznych i tworzeniem nowych połączeń neuronowych
Rankiem 12 kwietnia dziennikarka kanału telewizyjnego „1+1” Natalia Górna udostępniła nagranie wideo, które otrzymała od żołnierzy 36. Brygady Piechoty Morskiej z Mariupola.
Żołnierze mówią w nim, że nie mają już broni do udziału w bitwach, a rannych jest wielu.
Mówili, że „liczy się każda godzina”.
Wcześniej, 11 kwietnia, 36. oddzielna brygada piechoty morskiej, która bierze udział w obronie Mariupola, opublikowała apel do Ukraińców w języku rosyjskim.
W oświadczeniu stwierdzono, że 11 kwietnia może być ostatnia bitwa dla obrońców Mariupola, a ukraińskie dowództwo wojskowe nie kontaktowało się z bojownikami od dwóch tygodnia.
Ludzie byli sceptyczni w sieciach społecznościowych, ponieważ apel został opublikowany w języku rosyjskim.
Naczelny Dowódca Sił Zbrojnych Ukrainy Walerij Załużnyj zapewnił, że dowództwo komunikuje się z siłami obrony w Mariupolu, a szczegóły operacji obronnej nie powinny być przedmiotem publicznej dyskusji.
Rosjanie zagrozili zablokowaniem ukraińskich bojowników na terenie zakładów Azowstal w Mariupolu i użyciem przeciwko nim broni chemicznej.
Wieczorem 11 kwietnia rosyjscy okupanci zrzucili na Mariupol trującą substancję niewiadomego pochodzenia.
Jak poinformował przywódca „Azova” Andriya Biletsky, armia rosyjska użyła broni chemicznej w fabryce „Azovstal”, która jest kontrolowana przez bojowników pułku „Azow”.
Dziękuję, dostosuję się do Ciebie. Tak byłoby bardzo dobrze.
Sytuacja jest taka sama, na razie zostajemy tutaj
2 godziny jazdy )) spaceruje, mama idzie na zakupy i z powrotem)
To nie jest ważna sprawa
Zapomniała, co tu zrobić
Nad Ukrainą 🇺🇦 od dzisiaj zaczęła latać eskadra czeskich 🇨🇿 dronów.
Prawie 50 profesjonalnych śmigłowców🚁 posłuży do wykrywania, a część z nich do bezpośredniego zniszczenia wrogiego najeźdźcy💥.
Dwie osoby z Zakarpacia i dwóch Czechów wysłało przedwczoraj „ptaszki” na Ukrainę za sprawą deputowanego Rady Miejskiej Mukaczewo Wołodymyra Labutenko.
Dziś ich międzygórscy przyjaciele, na czele z przewodniczącym rady wsi i koordynatorem https://www.facebook.com/examplehere101/ Wasylem Shchurem, dostarczyli drony zgodnie z ich przeznaczeniem: trafiły one do jednostek specjalnych wojsk ukraińskich w różnych miastach gdzie obecnie trwają działania wojenne.
Aby jak najefektywniej i jak najbezpieczniej korzystać ze śmigłowców, na razie zachowamy ich lokalizację w tajemnicy.
Czterech przyjaciół, którzy pomagają armii ukraińskiej z Czech, nie planuje na tym poprzestać, jak mówią: w najbliższych dniach na Ukrainę zostanie wysłanych o wiele więcej ciekawych „prezentów”, które posłużą do zniszczenia rosyjskiego okupanta i ratowania życia ukraińskich bohaterów.
Nie martw się, wszystko jest w porządku. Uwielbiam słodycze, ale mogę się bez nich obejść
Martwię się, że nie damy rady. Mamy dużo bagażu.
Wkrótce wrócę na Ukrainę, aby kontynuować pracę
Świetnie. Jeśli wszystko będzie w porządku, zgodzę się
Spróbuję sam, ale jeśli będą jakieś problemy, napiszę do ciebie, jeśli to możliwe?
Najważniejsze jest wzajemne zrozumienie
Byliśmy osobiście u staruszki we wsi Jivov, widziała mnie i to, że jestem w ciąży, ale powiedziała, że nie ma mieszkania.
Może będzie szczęśliwa i poprawi jej się humor
Oddałem dzisiaj telefon do naprawy.
I chyba dzisiaj też zmarzłam na zewnątrz.
Wziąłem lekarstwo i wypiłem herbatę, czuję się gorzej, ale nie tak krytycznie.
Ja też przepraszam, ale lepiej się spotkać jak będę zdrowy.
Jak będziesz mieć czas, wyślij mi muzykę, którą lubisz.
Jestem ciekawy twoich muzycznych preferencji 😊
mama i tata muszą być posłuszni
Znajdziesz to gdzieś w pobliżu wózka Twojego młodszego brata.
U nas dzisiaj było chłodniej i padał deszcz. Jutro powinno być ciepło.
Ale to nie zniszczone domy, ale ludzie, z których wyśmiewają się okupanci, to jest dla mnie smutne
W Chersoniu okupanci kpili z pomnika „Chwała Ukrainie” w Chersoniu przy ulicy Perekopskiej.
Szczegóły: Nieznane osoby zerwały flagę Unii Europejskiej, wypatroszyły tablice ze zdjęciami Niebiańskiej Sotni i poległych w wojnie rosyjsko-ukraińskiej.
Okupanci zburzyli portrety bohaterów Niebiańskiej Sotni i poległych uczestników wojny rosyjsko-ukraińskiej.
Flaga została zdjęta.
Dzień dobry, dziękuję dzieciom za kolędę, my nie mamy takiego zwyczaju, dlatego o tym nie wiedzieliśmy, daliśmy dzieciom tylko czekoladę i ciastka, może trzeba było dać coś innego.
Jeśli potrzebujesz, jest ktoś, z kim można porozmawiać w Czechach.
Bo mieszkam w hostelu. Będą tu ludzie do dwunastej, a potem idą do pracy.
Cześć, już jest trochę lepiej.
Był już dzisiaj w żłobku.
Nawet tam dzisiaj spał.
Dlatego zrobiliśmy już duży postęp.
Na pewno przyniosę pierogi innym razem!
Nie mam siły dzisiaj ich robić
Ponieważ zależy to od dni i godzin, w których odbywa się sprzątanie apartamentów po gościach, mogę z grubsza powiedzieć że to będzie kwiecień, ponieważ mam już przybliżony harmonogram sprzątania apartamentów.
W maju - z grubsza powiem koniec kwietnia lub początek maja.
Zapytałem tylko, czy coś o tym powiesz..
Cześć, przepraszam, że nie odpisywałam długi czas, gotowałam obiad i trochę spałam.
Jeśli nadal nie masz nic przeciwko, czy mógłbym dzisiaj przyjść?)
lub spotkamy się po Twoim przyjeździe)
Jest skromny, ostatnio dużo się uczy. Uświadomił sobie, że naprawdę potrzebuje tego w swoim życiu
Witam) wszystko poszło bardzo dobrze.
Byłam w lekkim szoku, że pracuję z ludźmi na tak wysokim stanowisku.
Dzisiaj miałem lekcję z panią, która jest dyrektorem Wydziału Ekonomicznego Regionu Vysočina.
Była bardzo zadowolona z mojej pracy.
Grishko dobrze zachowywał się w żłobku.
W poniedziałek muszę wnieść potwierdzenie zatrudnienia i płatności gotówkowych za żłobek.
Jestem leniwy od piątku
Nic nie robię, tylko dużo jem i śpię😂 (i piję dużo wody☝🏻)
Jeśli idziesz jutro do lekarza, chciałbym iść z Tobą, jeśli to możliwe.
Muszę przynieść kolejny test.
więc nie będę musiał iść ponownie
Odpływ nie działa dobrze, nie spłukuje dobrze. Potrzebny jest fachowiec. Konieczna jest naprawa.
Tak, niczego im nie brakuje
Czy możesz mi wysłać poprawny adres e-mail?
Chcę wysłać Ci zaproszenie na kurs języka czeskiego, na który się zapisałeś.
Dzieci są tam karmione czy muszą przynosić jedzenie ze sobą?
Teraz mogę na chwilę do was przyjść, mam jedno pytanie
Jeśli znowu potrzebujesz pomocy, napisz do mnie.
Jeśli się nie mylę, obchodzicie dziś Wielkanoc, prawda?
Od samego początku tak naprawdę nie chcieliśmy, żebyś zbierał fundusze, żeby ludzie nie myśleli, że spekulujemy na ten temat!
Ale brakowało mi dwóch punktów do wypełnienia tego online:
Pójdę odpocząć. Zyskać siłę i energię. Dziękuję za dzisiejszy prezent. Dobranoc
😄😍 świetny pomysł. Teraz obejrzę filmik. Będzie dobrze, bo cała rodzina będzie rysować.
Karazin University apeluje do pracowników i studentów o uważne sprawdzanie wszystkich informacji, nieufanie anonimowym źródłom w komunikatorach i sieciach społecznościowych oraz plotkom.
Polegaj tylko na oficjalnych informacjach.
Tak, możesz na mnie liczyć, dziękuję!
Mój inny brat, który wyjechał z Ukrainy też pomaga armii.
Zamieściłam kilka prac w portfolio.
Internet powinien być założony po wakacjach.
Chciałbym być twoim zapasowym projektantem.
Jak będę rozliczony za dzień, w którym nie byłem w pracy? Mam zwolnienie.
Kwatera główna: Rosja przygotowuje prowokację w Naddniestrzu, żeby obwinić Ukrainę
Rosyjska armia może uciekać się do prowokacji w regionie Mołdawii, Nadniestrzu żeby oskarżyć Ukrainę o „agresję na sąsiednie państwo”.
Dosłownie: „Nie jest wykluczone, że siły zbrojne Federacji Rosyjskiej przeprowadzą prowokacyjne akcje na terytorium regionu Republiki Mołdawii, Naddniestrza w celu oskarżenia Ukrainy o agresję na sąsiednie państwo”.
Szczegóły: Wróg nadal formuje ofensywną grupę wojsk do operacji w kierunku Słobożańska.
Prawdopodobnie w najbliższych dniach okupanci spróbują wznowić ofensywę.
Ponadto wróg nadal szkoli i wysyła personel, broń i sprzęt do udziału w działaniach wojennych na terytorium Ukrainy.
Uzbrojenie i sprzęt wojskowy są przygotowywane w stałym punkcie rozmieszczenia 60. Samodzielnej Brygady Strzelców Zmotoryzowanych (Monastyryszcze) 5. Armii Połączonej Armii Wschodniego Okręgu Wojskowego.
Przypuszczalnie, określona broń zostanie przeniesiona na czasowo okupowane terytorium obwodu donieckiego.
Również w celu odbudowania strat osobowych jednostek batalionowej grupy taktycznej z 36. samodzielnej brygady zmechanizowanej (Borzya, obwód zabajkalski) 29. Armii Połączonej Armii Wschodniego Okręgu Wojskowego, żołnierze wspomnianej brygady będą rekrutowani.
Wróg odczuwa szczególny problem przy obsadzaniu stanowisk kierowców i mechaników.
Wyjazd zrekrutowanej kadry z miejsca stałego rozmieszczenia planowany jest na drugą połowę kwietnia tego roku.
Przypuszczalnie wróg, aby zakłócić dostawy towarów na pola bitew, będzie kontynuował ataki na obiekty infrastruktury transportowej na terytorium Ukrainy w celu ich zniszczenia lub wyłączenia.
Niektóre jednostki Sił Zbrojnych Republiki Białorusi nadal realizują zadania wzmacniające ochronę granicy ukraińsko-białoruskiej w obwodzie brzeskim i homelskim.
W kierunku Słobożańska oddzielne jednostki 6. Armii Połączonej i Sił Nadbrzeżnych Floty Północnej nadal częściowo blokują miasto Charków, a ostrzał artyleryjski niektórych obszarów miasta nadal trwa.
W kierunku Izyumu trwa rozpoznanie terenu z powietrza w celu zidentyfikowania pozycji Sił Zbrojnych Ukrainy.
W tym celu przeciwnik wykorzystuje UAV Orlan-10.
Siłami dwóch batalionowych grup taktycznych wróg próbował przeprowadzić ofensywę w kierunku osad Dovgenke i Dmytrivka, ale było to bezskuteczne i wycofał się na wcześniej okupowane pozycje.
W kierunku Doniecka wróg nadal koncentruje się na przejęciu osad Popasna, Rubiżne, Nyżnie i Nowobachmutiwka oraz na przejęciu pełnej kontroli nad miastem Mariupol.
Wróg próbował przeprowadzić szturm w pobliżu Zolote, ale bezskutecznie.
W mieście Mariupol przy pomocy artylerii i lotnictwa okupanci kontynuują szturm na tereny zakładów Azovstal i portu morskiego.
Siłami oddzielnych oddziałów nieprzyjaciel przeprowadził ostrzał artyleryjski pozycji wojsk ukraińskich w rejonie osad Visokopillya, Trudolyubivka i Maryanske.
Na terytorium obwodów donieckiego i ługańskiego obrońcy Ukrainy w ciągu ostatniej doby odparli cztery ataki wroga, zniszczyli pięć czołgów, osiem pojazdów opancerzonych, sześć samochodów i osiem systemów artyleryjskich wroga.
Nie zrozumiał twoich przemyśleń?
Na pewno spróbujemy to zrobić, ale wątpię
A co z tobą? Może chcesz spać a ja cię opóźniam.
Jesteś pewien, że nie masz nic przeciwko temu, żebym przyszedł?
Może po prostu nie chcesz się dzisiaj spotkać, powiedz mi, wszystko zrozumiem)
Dziękuję. Nie oglądaliśmy telewizji w domu, nie mówiąc już o 1+1. Nie musimy go konfigurować :)
Włączę tu telewizję tylko po to, by słuchać czeskiego.
Mój miesięczny pakiet taryfowy kończy się dzisiaj
Czy możemy to zrobić dzisiaj przez telefon?
Kupię tkaninę do haftu, płótno, nici do haftu
Rozumiem, wtedy mogę przygotować materiał z tego zakresu.
Zapytam ją. Trochę wstydzę się zapytać, ona daje nam już tyle ciast.
Mój ojciec i ja spotkamy się później, na pewno 🙏🏻
Przeczytałem ogłoszenie na Facebooku, chyba Google napisało coś od siebie🏵️, myślę, że wystarczy numer telefonu
Dzień dobry, wzieliśmy, które przyniosłeś, ale są tu ubrania, które są dla nas za małe. Możemy je do Ciebie przynieść za 10 minut?
Myślałem o pracy.
Jeśli dyrektorowi to odpowiada, to w przyszłym tygodniu mogę zacząć chodzić do pracy, ponieważ jutro przed obiadem idę do urzędu pracy złożyć dokumenty (o ile mi się uda, bo kolejki są bardzo długie), w sobotę będzie padać deszcz
Szukam zespołu na początek, w szkole bardzo lubiłam chemię, uczę się języka czeskiego, żeby znać go perfekcyjnie, marzę o pracy w Teva
Starzy i nie tak starzy przyjaciele, przyjaciele, których nie znam osobiście, przyjaciele ducha i umysłu
Ciężkie czasy nastały także dla Was.
Przez ostatni miesiąc komunikowałem się z wieloma z was.
Jak życie każdego Ukraińca, wasze, nigdy łatwe, zostaje całkowicie wywrócone do góry nogami.
Wielu z was ucieka z Rosji.
I wielu z was wyraziło poczucie winy lub wstydu z powodu tego, co wasz kraj robi waszemu sąsiadowi.
Nad tym, co dzieje się z Ukrainą w waszym imieniu.
Niektórzy z was, aktywiści, od dawna są pod młotkiem i przygotowują się do ostatecznego uderzenia.
Na początku marca napisałem do Oleksandra Czerkasowa, mojego bardzo starego przyjaciela z „Memoriału”.
,,Powiem ci trochę później'', odpowiedział Sasha swoim zwykłym lakonicznym tonem. ,,Teraz, po poszukiwaniach wędrujemy wśród ruin''.
Inni spośród was, przedstawiciele kultury, artyści, krytycy, pisarze, są wstrząśnięci nagłym upadkiem waszego kruchego świata.
Nikt z was nie lubi Putina i jego reżimu złodziei i faszystów, większość z was ich nienawidzi.
Ale bądźmy szczerzy: poza bardzo nielicznymi z Was – pracującymi dla „Memoriał”, „Nowaja Gazieta”, „Echo Moskwy”, „Meduzy”, organizacji Nawalnego i garstki innych – ilu z was kiedykolwiek zrobiło cokolwiek, by stawić opór reżimowi?
Poza być może uczestniczeniem w demonstracjach, gdy takie były?
Przeczytajcie także felieton rosyjskiego dziennikarza „Za późno na ukrywanie się, za późno na milczenie”
Czy to możliwe, że wasze poczucie wstydu i winy nie jest abstrakcyjne?
Czy może wynikają one również z waszej wieloletniej obojętności na to, co dzieje się wokół was, waszej apatii i biernego współudziału, które teraz z pewnością obciążyły wasze dusze i serce?
Nie zawsze tak było.
Przez jakiś czas, jeszcze w latach 90., mieliście pewną dozę wolności i demokracji, chaotyczną, nawet krwawą, ale prawdziwą.
Ale rok 1991 okazał się wcale nie lepszy od 1917.
Dlaczego za każdym razem, gdy w końcu macie rewolucję, tak bardzo boicie się „czasu kłopotów”, że od razu wbiegacie pod spódnicę cara, bez względu na to, czy nazywa się on Stalin, czy Putin?
Bez względu na to, ilu zabije, wydaje wam się to bezpieczniejsze. Dlaczego?
To prawda, popełniono błędy.
Zamiast napadać na archiwa KGB i wystawiać je na światło dzienne, jak Niemcy zrobili ze Stasi, pozwoliliście rozproszyć się pomnikowi Dzierżyńskiego i pozwoliliście KGB się ukryć, przegrupować, odbudować i przejąć wasz kraj.
Kiedy staliście przed wyborem między grabieżą kraju a powrotem komunistów, nie walczyliście o narzucenie trzeciego wyboru i zgodziliście się na grabież.
W 1998 wasza gospodarka się załamała i to był właściwie koniec masowych demonstracji na rzecz większej sprawiedliwości społecznej lub przeciwko wojnie w Czeczenii.
Głównym problemem stało się przetrwanie.
Potem sprowadzili Putina. Młody, odważny, agresywny, obiecujący zniszczenie terrorystom i zwrot gospodarczy.
Niewielu z was to kupiło, ale i tak albo na niego głosowaliście, albo nie głosowaliście wcale.
Kiedy po raz drugi zaczął zrównywać z ziemią Czeczenię, większość z was zamknęła oczy.
Dobrze wspominam te lata.
W tym czasie pracowałem w Czeczenii, pomagając ofiarom „operacji antyterrorystycznej” Putina i widziałem na własne oczy ruiny Groznego, Katar-Yurta, Itum-Kala i innych miast.
Czasami wracałem do Moskwy na przerwę i imprezowałem z wami, przyjaciele.
Piliśmy, tańczyliśmy, a czasem próbowałem opowiadać o okropnościach, których byłem świadkiem: torturowanej ludności cywilnej, mordowanych dzieciach, żołnierzach, którzy sprzedawali ciała zmarłych rodzinom.
Mówiliście mi: „Bred, mamy dość twojej Czeczenii”. Bardzo dobrze pamiętam te słowa.
W odpowiedzi wściekałem się na was: „Chłopaki, to nie jest moja Czeczenia, to jest wasza Czeczenia.
To wasz kraj, do cholery, nie mój.
Ja jestem tu tylko głupim obcym.
To wasz rząd bombarduje jedno z waszych miast, zabijając współobywateli”.
Ale nie, to wszystko było zbyt skomplikowane, zbyt bolesne, a wy nie chcieliście nic wiedzieć.
Potem przyszedł boom gospodarczy połowy lat 2000, napędzany rosnącymi cenami ropy i gotowością Putina, by część skradzionych pieniędzy spłynęła kaskadą do klasy średniej.
Wielu z was zaczęło dobrze zarabiać, niektórzy się wzbogacili, a nawet ci biedniejsi z was dostali nowe mieszkania i lepszą pracę.
Ceny rosły, ale czy to był problem?
Moskwa była rozpalona, błyszcząca, szykowna.
Kiedy zabitych zostało kilku opozycjonistów – Jurij Szczekoczikhin, Anna Politkowska, Oleksandr Litwinienko i inni – wielu z was było wstrząśniętych i wyrażało przerażenie z powodu tego, co się dzieje.
Jednakże to ledwo poszło dalej.
Kiedy po dwóch kadencjach Putin przekazał prezydenturę Miedwiediewowi, a sam objął stanowisko premiera, o ile mi wiadomo, ledwie to zauważyliście.
Kiedy Rosja najechała Gruzję kilka miesięcy po prezydenturze Miedwiediewa, większość z was zignorowała to lub milczała.
A ilu z was spotkałem po latach na stokach narciarskich Gudauri, u podnóża Kazbegi lub w kawiarniach i łaźniach parowych Tbilisi, kiedy część tego kraju była okupowana przez wasze wojska?
Muszę przyznać, że my, tu na Zachodzie, też nie zrobiliśmy wiele, jeśli w ogóle nic.
Kilka skarg, kilka sankcji; ale czym były rażące naruszenia prawa międzynarodowego w porównaniu z urokiem rosyjskiej ropy, gazu i rynku wewnętrznego?
Było dobrze mieszkać w Rosji.
A po trudnych latach 90. to było najważniejsze.
Jednak pod koniec 2011 roku wy, moi rosyjscy przyjaciele, obudziliście się.
Kiedy Putin ponownie zamienił się miejscami z Miedwiediewem, od razu siadając z powrotem na fotelu prezydenta, wielu z was zdecydowało, że to o jeden brudny trik za dużo, i masowo wyszliście protestować.
Nazwisko Nawalnego stało się powszechnie znane, przez pół roku nie schodziliście z ulic, w końcu zastraszając reżim, popychając go na piętach.
Potem to się powtórzyło.
Najpierw zorganizowano kontrdemonstracje; następnie uchwalono bardziej represyjne prawa i zaczęto wypełniać więzienia.
Tysiące skończyło w więzieniu.
Niektórzy dostali bardzo długie wyroki.
I co możemy zrobić?
Słyszałem to tak często i słyszę to nadal.
Państwo jest takie silne, a my tacy słabi.
Cóż, spójrzcie na Ukraińców.
Popatrz co oni zrobili dwa lata temu.
Kiedy zajęli Majdan, wściekli na prorosyjskiego prezydenta, który zdradził obietnicę większej Europy, nigdy go nie opuścili.
Sami zbudowali miasteczko namiotowe i przygotowali się do decydującej obrony.
Kiedy przyjechała policja i próbowała ich rozbić, ci odpowiedzieli kijami, żelaznymi prętami i koktajlami Mołotowa.
W końcu policja otworzyła ogień.
Ale zamiast uciekać, protestujący zaatakowali.
Wielu zginęło, ale wygrali.
To Janukowycz kandydował, ale Ukraińcy odzyskują demokrację, prawo do wybierania swoich przywódców i wyrzucania ich, gdy nie wykonują swojej pracy.
Putin naprawdę nie polubił Majdanu.
To był zły przykład.
Więc zabrał Krym, kiedy wszyscy byli jeszcze wytrąceni z równowagi.
Niektórzy z was protestowali, ale bezskutecznie.
Tak wielu było zachwyconych!
O ile mi wiadomo, 91% Rosjan zaakceptowało aneksję.
Nagle pojawił się nowy mit i niektórzy z was, którzy gardzili Putinem i jego kliką, nagle odwrócili się i zaczęli go czcić.
Nie wiem dlaczego, ponieważ po tym szybko przestaliśmy rozmawiać.
Reszta tych, którzy pozostali moimi przyjaciółmi, przeważnie milczała.
„Nie interesuje nas polityka” – powiecie.
I wrócilibyście do literatury, filmów, katalogów IKEA lub nowiutkich parków po renowacji rozpoczętej przez burmistrza Moskwy w 2012 roku – z ich pufami, darmowym Wi-Fi i hipsterskimi kawiarniami.
Tak, Donbas był daleko, a Moskwa była fajna i stawała się coraz fajniejsza.
Ledwo zauważyliście Syrię.
Tam byli terroryści, prawda?
Daesh czy cokolwiek... Nawet moskiewski redaktor, który opublikował moją książkę o Syrii potem skrytykował ją w wywiadzie, mówiąc, że nic nie rozumiem z tego, co dzieje się w Syrii.
Cóż, ja przynajmniej tam byłem i obserwowałem, jak dzieci w wieku moich dzieci są rozstrzeliwane z zimną krwią przez reżimowych snajperów na ulicach Homs.
Jedynymi Rosjanami, którzy tam pojechali, była wasza armia, która w 2015 roku zaczęła bombardować tysiące cywilów i ćwiczyć przed kolejną poważną wojną.
Z pewnością wielu z was zna słowa pastora Martina Niemellera:
„Najpierw przyszli po socjalistów, a ja się nie wypowiadałem – bo nie byłem socjalistą. Potem przyszli po związkowców, a ja się nie wypowiadałem – bo nie byłem związkowcem. Potem przyszli po Żydów, a ja się nie wypowiadałem – bo nie byłem Żydem. Potem przyszli po mnie – i nie było już nikogo, kto by się za mną opowiedział”.
Ilu z was opowiedziało się za Czeczenami, Syryjczykami czy Ukraińcami?
Niektórzy z was to zrobili.
Ale zbyt wielu było cicho.
Niektórzy, co prawda, już teraz zabierają głos, jak na przykład Dmytro Głuchowski, Mychajło Szyszkin, Mychajło Żyhar, Maksym Osypow i inni.
Większość mówi spoza kraju, nieliczni z wewnątrz, jak Marina Ovsyannikova, ryzykując wysłanie do nowego Gułagu lub dołączenie do Nawalnego.
Jeśli chodzi o resztę z was, rozumiecie kraj, w którym żyjecie, lepiej niż większość.
Jestem więc pewien, że rozumiecie to: kiedy Putin skończy z Ukraińcami – a tym bardziej, jeśli nie będzie w stanie ich wykończyć, co wydaje się prawdopodobne – przyjdzie po was.
Dla Was wszystkich, przyjaciele: dla tych, którzy odważnie, ale przeważnie indywidualnie wyszli protestować i na razie dostali tylko łagodne wyroki, ale wkrótce dostaną dużo surowsze.
Dla tysięcy z Was, którzy podpisali petycje, wyrazili swoją dezaprobatę na portalach społecznościowych (może tylko czarnym kwadratem na Instagramie) lub prywatnie rozmawiali ze swoimi kolegami z pracy.
Czasy, w których za żart dostawało się dziesięć lat pozbawienia wolności, a nawet dwadzieścia pięć, nie należą już do przeszłości, a teraz najprawdopodobniej należą również do przyszłości.
Kto wtedy będzie przemawiał w waszym imieniu? Kto zostanie?
Ukraińcy, teraz jeszcze bardziej niż w 2014 roku, dają przerażający przykład reżimowi Putina: pokazują, że można z nim walczyć.
I że jeśli ktoś jest sprytny, zmotywowany i odważny, może go nawet powstrzymać, bez względu na jego przytłaczającą przewagę na papierze.
Najwyraźniej prawie nikt w Rosji nie wie o tym, a nawet o tym, że trwa wojna.
Ale wy, moi przyjaciele, dobrze wiecie, co się teraz dzieje.
Czytacie zagraniczne wiadomości w Internecie, macie przyjaciół, a nawet krewnych na Ukrainie, do których piszecie.
A Putin wie, że wy wiecie.
Więc uważajcie.
Wiecie, dokąd to zmierza.
Dni dobrego życia w zamian za twoje milczenie już się skończyły.
Twoje wybory to żart, twoje prawa, z wyjątkiem tych represyjnych, nie są warte papieru, na którym są spisane, twoje ostatnie wolne media przepadły, twoja gospodarka upada szybciej, niż jestem w stanie napisać, nie masz już nawet kart kredytowych do zakupu biletu lotniczego, jeśli zostały jeszcze jakieś loty.
Teraz Putin nie będzie chciał tylko waszego milczenia, będzie chciał waszego przyzwolenia, waszego współudziału.
A jeśli nie dacie mu tego, czego chce, możecie albo spróbować jakoś odejść, albo zostać zmiażdżonym.
Wątpię, żebyście widzieli inny wybór.
A jednak jest jeden.
Który ma ostatecznie obalić ten reżim.
W obecnej sytuacji prawdopodobnie zajęłoby to mniej niż myślicie.
Pomyślcie o tym.
Iskra nie przyjdzie od was: wraz z załamaniem gospodarczym, które ma dotknąć Rosję, najprawdopodobniej przyjdzie z prowincji, z mniejszych miast.
Kiedy ceny wzrosną, a pensje nie zostaną wypłacone, ludzie, którzy przez te wszystkie lata głosowali na Putina, bo chcieli chleba i pokoju, wyjdą na ulice.
Putin wie o tym i boi się tych ludzi o wiele bardziej niż intelektualistów i klasy średniej z Moskwy i Petersburga, czyli was, moi przyjaciele.
Ale jeśli każde miasto demonstruje na własną rękę, jak to już się czasami zdarzało, nie będzie mu trudno stłumić je jedno po drugim.
To musi być skoordynowane, zorganizowane. Tłum musi zmienić się w masę.
Macie to wspaniałe i magiczne narzędzie zwane Internetem, któremu reżim może przeszkadzać, ale które wciąż działa i może zostać naprawione niezależnie od prawie każdych okoliczności.
Organizacja Nawalnego została rozwiązana, ale można tworzyć inne, bardziej nieformalne, bardziej zdecentralizowane.
Jest was bardzo dużo, są was miliony.
Moskiewska policja może poradzić sobie na ulicach miasta z 30 tysiącami ludzi, może setką tysięcy.
Jeśli okaże się, że byłoby to więcej niż 300 tysięcy, byliby przytłoczeni.
Musieliby wezwać armię, ale czy ta armia będzie walczyć dla Putina, kiedy do tego dojdzie?
Po tym wszystkim, co im kazał zrobić na Ukrainie, po wszystkim, przez co musieli przejść?
Będzie oczywiście straszne niebezpieczeństwo.
Wielu z was poczuje zrozumiały strach; ci, którzy mają dzieci, będą się o nie bali.
I to jest naturalne, normalne.
Na waszym miejscu też bym się bał.
Na przykładzie Syrii, a teraz Ukrainy, Putin starał się pokazać, co dzieje się z tymi, którzy ośmielają się sprzeciwić swojemu panu, którzy ośmielają się nie tylko prosić o wolność, ale faktycznie próbują ją odebrać.
Jednak jeśli nic nie zrobicie, wiele istnień nadal będzie zmarnowanych.
Twój syn zażartuje na czacie gry komputerowej – i zostanie aresztowany; twoja córka wyrazi swoje oburzenie w Internecie – i zostanie aresztowana; Twój bliski przyjaciel popełni błąd – i umrze w wilgotnej celi pod pałkami policji.
Tak dzieje się od wielu lat – i będzie się tylko nasilać, nabierając coraz większej skali.
Więc nie macie wyboru. Jeśli nic nie zrobicie, wiecie, jak to się skończy.
Zachowajcie spokój, myślcie strategicznie i znajdźcie sposób, aby to osiągnąć.
Poszliśmy na zajęcia w piątek, powiedziano nam, że możemy przyjść w poniedziałek
Będziemy w domu wieczorem.
To, że traktujesz mnie jak rzecznika prasowego
Vika, jak często chodzisz na kolację do drogiej restauracji?
raz w roku idę na kolację do drogiej restauracji
postaram się jej wszystko wytłumaczyć)
Podobało nam się, jest naprawdę dobre i chcieliśmy czegoś bliżej, więc to jest najlepsza opcja
Byłem w pokoju, w którym było dużo ludzi. Byłem zmęczony energetycznie.
Źle się czuję, mam kaszel, gorączkę, straciłem głos, jestem osłabiony i mam zawroty głowy
Muszę iść do tego urzędu pracy
Już to zrobiliśmy, ale powiedzieli, że ci, którzy zarejestrowali się w kwietniu, dostaną pieniądze dopiero pod koniec miesiąca
Potrzebujemy zwolnienia na czwartek, idziemy z dziećmi do lekarza.
Ale jedna pani napisała do mnie zeszłej nocy, spodobała jej się twoja praca i chciałaby coś od ciebie w jej domu.
Czekam na świeże wieści od niej i na pewno dam znać.
Pracując w prokuraturze wydawało mi się, że buduję karierę, poświęcając na to dużo czasu i wysiłku.
Miałem ciężką psychologicznie, odpowiedzialną, umysłową pracę, w której byłem całkowicie rozczarowany.
Naprawdę żałuję straconego czasu, ale to doświadczenie życiowe.
W życiu osobistym jestem towarzyska, ale jestem monogamiczna i poważnie traktuję sprawy małżeństwa.
Był jeden mężczyzna, którego miałam poślubić, ale zmarł przez problemy z sercem.
Wierzę, że aby stworzyć rodzinę, ludzie muszą się kochać, szanować i ufać sobie nawzajem.
Do tej pory nie spotkałem takiego człowieka.
Dzień dobry. Gdzie w Yihlav mogę kupić formy do pieczenia babki (papierowe lub silikonowe)?
Ok, dziękuję za radę, wpiszę teraz certyfikat Valyi do kwestionariusza
Ma mózgowe porażenie dziecięce, leży, teraz ma złamaną nogę w gipsie, wózek jest w pozycji leżącej, całe jedzenie jest rozgniatane w blenderze
Panie Reichard, przepraszam, że przeszkadzam poza godzinami pracy.
Ale mam do ciebie ważne pytanie.
Spotkałem się dzisiaj z Natalią w pokoju zabaw, żeby się z nią przywitać.
Miała nieprzyjemną sytuację.
Bo gdy dzieci jechały do domu to jedna matka odmówiła zabrania dziecka, bo powiedziała, że przyszła pooglądać rzeczy i poukładać je w tym pokoju z ubraniami, a wczoraj pan Walery otworzył jej pokój naszych dzieci do 19:00
Czy naprawdę tak może być?
Godziny pracy sali są do godziny 16:00.
A przecież to nasza odpowiedzialność.
Ale strona nie ładuje się ani nie otwiera, mój internet jest bardzo słaby
Dzień dobry, u nas wszystko w porządku) Kolya pracuje, wczoraj wypełniliśmy zaproszenia, a ja uczyłem się z seniorami przed egzaminem gimnazjalnym.
Jak dotąd najtrudniejsze jest rozwiązywanie zadań z geometrii.
Wołodymyr pomógł nam w sobotę.
Vika studiuje uniwersytety i programy szkół średnich.
Czy możemy zapłacić za wynajem i za wi-fi?
Jesteśmy bardzo wdzięczni za nocleg
Tak, ale myślałem, że go nie wypełniłeś
Postaramy się zebrać jak najwięcej pieniędzy do końca tygodnia, aby zapłacić
Sytuacja w sprawie rosyjskiej inwazji – odprawa doradcy szefa Kancelarii Prezydenta, Oleksij Arestowicz (10.04.2022)
Doradca szefa Kancelarii Prezydenta mówił o bohaterskim czynie starszego oficera wojsk nadbrzeżnych w Mariupolu – był otoczony i ranny, więc wysadził się w powietrze radiostacją, żeby nie trafiła do wroga.
Mam bardzo ważne pytanie, czy pomogą mi zarejestrować wnuczkę? Ma 5 lat (astma oskrzelowa), teraz ma katar i świszczący oddech…
Potrzebujemy dla niej lekarza rodzinnego, który trochę zrozumie ukraiński lub rosyjski.
Pilnie potrzebujemy konsultacji lekarskiej, bardzo martwimy się o jej stan..
Mieszkamy w Czechach w miejscowości Dolní Chabry. Potrzebujemy lekarza, który jest albo tutaj, w Dolní Chabry, albo gdzieś w pobliżu, może w Brnie, ale niedaleko metra, żebyśmy mogli się tam dostać.
Bardzo podobała mi się wystawa motyli.
Motyle lądowały na dłoniach i stopach dzieci.
jak ci mija dzień?
Boże, jakie fajne przedszkole! Jestem Ci bardzo wdzięczna, brak słów, bardzo dziękuję. Vladowi bardzo się podobało❤️
Mama stoi tutaj od 4 rano.
Być może gospodyni zostawi swój numer telefonu do komunikacji.
Ten dom w Pradze-8 wydaje mi się jak dotąd najlepszą opcją.
Dyrektor nic mi nie mówił o możliwości sponsorowania obiadów dla dziecka.
Podali mi następujące dane do zapłaty.
Zapłaciłem już za jedzenie za część marca i kwietnia.
Czy byłbyś w stanie pomóc mi zapłacić za maj i czerwiec?
Co powinienem zrobić?
Powinienem skontaktować się z dyrektorem szkoły z tym pytaniem?
Iść w poniedziałki czy lepiej chodzić w środę?
Wszyscy twoi znajomi będą wiedzieć, że ze mną rozmawiasz.
Nie wiem co robić, niedługo maj, potrzebuję mieszkania, ale nie ma mieszkań.
Czy byłeś pierwszym, który wyszedł ze związku, czy to ty zostałeś porzucony?
Pochodzę z okolic Doniecka, mam wykształcenie medyczne, 27 lat doświadczenia, praca na oddziale neurologicznym, masaże, gimnastyka dla dorosłych i dzieci, wszelkie manipulacje medyczne.. Mówię po rosyjsku i ukraińsku.. po resztę informacji, zadzwoń +420-464-548 -072 lub napisz na Viber +380-42-791-0436
Byłam manikiurzystką😥, a moja przyjaciółka była managerem.
Ale możemy robić wszystko, jesteśmy Ukraińcami, a czego nie umiemy, szybko się nauczymy)))
Życzę Ci znalezienia dobrej asystentki😊
Z jakiegoś powodu, myślałem, że dzisiaj jest poniedziałek.
czy mogę cię prosić, żebyś zabrał mnie ze sobą, kiedy będziesz wracał do domu?
Potrzebuję stolika nocnego. Mogę zapłacić czynsz.
Nie wiem co mam zrobić.
Od czasu do czasu musimy jechać do ambasady, czekam aż zajmą się dokumentami, jadę i pytam. Tu też będę szukać.
Ponadto, jestem zainteresowany rozmową z Tobą.