# Training Modernmt inside Docker
- copy your datasets to `modernmt-splittrain/host/data` according to the [Tree View of the Directory structure](#tree-view-of-the-directory-structure) **(inside the server terminal)**
    - copy corpora pairs intended for training to `modernmt-splittrain/host/data/train` as files.
    - copy corpora pairs intended for memory to `modernmt-splittrain/host/data/memory` as files.
    - copy corpora pairs intended for testing to `modernmt-splittrain/host/data/tests` as files inside **folders**.
- change directory to `modernmt-splittrain` **(inside the server terminal)**
    ```sh
        cd modernmt-splittrain
    ```
- Stop previous container if it's a ghost process (still running, prevents you from re-running it)
    ```
        docker stop kwolk
    ```
- **OPTIONAL (IF NECESSARY)**
    - Remove old image **(inside the server terminal)**
        ```
            docker rmi test 
        ```
    - Create new image **(inside the server terminal)**
        ```
            docker build -t test . --build-arg MMT_VERSION=v4.9.5
        ```
- Start image with lots of RAM (as much as possible) **(inside the server terminal)**
    ```
        docker run --rm --name kwolk --cpus=4 --memory=64g -it -v ./host:/opt/mmt/host --gpus all test:latest bash
    ```
- Train the model **(inside the Docker terminal)**
    ```
        python3 host/scripts/trainer.py --datadir host/data --saveto host/engines --language_pair pl:uk --model_name PLEN_SUBCCALCC100k --train_steps 100000 --unifiedmemory -y
    ```
    - **Params**:
      - `--unifiedmemory` creates a single memory for all datasets intended to be stored as memory, **it should be experimented with**, omitting this option will create a separate memory for each corpora pair intended to be stored as memory.
      - `-y` the automation script skips asking you whether you want to execute a certain `mmt` command or not, it should be kept while doing long training sessions, but it should be omitted while debugging on small data. check [Sample Commands Executed by the Automation Script](#sample-commands-executed-by-the-automation-script)
- **OPTIONAL**
    - Check on memory usage on demand **(inside a second server terminal)**
        ```
            awk '$3=="kB"{$2=$2/1024/1024;$3="GB"} 1' /proc/meminfo | column -t | grep MemAvailable && nvidia-smi | grep MiB
        ```
    - Check on memory usage every 10 seconds **(inside a second server terminal)**
        ```
            while sleep 10; do awk '$3=="kB"{$2=$2/1024/1024;$3="GB"} 1' /proc/meminfo | column -t | grep MemAvailable && nvidia-smi | grep MiB; done
        ```

# Tree View of the Directory Structure
    modernmt-splittrain/
        documentation.md
        documentation.pdf
        Dockerfile
        fixes/
            requirements.txt
            ChineseCharacterConverter.java
            setup.py
            utils.py
            textencoder.py
            requirements_cuda-11.txt
            pom.xml
        host/
            engines/
                log_2023-03-04_20-08-58.txt
                log.txt
                PLEN_SUBCCALCC100k/
                    engine.xconf
                    models/
                        decoder/
                            model.conf
                            pl__uk/
                                model.vcb
                                model.pt
                            memory/
            data/
                tests/
                    val/
                        val.pl
                        val.uk
                    tst/
                        tst.pl
                        tst.uk
                train/
                    MultiCCAligned.100m.pl
                    OpenSubtitles.pl-uk.pl
                    MultiCCAligned.100m.uk
                    OpenSubtitles.pl-uk.uk
                memory/
                    CCMatrix.pl-uk.uk
                    WikiMatrix.pl-uk.pl
                    MultiCCAligned.pl-uk.pl
                    CCMatrix.pl-uk.pl
                    WikiMatrix.pl-uk.uk
                    MultiCCAligned.pl-uk.uk
            scripts/
                splitter.py
                trainer.py

## Notes
- the `engines` folder persists the following:
  - the engines that have been trained inside docker
  - log files for training sessions (marked by the date & time that the session has started)
- the `data/tests` folder should contain folders for different test cases (in the example above it has 2 test cases)

# Sample Commands Executed by the Automation Script

    ./mmt create pl uk host/data/train -e PLEN_SUBCCALCC100k --train-steps 100000 --no-test --delete
    Do you want to execute the above command? [y/n]: 


    ./mmt start -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/val
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/tst
    Do you want to execute the above command? [y/n]: 


    ./mmt memory create unified -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt memory import -p host/data/memory/CCMatrix.pl-uk.pl host/data/memory/CCMatrix.pl-uk.uk -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/val
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/tst
    Do you want to execute the above command? [y/n]: 


    ./mmt memory import -p host/data/memory/WikiMatrix.pl-uk.pl host/data/memory/WikiMatrix.pl-uk.uk -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/val
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/tst
    Do you want to execute the above command? [y/n]: 


    ./mmt memory import -p host/data/memory/MultiCCAligned.pl-uk.pl host/data/memory/MultiCCAligned.pl-uk.uk -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/val
    Do you want to execute the above command? [y/n]: 


    ./mmt evaluate -e PLEN_SUBCCALCC100k --path host/data/tests/tst
    Do you want to execute the above command? [y/n]: 


    ./mmt memory list -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    ./mmt stop -e PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    rm -rf host/engines/PLEN_SUBCCALCC100k
    Do you want to execute the above command? [y/n]: 


    mv engines/PLEN_SUBCCALCC100k host/engines
    Do you want to execute the above command? [y/n]: 