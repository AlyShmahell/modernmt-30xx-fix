import re
import os
import sys
import glob
import json
import argparse
import shutil
from tqdm import tqdm
from pathlib import Path
from collections import defaultdict
import random
from splitter import Splitter

class colors:
    red = '\033[91m'
    blu = '\033[94m'
    end = '\033[0m'
    @staticmethod
    def print(string):
        print(colors.red + string + colors.end)
    @staticmethod
    def str(string):
        return colors.blu + string + colors.end

oneliner = lambda x: re.sub(r'\s+', ' ', x.replace("\n", " ")).strip()

def skip(y, msg=""):
    print(flush=True)
    colors.print(msg)
    if y:
        print(flush=True)
        return False
    while True:
        ans = input(colors.str('Do you want to execute the above command? [y/n]: '))
        if ans == 'y':
            print(flush=True)
            return False
        if ans == 'n':
            print(flush=True)
            return True

def main():
    argparser = argparse.ArgumentParser()

    argparser.add_argument(
        "--datadir", 
        required=True, 
        help="directory of the data that contains src, tgt language files"
    )
    argparser.add_argument(
        "--saveto", 
        required=True, 
        help="path to the folder where you want to save the engine"
    )
    argparser.add_argument(
        "--language_pair", 
        required=True, 
        help="language pair separated by `:` only, no spaces"
    )
    argparser.add_argument(
        "--model_name", 
        required=True, 
        help="model name"
    )
    argparser.add_argument(
        "--train_steps", 
        required=False, 
        type=int,
        default=100,
        help="the number of training steps"
    )
    argparser.add_argument(
        "--unifiedmemory", 
        required=False, 
        action='store_true',
        default = False,
        help="use unified memory for all corpora (instead of separate memory for each)"
    )
    argparser.add_argument(
        "-y", 
        required=False, 
        action='store_true',
        default = False,
        help="do not ask if I want to continue"
    )
    # Preprocess Arguments
    args      = argparser.parse_args()
    src, tgt  = args.language_pair.split(":")
    # Create & Train Engine
    train_cmd = oneliner(
        f"""
        ./mmt create {src} {tgt} {args.datadir}/train
        -e {args.model_name}  --train-steps {args.train_steps} 
        --no-test --delete
        """
    )
    if not skip(args.y, train_cmd):
        os.system(train_cmd)
    # Start Engine
    start_cmd = f"./mmt start -e {args.model_name}"
    if not skip(args.y, start_cmd):
        os.system(start_cmd)
    # Evaluate Egnine
    eval_cmd  = f"./mmt evaluate -e {args.model_name} --path {args.datadir}/tests"
    if not skip(args.y, eval_cmd):
        os.system(eval_cmd)
    # List Memory Files
    memfiles  = defaultdict(dict)
    for path in glob.glob(f'{args.datadir}/memory/*.*'):
        if os.path.isdir(path):
            continue
        name = path.split("/")[-1].split('.')
        title = ".".join(name[:-1])
        extension = name[-1]
        memfiles[title][extension] = path
    # Import Memory Files
    uid = None
    if args.unifiedmemory:
        memory_cmd = oneliner(
            f"""
                 ./mmt memory create unified
                 -e {args.model_name}
             """
        )
        if not skip(args.y, memory_cmd):
            os.system(memory_cmd)
        uid = os.popen(f"./mmt memory list -e {args.model_name} | grep unified | sed 's/[^0-9]*//g'").read().split('\n')[0]
        try:
            uid = int(uid)
        except:
            uid = None
        if skip(args.y, f"continue with uid: {uid}"):
            uid = None
    for idx, (title, pair) in enumerate(memfiles.items()):
        # import Memory
        memory_cmd = oneliner(
            f"""
                 ./mmt memory import -p 
                 {pair[src]} {pair[tgt]}
                 -e {args.model_name}
             """
        )
        if args.unifiedmemory and uid is not None:
            memory_cmd = f"{memory_cmd} --id {uid}"
        if not skip(args.y, memory_cmd):
            os.system(memory_cmd)
        # Evaluate Engine
        if not skip(args.y, eval_cmd):
            os.system(eval_cmd)
    # List Memories
    memlist_cmd = f"./mmt memory list -e {args.model_name}"
    if not skip(args.y, memlist_cmd):
        os.system(memlist_cmd)
    # Stop Engine
    stop_cmd  = f"./mmt stop -e {args.model_name}"
    if not skip(args.y, stop_cmd):
        os.system(stop_cmd)
    # Copy Engine to Host
    p = Path(f'{args.saveto}')
    p.mkdir(parents=True, exist_ok=True)
    delt_cmd  = f"rm -rf {args.saveto}/{args.model_name}"
    if not skip(args.y, delt_cmd):
        os.system(delt_cmd)
    copy_cmd  = f"mv engines/{args.model_name} {args.saveto}"
    if not skip(args.y, copy_cmd):
        os.system(copy_cmd)



if __name__ == '__main__':
    main()