Dzień dobry. Przepraszam, nie miałem połączenia z internetem i nie mogłem wysłać tego szybciej. Dziękuję.
Proszę o podanie dokładnego adresu, gdzie mam jutro posprzątać oraz kodu do drzwi. O której goście jutro wyjeżdżają a nowi się wprowadzają?
Niestety, ale muszę odrzucić Pańską ofertę, ponieważ w tym czasie znalazłem już inną pracę. 
Wybacz, ale nie mogę tam odmówić.
Czasami wydaje mi się, że przez tłumacza, moje myśli po czesku różnią się od tego, co piszę po ukraińsku.
Obiecaliśmy, że kiedy pójdziesz do szkoły, damy Ci niespodziankę.
Dzień dobry, zgadzam się na kurs.
Proszę mi jednak powiedzieć, czy jest wcześniejszy termin?
Ponieważ nie mieszkam w Pradze, mogą być trudności z transportem.
Jeśli nie ma innej opcji to nadal się zgadzam.
Z góry dziękuję.
W Chersoniu ludzie znowu poszli na wiec, Rosjanie nie zdążyli ich rozpędzić.
Jak powiedzieli agencji uczestnicy wydarzenia, mieszkańcy Chersonia zdążyli zorganizować wiec zanim na miejsce przybyło rosyjskie wojsko ze sprzętem by ich rozpędzić.
,,Udało nam się zorganizować wiec. Teraz dotarł tam rosyjski sprzęt'' – powiedział jeden z uczestników wydarzenia.
Wcześniej mieszkańcy tradycyjnie gromadzili się na akcje protestacyjne na Placu Wolności - w pobliżu budynku Obwodowej Administracji Państwowej i Rady Obwodowej. 
Ten plac, podobnie jak ten budynek, obecnie jest kontrolowany przez uzbrojone rosyjskie wojska, które używają broni przeciwko uczestnikom wieców i porywają ludzi.
Jak informowaliśmy, 3 kwietnia uzbrojeni rosyjscy okupanci użyli broni przeciwko pokojowym demonstrantom w Kachowce.
Jak informował Ukrinform, mieszkańcy obwodu donieckiego regularnie organizują pokojowe protesty przeciwko rosyjskiemu agresorowi.
Rosyjskie wojsko używa siły i broni przeciwko ludziom, są ranni i zatrzymani.
Ponadto, rosyjscy najeźdźcy porywają mieszkańców regionu.
Prezydent Wołodymyr Zełenski nagrodził Chersoń specjalnym tytułem ,,Miasto-bohater''.
24 lutego prezydent Rosji Putin rozpoczął pełną inwazję na Ukrainę.
Wojska rosyjskie ostrzeliwują i niszczą kluczowe obiekty infrastruktury, przeprowadzają masowy ostrzał obszarów mieszkalnych ukraińskich miast i wsi przy użyciu artylerii, wyrzutni rakiet i pocisków balistycznych.
Często śni mi się tutaj mój tata.
Zmarł dzień po moich urodzinach.
Ale ogólnie sny są dobre.
Dzień dobry Hana.
Zrobiłem tak jak napisałeś i telefon zaczął się ładować!
Bardzo dobra wiadomość!
Dziękuję!
Możemy się spotkać na godzinę lub dwie a potem pójdę do domu, ponieważ nie mam przy sobie potrzebnych rzeczy.
Dozorca w czerwonym kombinezonie ciągnie rakietę do śmietnika. Na froncie charkowskim bez zmian.
Można zarezerwować telewizor z dekoderem i pilotem, garnki, poduszki, krzesła i patelnie.
Oleg znalazł dla mnie również pracę na pół etatu - sprzątanie 2 mieszkań, które na co dzień wynajmowane są turystom. 
Apartamenty znajdują się w centrum Pragi.
Czy pasuje Ci iść ze mną do banku w poniedziałek? Lub w inny dzień?
Dzień dobry, byłoby dobrze gdybyś mógł to zrobić dzisiaj, tak jak napisałeś, o 17:00.
Właśnie dlatego czytam Biblię, Koran i inne, żeby znaleźć odpowiedzi na pytania, na które szukałem odpowiedzi.
Gdzie jest dom, który ma być posprzątany?
To znaczy, że masz dobre sny?
W załączniku do tego reportu, przesyłam listę wolnych wakatów oferowanych nam przez pracowników.
Jeśli jesteś zainteresowany tą ofertą, proszę o bezpośredni kontakt z osobą z ogłoszenia.
Mam nadzieję, że jeszcze będą tu miejsca, bo nasi bliscy, żona mojego wujka, jej rodzice i córka też przyjadą.
Mają bilety na 20 kwietnia.
Niech Bóg da im bezpieczną podróż.
Kiedy przyjedziesz, zadzwoń do mnie na telefon. Dzwonek do drzwi nie działa.
Taniej było lepiej... musimy się przeprowadzić, ponieważ nie stać nas na europejskie ceny…
Muszę obejrzeć to miejsce i spróbować zobaczyć gdzie boli.
Chce teraz naciskać na wszystkie moje czułe punkty, wie które.
Ale to nie ma już na mnie żadnego wpływu.
Nie chciałem rozmawiać o nim i jego tragedii wczoraj przed Miszą.
Nie można zamykać puszek, nie stoją gdy pada. Zamknę więcej gdy nie będzie padać.
Więc po prostu czuję się niekomfortowo w moim własnym ciele.
To mój ukraiński kolega z klasy.
Biedna Oleksandra biega tutaj od kąta do kąta, jest tu tyle, że jej oczy szaleją i chce być wszędzie jednocześnie.
Tylko te szmaty powinny być używane do parownic.
Dzień dobry, przyjdę za 20 minut żeby odebrać drukarkę.
Czy mogę oddać Ci pieniądze za lekarza?
Twoja kawa już dotarła, mogę przynieść ją jutro.
Możesz zostawić swoje zakupy w samochodzie, później odbierzemy dzieci i rzeczy.
Pisałem do Ciebie już dwa razy :)) ale robię podwójne kółko dla pociągów.
Nie zrozumiałem, Valya i ja będziemy razem rano?
Czy miałeś na myśli to, że my będziemy sprzątać same a Ty będziesz tylko nadzorować?
Możemy zamienimy zmiany z Valyą? Valya rano, a ja po południu?
Moja mama będzie mieszkać tu w hostelu (/dormitorium) , ponieważ opłata za hostel jest niska.
Najważniejsze, że mam gdzie mieszkać.
Sasha nie była dzisiaj w szkole, napisałam maila do nauczyciela.
Cześć👋🏻 Jestem chora, dlatego będzie lepiej przełożyć naszę spotkanie na przyszły weekend, przepraszam.
Wiem jak gotować, najważniejsze to mieć przepis, ale lubię piec ciasta.
Barszcz, pierogi i inne to tradycja w Ukrainie.
Nie mam ulubionych dań, lubię próbówać różnych dań z różnych krajów.
Jakie są twoje preferencje kulinarne? Lubisz gotować?
Chciałabym się czymś zająć.
Dokładniej, jest pociąg, ale nie ma miejsc siedzących.
Przepraszam, ale jesteśmy trochę spóźnieni.
Lucia, też mogę pomóc w kuchni?
To bardzo dobrze, że Yulia będzie miała możliwość pójść do pracy.
Poszedłem do ich mieszkania wczoraj w nocy.
Jest tam bardzo przytulnie i wygodnie.
We wtorek Pablo powie mi czy Nazar dostał pracę w browarze i kiedy ma przyjść się umówić.
Jeśli Nazar pracuje od 5:30, może wsiąść w każdy pociąg.
Zełenski: Mariupol to serce tej wojny, jeśli przestanie walczyć - będziemy mieli słabe pozycje.
Prezydent Wołodymyr Zełenski wierzy, że walki o wschodnią Ukrainę, szczególnie o Mariupol, zadecydują o przebiegu wojny - jeśli Siły Zbrojne Ukrainy zostaną tam pokonane, Rosjanie będą mogli porzucić negocjacje i ponownie zająć okupowane terytoria.
Mowa bezpośrednia: ,,Mariupol jest dziś sercem tej wojny.
Bije - walczymy, jesteśmy silni.
Jeśli przestanie bić, będziemy mieć słabsze pozycje.
Oni (obrońcy miasta - przypomnienie redakcji) to ludzie, którzy przyciągneli do siebie dużą liczbę wrogów.
Im silniejsza nasza pozycja w Mariupolu, tym silniejsza będzie nasza pozycja na wschodzie kraju, w (regionie) JFO, a jeśli będą silniejsze, to stół negocjacyjny będzie dla nas bliższy i będziemy mieli przewagę w dialogu z Federacją Rosyjską.
Jeśli nasza sytuacja będzie słaba w tych wszystkich kierunkach, możemy nie doczekać spotkania.
Ponieważ wtedy Rosja podejmie wszystkie kroki, które mogą prowadzić do powrotu, nawet do miast, które już wyzwoliliśmy.
Mogą po to też pójść.
Wtedy nasza sytuacja w negocjacjach będzie słabsza i być może, nawet nieinteresująca dla strony rosyjskiej.
Niestety, stwierdzamy.
Wierzymy w nasz wynik, w nasze zwycięstwo…''
Szczegóły: Zełenski powiedział również, że po torturach Ukraińców trudno było przystąpić do negocjacji, ale ,,nie możemy tracić szansy na dyplomatyczne rozwiązanie jeśli ją mamy''.
Mowa bezpośrednia: ,,Ludzie zaakceptują pokój tak czy inaczej, ponieważ ludzie chcą końca tej wojny.
Na naszych warunkach, na warunkach niepodległości Ukrainy, ale… każda rodzina coś straciła - i nie sądzę, że jakikolwiek pokój na jakichkolwiek warunkach będzie ich satysfakcjonował.
Ale jeśli nie będziemy mówić emocjonalnie, wojna musi zakończyć się pokojem, inaczej zakończy się milionami ofiar.
I nawet tam, gdzie jest milion ofiar, wszystko zmierza do końca wojny.
Tak, musimy walczyć - ale o życie.
Nie można walczyć o proch, gdy nie ma nic, nie ma ludzi.''
Dzień dobry, czy są jeszcze wolne miejsca na kurs czeskiego dla dorosłych na godzinę 19:00 we wtorek?
Jeśli chcesz, możesz spotkać się z rodziną w Kutnia Hora.
A ci dwaj to moi kuzyni.
Tak, rozumiem.
Nie jestem pewna, czy zdążę posprzątać do 13:00, bo to duże mieszkanie i jest dużo sprzątania.
Postaram się posprzątać szybko, ale nie mogę obiecać.
Napiszę, gdy mieszkanie będzie gotowe dla gości.
Dominica, kto zajmuje się zakupem materiałów eksploatacyjnych?
Czy to procedura stała czy trzeba zamawiać po zakończeniu?
W związku ze zmianą estetyki literatury ukraińskiej potrzebne są nowe koncepcje opisujące jej nowy stan jakościowy.
To analiza przestrzeni metaforycznej literatury ukraińskiej, badanie stanu
ukraińskiej metafory poetyckiej w literaturze współczesnej pozwala na analizę kontekstu ponowoczesnego jako takiego, w którym metafora pełni rolę kryterium aksjologicznego
Czy wiesz jak zgłosić przez internet, że znalazłem pracę i nie ubiegam się już o pomoc?
Nie mam możliwości pójścia osobiście ((((( Dziękuję, ten formularz musi być wydrukowany, aby go wypełnić.
Nie wiesz kiedy możesz tam zamieszkać?
Masz koszyk? Chcielibyśmy poprosić o to na poświęcenie Wielkanocne w niedzielę.
Dzieci są naszym sensem życia. Nie męczymy się tym. Dobranoc
Nie zmieniaj tematu. Pytam teraz wprost. Czy chcesz kontynuować komunikację – jeśli nie, napisz do mnie od razu.
Ponadto, chodzimy do pracy i pieniędzy.
W poniedziałek odbędzie się spotkanie przywódców i zdecydujemy, jak i kiedy zorganizujemy.
To dobrze, ponieważ już zacząłem się martwić, że coś źle zrozumiałem i poszedłem w złe miejsce.
Myślę, że to dobra decyzja, mniej znaczy lepiej i można tym ludziom zapewnić lepszą jakość pomocy niż wtedy, gdy jest ich dużo.
Moja 16-letnia córka i ja szukamy tymczasowego schronienia w Czechach, gdzie moja córka planuje studiować na Uniwersytecie.
Przynajmniej teraz się zobaczyliśmy. Rozmowa przypominała bardziej korespondencję, ale nie było aż tak źle.
Pomóż znaleźć książki w języku czeskim.
Mam na imię Oksana. Jestem krytykiem teetralnym i nauczycielem akademickim. Pracuję również jako ekspert Ukraińskiego Funduszu Kultury i ekspert festiwalu teatralnego.
Mój mąż jest sportowcem, zajmuje się turystyką, mam syna.
Mogę pomóc w sprzątaniu.
Iść czy nie, po prostu musiałeś mnie zrozumieć.
Jeśli możesz, pożycz mi pieniądze na lekarstwa, proszę!
Następnie pobiorę przez Ukrainę przez mój VPN
Więc szukam pracy jako księgowy, ale w trakcie nauki języka mogę wykonywać prace administracyjne.
Rozumiem, że nie zostanę zatrudniony od razu gdzieś w firmie do pracy jako księgowy.
Kiedy dziecko ma urodziny, czy samo przynosi sok lub owoce dla całej klasy, coś dla wszystkich dzieci?
Oczywiście możemy przyjść, dziękuję!
5. Jakie inne wykształcenie poza kursami języka czeskiego chciałbyś mieć?
Oj, jakie to wszystkie trudne :)
Na Ukrainie operatorzy komórkowi pracują 24 godziny na dobę w trybie telefonicznym lub online, codziennie, niezależnie od świąt :)
Jutro rano idę do pracy około 6:00-6:20, w domu będę po obiedzie.
Jeśli masz czas, postaramy się zmienić plan taryfowy jutro wieczorem.
Ale dzisiaj znowu zbombardowali nasze miasto i boję się o mojego syna.
I chcę uciec stąd jak najszybciej.
Nie do końca zrozumiałem.
Drogi bracie Albercie, moja rodzina i ja jesteśmy bardzo wdzięczni za Twoje wsparcie i za prezenty, które nam dałeś!
Dziękujemy Ci z głębi naszych serc.
Z poważaniem, rodzina Bezverhi.
Ok, dziękuję za rozmowę. Wezmę tabletkę i pójdę do łóżka odpocząć. Dobrych snów.
Mam na imię Ciara, jesteśmy z Ukrainy, jestem z siedmioletnią córką i moją matką.
Szukam pracy… ale jest problem, nie mogę długo stać na nogach po operacji, dlatego ciężko mi znaleźć coś odpowiedniego.
Mieszkam tymczasowo w Pradze 9. Jestem gotów przenieść się gdziekolwiek, jeśli jest praca. Będę bardzo wdzięczny za rady lub oferty)
Ale jeśli nie chcesz ze mną rozmawiać, tęsknię za tobą
Dlaczego zdecydowałeś, że nie potrzebujesz takiego doświadczenia?
Każda sytuacja jest po coś dana.
Lepiej jest, aby osoba się zmieniła, zwłaszcza duchowo.
Przekażę ci te pieniądze, gdy bank je zatwierdzi.
Około 30 000 UAH za twoje długi, plus dla ciebie zostało 30 000 UAH.
Janka, mam nadzieję, że masz się dobrze, a Twoja babcia nie będzie na mnie źle mówić.
Próbuję uśpić Sashę... Potrzebuję, żeby chociaż trochę pospał…
Do jadalni wymagany jest kod
Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy opublikował listę rosyjskich żołnierzy, którzy brali udział w popełnieniu zbrodni wojennych w Buczy w obwodzie kijowskim.
Jak informuje Ukrinform, Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy poinformował o tym na Facebooku.
„Każdy Ukrainiec powinien znać ich nazwiska!
Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy uzyskał listę żołnierzy 64. oddzielnej brygady strzelców zmotoryzowanych, którzy bezpośrednio uczestniczyli w popełnieniu zbrodni wojennych na ludności Ukrainy w Buczy” – głosi wiadomość.
Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy informuje, że wszyscy zbrodniarze wojenni staną przed sądem i będą sądzeni za zbrodnie popełnione na ludności cywilnej Ukrainy.
Listę można zobaczyć w linku.
Jak donosi Ukrinform, Irpin, Bucza, Gostomel i cały obwód kijowski zostały wyzwolone spod rosyjskich najeźdźców.
W wyzwolonych miastach i wsiach odnotowano masowe mordy ludności cywilnej dokonane przez wojsko rosyjskie.
1 kwietnia burmistrz Buczy Anatolij Fedoruk poinformował, że w masowych grobach pochowano 280 osób.
Prokurator Generalna Iryna Wenediktowa poinformowała, że 3 kwietnia 410 ciał zabitych cywilów zostało wywiezione z terytorium obwodu kijowskiego wyzwolonego od rosyjskich najeźdźców.
24 lutego prezydent Rosji Putin ogłosił rozpoczęcie pełnej inwazji na Ukrainę.
Wojska rosyjskie ostrzeliwują i niszczą kluczowe obiekty infrastruktury, przeprowadzają masowy ostrzał obszarów mieszkalnych ukraińskich miast i wsi przy użyciu artylerii, wyrzutni rakiet, pocisków balistycznych i bomb lotniczych.
Dzień dobry, przepraszam, ale nie będę mógł dla Państwa pracować, ponieważ w najbliższym czasie lecę do Kanady.
Nazwy oficjalne umieszcza się bezpośrednio po myślniku, wyrażenia slangowe po ukośniku, skróty stosowane w planie lekcji podano w nawiasach.
Nie chcę przeszkadzać, odpoczywaj
Sprawdziłem prognozę pogody. Będzie zimno.
Nie potrzebuję marek.
Po prostu dobre ubrania w normalnych cenach i w różnych rozmiarach.
Byliśmy w sklepie na stacji kolejowej
Oferowane miejsca pracy. Czy jest to możliwe bez znajomości języka?
To ważne, jeśli istnieje taka tradycja, to muszę wiedzieć, abym mógł się przygotować)
Myślałem, że za tydzień, ale sytuacja tutaj jest gorąca, syreny ciągle wyją.
Jutro może być złe połączenie na drodze.
Jestem wdzięczna każdej osobie za to doświadczenie, nawet jeśli to bolesne.
Uważam, że z każdej sytuacji nauczyłem się czegoś, aby nie powtarzać błędów w przyszłości.
Dyrektywy wprowadza się w formie numerowanych pisemnych aneksów, które stanowią część niniejszego Regulaminu.
Jestem pewny, że nie będzie z tym problemów.
W Ukrainie wiele osób podobnie świętuje w tym tygodniu.
To zależy od religii.
Czy osoba jest Grekokatolikiem czy Katolikiem.
Na początku, możesz to wypróbować za darmo.
Może napiszesz nam algorytm płatności, sami zapłacimy.
Kartkę, którą dzieci otrzymują na koniec roku szkolnego, nazywamy świadectwem, a certyfikat otrzymuje się, gdy się urodzi lub bierze ślub.
Tak! Jest jak doświadczony kierowca! Ale nie wiem czy to lepiej. Martwię się o ściany mieszkania
Jest tam napisane, że trzeba wypełnić życiorys po czesku…
Postaram się zdążyć. Ponieważ jeszcze muszę iść do ratusza podpisać dokumenty.
Żona nie jest zła, że jesteś na telefonie.
W moich codziennych modlitwach dziękuję Bogu i Matce Bożej za Was.
Niech otulą Cię kocem miłości i ciepłem tej nocy.
Moje serce należy do Ciebie.
Nie masz nic przeciwko, żebym przyjechał zaraz po wojnie?
Miejsce, dzień i godzina zostaną określone zgodnie z zainteresowaniami i możliwościami.
Obiecaliśmy, że kiedy pójdziesz do szkoły, damy Ci niespodziankę.
Byłoby cudownie, mam pieniądze na dwa miesiące czynszu, w Ołomuńcu dzielnica nie ma znaczenia, będę bardzo wdzięczna.
Większość moich znajomych jest głęboko wstrząśnięta wiadomością o brutalnym maltretowaniu ludności cywilnej na północ od Kijowa.
Fotografie torturowanych i rozstrzeliwanych ludzi wprawiły w zakłopotanie cały cywilizowany świat.
Dziesiątki ludzi pytają się nawzajem, jak to się mogło stać w XXI wieku?! Jak?!
Ale zupełnie nic mnie nie zaskoczyło. Dzieje się dokładnie to, na co czekałem ze smutkiem…
Drugiego dnia wojny wywiozłem dzieci i starszych rodziców z Kijowa.
Potem koleżanki z dziećmi i dopiero potem wróciłem do stolicy do pracy.
Od 2014 roku konsekwentnie pomagam Siłom Zbrojnym Ukrainy i ani przez chwilę nie wątpiłem, że w przypadku okupacji przedmieść Kijowa moja rodzina nie zostanie oszczędzona.
Ponieważ byłem i pozostaję absolutnie pewny, że istota zgniłego komunistyczno-KGBistowskiego reżimu pozostaje niezmieniona od 1918 roku.
Po prostu nie może istnieć bez terroru, jest zbudowany na terrorze.
W 1937 r. jeden z moich pradziadków został rozstrzelany w więzieniu w Żytomierzu.
Kilka lat temu żytomierskie SSU pozwoliło mi sporządzić kopię sprawy egzekucyjnej pradziadka: cała sprawa ma ponad sto stron, ale wyrok śmierci jest bardzo prosty, a przez to jeszcze bardziej przerażający.
Oskarżony był analfabetą, nie przyznał się do winy.
Polak etniczny, katolik, miał pięcioro dzieci, pochodził z wolnych ludzi, biednej „jednodworskiej” szlachty, nigdy nie był poddanym.
Fakt, że mieszkali na farmach i posiadali kilka krów, wystarczył, by skazać oracza i karmiciela małych dzieci na śmierć.
Krewni nie znali nawet miejsca pochówku.
Babcia opowiadała, że ze wsi wywieziono wtedy prawie setkę ludzi i wszystkich zabito oprócz dwóch, które zgodziły się fałszywie zeznawać.
Sprawa karna wskazuje na nazwisko pukającego – Shariy.
Nasz były członek Rady Najwyższej pochodzi z sąsiedniej wsi.
Wierzę w genetykę i nie zdziwiłbym się, gdyby jego krewny był informatorem KGB.
Jak wiadomo niedaleko pada jabłko od jabłoni…
Pluton egzekucyjny, który skazał wieśniaków na egzekucję, to byli etniczni Rosjanie.
Analizując sprawę pradziadka, zainteresowałem się różnymi źródłami informacji.
W Rosji istnieją wspaniałe (bez sarkazmu) źródła informacji, takie jak „Bessmertny Barak”, które jakościowo przypominają wydarzenia z tamtych lat.
Tak więc we współczesnej Rosji potomkowie NKWD znaleźli sposoby na ukaranie i eksterminację prawie każdego, kto poważnie badał zbrodnie ich przodków 70-80 lat temu.
System najpierw dyskredytował, a następnie eksterminował ludzi, którzy odnajdywali masowe groby ofiar stalinowskich represji i publicznie spisywali nazwiska morderców.
Tak jakby na komputerze znaleziono pliki z pornografią dziecięcą, trafił za to do więzienia i tam szybko zmarł.
Agenci KGB wciąż zabijają tych, którzy próbują poznać prawdę o zbrodniach ubiegłego stulecia.
Więc dlaczego teraz nagle jesteś zaskoczony ich działaniami?!
Skupiają się tam najbardziej złe cechy natury ludzkiej.
Niewolnictwo i imperialny szowinizm XVI-XIX wieku zostały dodane do tysiącletniej tradycji Hordy.
A potem wynik został poddany bestialskiemu eksperymentowi genetycznemu, kiedy inteligencja została wycięta podczas kilku fal Czerwonego Terroru.
Obejrzyj na wpół francuski film z 1992 roku „Czekista”, tak właśnie było.
Widziałeś moje zdjęcia w kostiumie kąpielowym?
Czy możesz zapytać żonę, co mogę kupić na kaszel?
Przepraszam, ale nie mam kogo zapytać.
Chciałem też zapytać, czy wiecie może, gdzie poszły dzieci, bo Galya nie może ich znaleźć?
Lyubosh, Igor pyta, czy pasuje Ci iść jutro? (ma wolne i może jechać, bo dziś nie obejrzano jeszcze samochodu na stacji).
To dla nas bardzo niewygodne, że tak bardzo ci przeszkadzamy.
Bardzo nam pomogłeś, dziękuję!!
W Borodyance pod Kijowem podczas rozbiórki gruzów dwóch wielopiętrowych budynków mieszkalnych odkryto ciała 7 cywilów.
Obrońcy Mariupola poinformowali, że z rosyjskiego drona rozpylono nad miastem nieznaną trującą substancję.
Trzy osoby zostały ranne.
W rosyjskich więzieniach przetrzymywanych jest około 1700 ukraińskich obrońców i cywilów.
Wśród nich jest 500 kobiet.
Niemcy przeznaczą 1 mln euro na wsparcie Międzynarodowego Trybunału Karnego, który bada zbrodnie wojenne popełnione przez rosyjską armię na Ukrainie.
Kanada nałożyła sankcje na 33 rosyjskie przedsiębiorstwa sektora obronnego.
W ciągu minionej doby w walkach na wschodzie Ukrainy zniszczono jeden czołg wroga, trzy transportery opancerzone, trzy systemy artyleryjskie, 24 pojazdy samochodowe, jeden helikopter i trzy drony.
Twoja kawa dotrze dzisiaj.
Mam pierwszy "rower" po synku.
Co robią dziewczyny po powrocie ze szkoły?
Do miejsca, w którym się osiedliliśmy, dotarliśmy z centrum w Pardubicach, warunki są dobre.
Ale jest duży problem: mieszkają tu mężczyźni, którzy piją alkohol i palą w domu, głośna muzyka jest najmniej „przeszkadzająca”, zapach papierosów, pijani mężczyźni i my z dziećmi… szczere strach iść spać.
Proszę pomóżcie z mieszkaniem, proszę o pieniądze.
Ale gdzie będzie bezpiecznie i nie palono.
Pokój pachnie papierosami, jakby palili właśnie tutaj.
Błagam, jeden ledwo stoi, coś krzyczy, coś mu się nie podoba. to bardzo przerażające.
Tylko błagam, pomóż jeśli możesz🙏🏼
Najważniejsze, że się zrozumieliśmy
Bardzo pozytywnie, jakie cudowne przedszkole, jacy mili nauczyciele.
Robicie dla nas tak wiele, to niesamowite, bardzo dziękujemy ❤️
Dobry wieczór Stefanie, Agata chce wziąć udział w grze, tęskniła za grą 😉
Nie dosięgniemy tego włazu.
Na razie nie jesteśmy gotowi zapłacić takich pieniędzy, poczekamy na pomoc, a potem coś zaplanujemy.
Jak dostanę się dzisiaj do mieszkania, aby posprzątać?
Kiedy będę przy głównym wejściu, powinienem dać ci znać, a ty mnie wpuścisz?
Chciałem poszukać tortu dla Kariny, gdybym miał czas
Zapomniałem do Ciebie napisać, przepraszam.
Wczoraj wszystko poszło dobrze.
Rozmawialiśmy o dzieciach ze specjalnymi potrzebami i systemie ich edukacji na Ukrainie.
Kiedy pani Shakhova przedstawiła mnie jako pracownika Fpoint, pierwsze pytanie brzmiało: jak został znaleziony pies, jak został znaleziony mops.
Wszyscy śledzą stronę na Facebooku.
Poprosili mnie, abym przekazał im pozdrowienia i powiedział, że bardzo interesujące dla nich jest czytanie wiadomości.
Rozmawialiśmy także o osobach narodowości romskiej i przywilejach, jakie mają na Ukrainie.
I umówiliśmy się, że jeśli przyjdzie dziecko, a rodzice w ogóle nie rozumieją czeskiego, to mogę im pomóc po pracy przez telefon.
Muszę zmienić pościel, 2 komplety.
Pasuje mi szczególnie w święta.
Mam wolny czas i chodzimy tylko na nabożeństwa wielkanocne.
Dziękuję🏵️🏵️🏵️dzisiaj napiszę swoje dane do pracy
Danyi bardzo się podobało, dziękuję za organizację.
Tak, na razie Nestor ma tylko katar, a temperatura Halinki to 37,7, wieczorem 38.
Kolejka u generała Chapka jest bardzo powolna.
Każdy ma szansę.
Najważniejsze, że miłość jest prawdziwa i wzajemna.
Nie wiem jak jest w Europie, ale u nas ludzie zawierają małżeństwa z różnych powodów, głównie w celach chciwych, handlowych.
I mam z tym problem, jak kogoś nie kocham, to się nie uda.
Tak, zabraliśmy go do domu i od razu zanieśliśmy do cioci.
Bardzo nam dziękowała, nawet płakała.
Powiedziałem jej o Tobie i o tym jak pomagasz Ukraińcom.
Miała łzy w oczach.
Powiedziała, że gdyby to było możliwe, to może znalazłby się jakiś stary koc i poduszka.
Ale to nie jest konieczne. Tylko jeśli jest. Ja też jestem Ci bardzo wdzięczna.
Bardzo mi przykro z jego powodu.
Mój najlepszy przyjacieł został zabity na jego oczach.
Miałem wiele pytań do Boga, dlaczego w moim życiu były sytuacje, które po prostu doprowadzały mnie do rozpaczy.
Czy małe sklepy spożywcze są otwarte? Muszę kupić chleb i inne produkty.
Po prostu zdecydowałem, że pójdę, a ty umówiłeś spotkanie.
To prawda, ale nie zorientowaliśmy się jeszcze w okolicy i nie wiemy, gdzie wszystko jest. Dzisiaj przez godzinę szukaliśmy supermarketu i wróciliśmy pieszo. Dwa koce się nie nadają, więc potrzebujemy dwóch dużych.
Nawet teraz myślałem o tobie, a ty do mnie napisałeś.
Czy twój tata jako jedyny mówi po rosyjsku, czy jest ktoś jeszcze w rodzinie?
Dzieci mogą przyjść do Valyi i pobawić się w holu.
No to ryzykujmy :)
Również cieszę się, że cię poznałam.
Rozmawiałem z Wołodymyrem na temat mieszkania i konsultowałem, czy czekać na nich ze znalezieniem, czy sam szukać. Mieszkające z nami kobiety powiedziały nam też, że mamy iść na stację metra „Museina”, tam jest instytucja, która pomaga w znalezieniu mieszkania.
Ze względu na maleństwo przekroczę barierę 😂🙃😂
Nie znałem nawet odpowiedzi na niektóre z ich pytań.
Tak, w czwartek byłoby dobrze, jeśli to możliwe.
Nie mogę zadzwonić do lekarza, ponieważ nie wykonałem jeszcze testu na pozwolenie na żywność.
Ale nie mogę do niego zadzwonić, bo skończyły mi się pieniądze na koncie.
Nie mogę doładować telefonu, ponieważ nie rozumiem czeskiej bankowości internetowej i nie mogę doładować używając ukraińskiej karty bankowej.
W aplikacji Vodaphone nie mogę ani zmienić taryfy, żeby mieć normalne rozmowy i internet, ani doładować salda.
Zaraz oszaleję.
Gdzie jest cena, nie policzki, a twarz... Tytuł nie brzmi dobrze, co miałeś na myśli?
Wstydzę się siedzieć bez pracy.
Właśnie napisała, że jest w klasie w szkole.
Przepraszam, że przeszkadzam, po prostu bardzo się martwiłem.
Ale bliżej będzie momentu, kiedy opuszczą granice Ukrainy, aby mieć pewność, że dotrą.
Ponieważ teraz życie każdego jest tam zagrożone.
Tak. Rozmiar na wiek 10-11 lat. Ale nasze rozmiary nie pasują. Wszystko trzeba przymierzyć.
Szukam wszystkiego do domu i dla dzieci.
Dzięki ludziom, którzy mnie przyjęli, mieszkam w kaplicy, zawsze pytają, czy czegoś nie potrzebuję, ale wstydzę się powiedzieć, sam staram się to znaleźć.
Właśnie wróciłam do domu i teraz jem śniadanie :)
Nie tłumacz się, proszę, udawaj, że mnie tam nie ma.
nie można odpowiedzieć bez wysłania CV
Nie będę mogła powiedzieć tego mamie :)
I właściwie czuję się teraz trochę nieswojo, kiedy nie mogłem powstrzymać swoich uczuć przed opuszczeniem mieszkania... Jak ostatniej nocy...
Daj Boże żeby Yura zasnęła 🙏 może wtedy od razu pójdę do łóżka się wyspać.
W każdym razie napiszę do ciebie.
Cześć. Susana, pomóż. Dostałem wypłatę za marzec. Czy to dla nas dwojga z Julią, czy tylko dla mnie, nie rozumiem, dlaczego taka kwota.
Tak, możesz zrobić kopie paszportów, kiedy Ci pasuje :)
Nasza wieś posiada jedno z najlepszych liceów w regionie.
😂😋 Już dobrze mi się z Tobą rozmawia i nawet to lubię 😉
Zwróciłem się do Caritasu, zaoferowali mieszkanie tymczasowe na tydzień lub dwa, ale potrzebuję stałego, w którym będę mógł być z dzieckiem. Dlaczego jest ich coraz mniej?
Podlałam kwiaty. Wszystko w porządku. Wszyscy są wypoczęci i bardzo piękni.
Jak informuje „European Truth”, Welt pisze o tym, powołując się na źródła w kręgach rządowych Ukrainy.
Jak wynika z publikacji, w sobotę stosowna propozycja została przesłana do Ministerstwa Gospodarki Niemiec.
Koszt 100 haubic wraz z zestawem szkoleniowym i częściami zamiennymi to 1,7 mld euro.
Haubice oferowane są również w wersji transportera opancerzonego Boxer za 1,2 mld euro.
Podczas gdy czołgi w bitwie muszą zbliżyć się stosunkowo blisko do celów wroga, Panzerhaubitze 2000 może strzelać na odległość ponad 30 km.
Jak poinformowały ukraińskie kręgi rządowe, powołując się na propozycję KMW, dostawy haubic samobieżnych będą miały charakter obiegowy.
Bundeswehr jak najszybciej dostarczy do Kijowa 100 swoich haubic, a powstałe w ten sposób luki uzupełni przemysł w drugim etapie.
Pierwsze nowe haubice mogą zostać dostarczone 30 miesięcy po podpisaniu kontraktu, czyli przed drugą połową 2024 roku.
Pełna dostawa zostanie zakończona dopiero w 2027 roku.
A czy to my będziemy razem w pierwszej połowie dnia czy w drugiej?
Dziękujemy, znajdziemy sposób na doładowanie konta i zadzwonimy. Odpiszę ci. Dziękuję.
Jutro idę do pracy bez zdania komisji, a jak mój lekarz wyzdrowieje, zdam komisję, prawda?
Jak mogę teraz zmienić pakiet taryfowy T-Mobile na 4 gigabajty za 249 koron?
Witam, przepraszam. Chcę wiedzieć czy potrzebujesz pracownika?
Mogę myć podłogi lub naczynia.
Jestem z Ukrainy. Niestety, nie znam języka, ale potrzebuję pracy.
Jestem młody i aktywny, mam 21 lat.
Przyjmę jakąkolwiek pracę.
Znam czeski na podstawowym poziomie, ale uczę się codziennie więc myślę, że łatwo nauczę się wszystkiego, co jest potrzebne do pracy.
Mówiłem ci dzisiaj, już czas żebyś poszedł spać żebyś mógł jutro pracować.
Jeśli mogę, wezmę te spodnie do pracy. Rozmiar jest dla mnie dobry.
Jesteś mądry i wszystko będzie dobrze🙏 Odpoczywaj, nabieraj sił i piękna w zdrowym śnie!!! 🇺🇦❤️🇨🇿
Katka próbuje popełnić samobójstwo na Moście Karola w swoje urodziny.
Udało Ci się z kimś zaprzyjaźnić?
Chcieliśmy więc rozwiązać problem z kartą przed Wielkanocą. Nie mamy bankowości internetowej, nie wiemy jak ją założyć. Co musimy zrobić?
Czy mam zwrócić się do Pana, z którym żyjemy?
Zawsze mów ,,do widzenia'' kiedy wychodzisz.
Oczywiście, możemy po 17:00.
Czy mogę jutro wyprać ubrania w mieszkaniu i powiesić je w garażu żeby wyschły?
Cześć. Tak, będę na Ciebie czekać o 18:00.
Jak długo uczyłeś się na tę specjalizację?
Gdyby było ciepło, byłoby bardzo dobrze.
Złożyłem wniosek online. Postaram się dzisiaj pojechać po pracy.
U nas wszystko w porządku. Radzimy sobie z ogrzewaniem piecowym, mamy doświadczenie, mamy gaz na Ukrainie, ale ponieważ jest bardzo drogi, do ogrzewania pieca używaliśmy drewna.
Dzień dobry, Lena, proszę powiedz mi, gdzie w pobliżu jest sklep papierniczy.
Jutro jedziemy do Pragi obejrzeć mieszkanie.
Wszystko rozwiązało się samo.
Muszę wziąć ze sobą Karinkę.
Włożyłem pranie do pralki, wróciłem do domu i przetłumaczyłem, że na krześle niedaleko drzwi od pralki jest napis "kanał w naprawie". Czy mogę prać czy muszę wyłączyć pralkę?
mówi, że mój status zmieni się w ciągu 24 godzin. Ale dlaczego? Co to za żart? 😂😂😂
Mój były mąż nie może się uspokoić, pisze mi wiersze (prawdziwy dramat).
Tak bardzo chcę, żeby wszystko, co nas z nim oficjalnie łączy, skończyło się jak najszybciej🙏
Dziękuję, bo coś tu nie działa zbyt dobrze.
I nawet mamy już produkt menedżerski.
Przepraszam, musiałem coś pomylić.
Wtedy nie rozumiałem tak dobrze czeskiego.
Musiałem coś wymyślić.
To prawda, idą do szkoły we trójkę, bo Galya i Svyatoslav uczą się zdalnie, skończą szkołę na Ukrainie i dostaną świadectwa ukończenia szkoły, jesienią muszą iść na uniwersytety.
Powiesz mi jak dostać się do centrum miasta?
Podzielę się z Tobą moimi przemyśleniami.
Dla mnie małżeństwo jest sakramentem dwojga ludzi, którzy nie dyskutują o sobie ani z bliskimi, ani z przyjaciółmi.
Mąż i żona sami decydują o sprawach w swojej rodzinie, zwłaszcza bez udziału bliskich.
Czy możemy być razem?
To zajmie trochę czasu zanim będziemy razem.
Dlaczego nie spróbować teraz w ten sposób?
Wypożyczyłem samochód na 9 osób, przyjedziemy z Maryaną i Twoją rodziną.
Ile masz czasu? O której godzinie powinniśmy iść?
Tak, chętnie słucham jazzu.
Dziękuję, pracuję z tą aplikacją, rozmawialiśmy o niej na kursie języka czeskiego w środę.
Przez ostatnie cztery lata nikogo nie dopuszczałem do siebie, przeczytałem wiele książek o filozofii i próbowałem zrozumieć siebie.
Kiedy jesteś bardzo zraniony, trudno ci zaufać.
Ale musisz spróbować jeszcze raz, każdy przechodzi przez coś, co zmienia go na zawsze, takie jest życie.
Martin, my już idziemy spać.
Dziękuję Ci za piękny i zabawny dzień.
Wszystko bardzo nam się podobało.
Czujemy się, jakby to była nasza rodzina.
Dzieci przez cały wieczór opowiadały ojcu i wszystkim dziadkom, jak miło było u Was.
Pozdrowienia od dziewczyn! Życzymy wszystkiego najlepszego na święta 😉
A gdzie teraz patrzyliśmy?
Mam nadzieję, że mój syn wyjdzie z tej masakry żywy.
Chodźmy dzisiaj, może będzie coś, czego będziemy potrzebować.
Jak się z nimi skontaktować, żeby otworzyli drzwi?
Czy nastąpiła poprawa w walce z koronawirusem?
Bardzo dziękuję za pomoc ludziom. Jeśli możesz, pomóż też nam. Znajdź niedrogie mieszkanie.
Jesteśmy teraz w Slap, przez jakiś czas schroniliśmy się u przyjaciół.
Moja rodzina: mąż, sześcioletnia córka, jedenastoletni syn.
Mężczyzna znalazł już pracę jako kierowca.
Jestem masażystką - rehabilitantką, szukam pracy.
Żeby dzieci mogły chodzić do szkoły, a ja do pracy, potrzebujemy mieszkania blisko cywilizacji.
Po prostu desperacko potrzebowałem dzisiaj dać!
Nic. Poczekamy do jutra. Nie wiedziałem, że nawet duże sklepy będą zamknięte.
Gołąbki gotuję tak: w rondelku rozcieńczam koncentrat pomidorowy w pół litra wody. 3-4 łyżki koncentratu pomidorowego - doprowadzam do wrzenia.
Gołąbki przekładam do garnka i zalewam tym sosem.
Duszę w piekarniku około 1,5 godziny.
Ile mam pieniędzy na tym numerze?
Muszę przynieść to wszystko.
Od poniedziałku 4.
W 2022 r. uchodźcy z wojny w Ukrainie mogą zwrócić się o pomoc humanitarną w nowym miejscu pracy Urzędu Pracy na rynku praskim.
Oddział w hali nr 29 jest przeznaczony specjalnie do składania i rozpatrywania wniosków o pomoc, dlatego na miejscu jest tłumacz.
Lydia została już przyjęta do szkoły, ale pójdziemy we wtorek z powodu choroby, poinformowałam dziś nauczycielkę.
Siedzę ze słuchawkami na uszach, słucham muzyki, myślę o tobie i dzieciach.
Naprawdę chcę być z Tobą.
Aby Cię uszczęśliwić 😢.
Nie wiem, kochanie, jak się masz?
Wiem, że to dla Ciebie trudne.
Ale traktuję to tak, jakbyśmy byli razem. Jakbyśmy byli parą.
Powiedziałbym, że po wojnie będzie dużo pracy.
Dlatego nie boję się, że jej tam nie znajdę.
Mogę robić wiele rzeczy.
Dlatego nie boję się, że nie dostałem się do żadnej z nich.
Tylko nie wiem jak będzie z mieszkaniem.😢😢😟
Muszę zdać egzamin na produkcję pozwolenia na żywność. Czy mogę to zrobić tam?
Proszę o przypomnienie, jutro apartament powinien być przygotowany na 5 gości.
Piąte miejsce, jak zgaduję, jest w pokoju z telewizorem?
Mam rozłożyć sofę i pościelić łóżko?
Czy możemy zostać z tobą, podczas gdy pani Margarita znajdzie nam mieszkanie?
Nie martw się o to.
Nie jest nowy, był już używany, ale działa, ale nie jest potrzebny..
Podaj adres po czesku, zobaczymy na mapie gdzie to jest od nas.
Nie wiem, ile jest wolnej przestrzeni, więc nie mogę nic zaplanować z meblami. Chcę w końcu zobaczyć to mieszkanie w tym tygodniu, a potem zrozumieć, jakich mebli potrzebuję.
Przepraszam, że tak długo nie odpowiadałem, to był dzień roboczy, trudno się przystosować.
Czy to na razie wystarczy?
Chcę, żebyś była szczęśliwa, chcę, żebyś była bezpieczna i chcę wreszcie być z tobą, żeby mieć możliwość przytulenia cię.
Całować cię rano, mówić, jak ci pasuje.
Jest już łóżeczko i wanienka dla dziecka, kilka rzeczy znalazłam pierwszy raz
Nie zapomnijcie, że obiecaliście mi pomóc, gdy tylko będziecie mieli okazję, ale nie oddawaj ostatni 🤫😟😉🙃
Chcę zrobić fryzurę o nazwie bob.
Oleg zachorował - ma katar i kaszel. Lepiej nie zabieraj ze sobą Jana do nas, żeby się nie zaraził.
Ale będę trochę później - około 8 rano. Mogę?
Nie chcę z tobą żadnych nieporozumień.
Bo martwię się czy wszystko będzie dobrze!?
Bo przy tych wycieczkach nawet o tym nie rozmawialiśmy!
Rozumiem, jakie to dla Ciebie ważne!
I nawet nie mówię o sobie (dla mnie to po prostu nieosiągalny szczyt)!
jak się dzisiaj czujesz? 😅 po imprezie?
cześć, przepraszam, właśnie się obudziłem, nie spałem dobrze
Przepraszam, że przeszkadzam
Byłem zdenerwowany, że Kolya i ja źle zaczęliśmy wczoraj tłumaczyć test.
Poproszę Hryhorija Denysenkę, a może Jonashka)), aby chociaż trochę pomogli mi z pojęciami matematycznymi.
Może mogę się im na coś przydać?
Jeśli jest taka możliwość, chcę przez weekend poprawić swoją znajomość pojęć matematycznych.
Geometria jest generalnie trudna, ale musimy pracować z Kolyą, żeby nie było błędów.
Dziękuję za zadania testowe
Na to też mamy nadzieję
I dlatego jest bardzo zadowolona z każdego prezentu
Chciałem połączyć Internet z moim czeskim numerem
Wczoraj na przystanku autobusowym 402 poznałem Ukrainkę Wiktorię.
Ta dziewczyna to dziecko, ale tutaj jest sama... jej oczy są pełne łez i żalu...
Nie mogłem trzymać się z daleka.
Teraz zgodziliśmy się, że zostaniemy przyjaciółmi.
Wczoraj wieczorem dziękowałem Bogu za tę dziewczynę, bo jest pierwszą osobą z Ukrainy, z którą moje serce poczuło wzajemność.
Oddział w hali nr 29 jest specjalnie przystosowany do składania i rozpatrywania wniosków o pomoc
Okazało się, że zamówiłem zapasową kartę.
Nie kłopocz się, jestem prostym człowiekiem.
Żeby się nie bała, że nikt nie przyjdzie
Nie poszedłem. Tak, sam go upiekłem. Mogę to zrobić! Najważniejsze, że nauczyłeś mnie włączać piekarnik.
Więc wyjeżdżasz z miasta na dłużej?
Pół roku temu w Centrum Pamięci o Holokauście Babyn Yar w Kijowie obchodziliśmy 80. rocznicę masowego rozstrzelania ukraińskich Żydów przez żołnierzy niemieckich w Babyn Yar.
Miałem zaszczyt przemawiać w imieniu trzech głów państw, w tym prezydenta Niemiec.
Mówił o „wspólnej podstawie prawa międzynarodowego i godności ludzkiej, wolności ludzi do wyboru własnej drogi i życia w integralności terytorialnej, o pokojowej i bezpiecznej Europie.
Musimy chronić tę podstawę – to także część naszej odpowiedzialności związanej z naszą historią”.
Jeśli „złe demony przeszłości pojawiają się dzisiaj w nowych ubraniach”, powiedział, „dla nas, Niemców, może być tylko jedna odpowiedź: nigdy więcej!
Walka musi trwać”.
Dziś Rosja zaatakowała pokojowo nastawiony kraj, bombarduje i zabija tysiące cywilów, głodzi mieszkańców blokowanych przez siebie miast i pozwala im umierać z powodu chorób.
Wojska rosyjskie dokonują masowych egzekucji Ukraińców, nawet wizualnie przypomina to egzekucje w Babim Jarze.
Od ponad miesiąca Niemcy widzą to w wiadomościach w czasie rzeczywistym.
Tak, Niemcy stosują sankcje, udzielają pomocy humanitarnej, a także dostarczają broń, co jeszcze nie tak dawno było niewyobrażalne.
Niemcy opóźniają dostawę ciężkiego uzbrojenia potrzebnego Ukrainie.
Ale „Nigdy więcej!” oznacza nie tylko przeciwstawienie się swastyce.
Oznacza to walkę wszystkimi możliwymi środkami z masowymi mordami, ludobójstwem, zbrodniami wojennymi i okrucieństwami.
Bez ryzyka i poświęceń nie ma łatwej drogi do pokonania zła i powstrzymania okrucieństw mających miejsce w Ukrainie.
Jedna piosenka na dobranoc dla ciebie
Zgadzamy się, umawiamy na wycieczkę i piszemy, kiedy powinniśmy być gotowi
Wszyscy byli chorzy, tylko Lydia nie była chora, mieli omicron, nowy typ covida
W takim razie zrobię to jutro
Użyję tego kuponu zamiast karty
Przepraszam za opóźnienie z dokumentami.
Bilet kosztował mnie u konduktora 2000 hrywien.
Serhii Sydorenko: Nasze członkostwo w NATO nie jest już odległą perspektywą
9 lat temu ukraińska socjologia wykazała, że 67% Ukraińców było przeciwnych przystąpieniu do NATO, a tylko 18% popierało to.
Po Rewolucji Godności, ucieczce Wiktora Janukowycza, aneksji Krymu i rozpoczęciu wojny w Donbasie liczba przeciwników NATO zaczęła maleć, a zwolenników wręcz przeciwnie zaczęła wzrastać.
Po rozpoczęciu wojny na pełną skalę z Rosją ukraińscy socjologowie odnotowali rekordowy poziom poparcia dla przystąpienia Ukrainy do NATO wśród obywateli Ukrainy – ponad 75%.
Pomimo poparcia dla przystąpienia Ukrainy do NATO i pomocy, jakiej NATO udziela w warunkach wojennych, obecnie bardzo dużo krytykuje się Sojusz i jego państwa członkowskie – za nieterminowe dostawy broni, odmowę zamknięcia nieba, niechęć do „denerwowania” Rosji.
Ponadto istnieje duże ryzyko, że Ukraina będzie zmuszona zrezygnować z aspiracji do członkostwa w Sojuszu ze względu na stanowisko Federacji Rosyjskiej, jeśli pozwoli to na zakończenie wojny, a Ukraina otrzyma niezawodne gwarancje bezpieczeństwa, w tym m.in. wojskowe.
W nowym odcinku podcastu „Damn Questions” wspólnie z redaktorem „European Truth” rozmawiamy o tym, jak dokładnie Sojusz pomógł Ukrainie od czasu rosyjskiej inwazji, dlaczego należy krytykować NATO, dlaczego Sojusz jest krytykowany na próżno, dlaczego nasza perspektywa członkostwa w NATO jest bliższa niż kiedykolwiek w historii i dlaczego gwarancje bezpieczeństwa omawiane w negocjacjach z Rosją mogą stać się drugim Memorandum Budapeszteńskim.
Jak myślisz, co tu jest?
Mój partner Wolt mówi, że moja aplikacja jest w toku.
Przesłałem go za pośrednictwem tej aplikacji mobilnej.
Nie mamy wizy, musimy iść do Centrum Kongresowego i dowiedzieć się, jak to zrobić, bo była wydana w Polsce, gdzie wizy nie dali, dali tylko pesel.
Na pewno do Ciebie napiszemy!
Denis wyszedł dzisiaj w dobrym nastroju.
Umówiłem się z chłopakiem z Ukrainy, którego poznałem wczoraj, na spotkanie obok szkoły, żeby mu wszystko pokazał.
Więc mam nadzieję, że nic mu nie jest
Ponieważ nie kocham go w ten sposób, nie wytrzymam tego długo
Ukraina informuje, że Czechy wysłały na Ukrainę czołgi T-72 i bojowe wozy piechoty.
Idę, zostawiam dzieci same, czekam tam 3-4 godziny i wracam do domu, bo nie mogę ich zostawić samych na dłużej.
I muszę je zabrać ze sobą na 6-7 rano.
Tak, serce było chore.
Miałam szczere uczucia do tej osoby, ale nie zachowywał się zbyt przyzwoicie i zostawiłam go.
Po jakimś czasie znowu wrócił i prosił o moje wybaczenie.
Odrzuciłam go.
Po czasie zadzwonił, że przeszedł operację serca.
Poprosiłam go, żeby po prostu ze mną porozmawiał, było mi go żal.
Wspierałam go psychicznie przez prawie pół roku.
Przez ten czas dużo rozmawialiśmy.
W tym samym czasie zaczęłam mieć problemy w pracy.
Jego wsparcie również mi pomogło w tym czasie.
Taka wzajemna pomoc.
I pomyślałam, że może naprawdę powinnam spojrzeć na niego inaczej.
I oświadczył mi się, a dwa dni później zmarł.
Dlatego sam Bóg zdecydował o naszym przeznaczeniu.
Co oznacza dla ciebie gotowość do małżeństwa?
On mówi tylko po czesku.
Chciałam powiedzieć, że udało mi się znaleźć mieszkanie i bardzo się z tego cieszę ☺ Mam teraz gdzie mieszkać i gdzie zatrzymać się z dzieckiem.
Czy powinienem był przypomnieć sobie to wcześniej?
)) W końcu pomagałem zajmować się dziećmi w rodzinie.
Nie przepraszaj. Po prostu napisz, których zdań nie zrozumiałeś.
Sam rozumiem, że tłumacz nie zawsze poprawnie tłumaczy tekst.
Nie wiem jak rozmawiać z lekarzem, czy powinna dać papier?
Goście musieli go zostawić, schowałem do szafy.
To chyba czas, żebyś poszedł spać, żebyś mógł jutro pracować.
Czy ktoś może pomóc? Potrzebuję ubrania dla kobiety, rozmiar XS lub S, wzrost 165. Oraz dla jej córek (8, 10, 12 lat). Dziękuję.
W tym czasie kupiłam dwie paczki w Lidlu i moja mama kupiła dwa.
To bardzo miłe z twojej strony, dziękuję.
Pocieszyłeś mnie.
Dobra, porozmawiajmy o czymś innym, bo kiepsko sypiam, a jak zasypiam to w snach widzę bombardowania…
Bóg nigdy się nie spóźnia, wszystko ma swój czas i miejsce.
Chyba nie chce mnie okraść :)
Doskonale rozumiem cenę niewykwalifikowanej siły roboczej i rozumiem, że nie będę mógł mieć tutaj takiej pracy, jaką miałem w domu w Kijowie, i nie otrzymam tu też pieniędzy, które zarabiałem w domu.
Ale nie mogę tak po prostu siedzieć i nic nie robić, bo wtedy różne złe myśli wkradają się do mojej głowy, więc muszę zająć się jakąś aktywnością fizyczną
Na lotnisku dokumenty są przetwarzane od 7:00 do 19:00, w innych godzinach możesz tylko poczekać.
Wołodymyr wrócił o 4 rano.
Dlatego zabraliśmy ich do nas.
Vika i ja spaliśmy w kuchni, położyliśmy ich do snu w sypialni.
Skończę pracę i pojadę z nimi na lotnisko.
Jak będziesz to miał to napisz do mnie a dowiesz się co dalej...
Bo nie mogę znaleźć dla siebie miejsca
Proszę pana, oto zaproszenia ukraińskich dzieci, które pójdą do gimnazjum.
Tak, ale robię to, to trudne.
Ok, napisz kiedy będzie Ci pasować😘
Nie wiem jeszcze jak z pracą. Chciałbym oczywiście, jeśli zorganizuję dzieciom przedszkole i szkołę.
Tak to zaplanowaliśmy. Czy lepiej czasem zmieniać zmiany?
Przepraszam. Naprawdę nie miałem żadnych nieodebranych połączeń od środy. Przepraszam, czy możemy umówić się na inny termin?
Oferuję pracę, sprzątanie łazienki i toalety, umycie 3 okien, wycieranie kurzu.
Praca trwa około 3-4 godzin. Kwota wynosi 800 UAH jednorazowo. Od wtorku 19.04 od godziny 14:00.
Mam nadzieję, że mogę powiedzieć, że wszystko z nami dobrze.
Czy mogę do Ciebie zadzwonić?
Lub czy możesz napisać mi kontakt do Twojej żony?
Grishko zaczął kaszleć, chcę zapytać, co mogę kupić w aptece.
Chcę zapytać o radę.
W naszym kraju Hanna jest uważana za rodzimą formę imienia Anya.
Wujek przysłał jej to z domu
Stworzyłem wersję angielską, dodałem nowych partnerów
Napisz do niego, gdybyś czegoś potrzebował.
tylko nie zapomnij o mnie, proszę🙏🏻
Czy zajęcia w poniedziałek i środę różnią się?
Dziękuję bardzo. Robisz dużo dla naszej rodziny! Wszyscy jesteśmy Ci nieskończenie wdzięczni.
Potrzebujesz certyfikatu, żeby być w basenie.
Ale to moja opinia.
Wujek przysłał jej z domu wrotki i deskorolkę, jeździła na nich w domu, więc ma.
Ja też wstałam o 9 rano i właśnie robię śniadanie.
Bardzo mi wstyd, że rozmawiasz ze mną w swój dzień wolny. Mam nadzieję, że nie jestem zbyt irytujący.
Chcielibyśmy poinformować o zmianie miejsca zamieszkania i jednocześnie złożyć dokumenty do przedłużenia karty.
Obecnie dostarczamy tlen medyczny do wszystkich szpitali w naszym kraju.
I zapomniałem ci powiedzieć, że jutro będzie przekąska.
Jedna mama powiedziała, że upiecze pączki z dżemem dla dzieci.
Przyjeżdża cię odwiedzić.
Powiedz mi, czy masz przynajmniej przybliżony harmonogram sprzątania mieszkań na miesiąc do przodu, aby zrozumieć przynajmniej w przybliżeniu, które dni?
Nie zapamiętam tego harmonogramu w żaden sposób
Rosyjska armia grozi atakiem rakietowym na Kijów: mówią „nigdy wcześniej tego nie robili”
Bezpośrednie przemówienie Konaszenkowa: „Widzimy próby sabotażu i uderzenia wojsk ukraińskich na obiekty na terytorium Federacji Rosyjskiej.
Jeśli takie przypadki będą się powtarzać, siły zbrojne Federacji Rosyjskiej uderzą w ośrodki decyzyjne, w tym w Kijowie, od czego armia rosyjska wcześniej się powstrzymywała”.
Rosjanie przeprowadzali ataki rakietowe na Kijów od pierwszych dni pełnej inwazji sił okupacyjnych Federacji Rosyjskiej na Ukrainę.
25 lutego pozostałości rosyjskich pocisków zestrzelonych przez ukraiński system obrony powietrznej spadły na apartamentowiec w dzielnicy Poznyaki w stolicy.
26 lutego rosyjski pocisk trafił w wieżowiec przy Alei Walerego Łobanowskiego.
1 marca Rosjanie uderzyli w wieżę telewizyjną na Dorohożyczach koło Babynego Jaru, w wyniku czego zginęło 5 przechodniów.
2 marca ukraińskie systemy obrony powietrznej zestrzeliły rosyjskie rakiety lecące w kierunku budynku Ministerstwa Obrony nad Dworcem Południowym.
14 marca fragmenty zestrzelonego pocisku okupanta zmiażdżyły dom i trolejbus na Kureniwce w Kijowie.
18 marca rosyjski pocisk uderzył w dzielnicę mieszkalną w Wynogradarze, zabijając jedną osobę i raniąc 19 innych, w tym czworo dzieci.
21 marca rosyjskie pociski całkowicie zniszczyły nowoczesne centrum handlowe Retroville w Wynogradarze, w wyniku czego zginęły co najmniej 4 osoby.
Burmistrz Kijowa Witalij Kliczko 13 kwietnia po raz kolejny stwierdził, że dla ewakuowanych z miasta mieszkańców stolicy jest jeszcze za wcześnie na powrót.
Wojsko tłumaczyło lokalnym władzom, że Rosjanie wciąż mogą atakować Kijów rakietami, a poza tym na obrzeżach stolicy jest dużo min i niewybuchów z amunicją.
Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy 12 kwietnia ostrzegł, że Rosjanie planują serię ataków terrorystycznych na terytorium Federacji Rosyjskiej, aby zrzucić winę na Ukraińców i usprawiedliwić brutalność rosyjskiej armii wobec ludności cywilnej.
1 kwietnia, w pobliżu Biełgorodu w Rosji eksplodował skład ropy naftowej, rzekomo w wyniku ataku lotniczego ukraińskich helikopterów.
Na początku kwietnia lokalne władze Biełgorodu ogłosiły, że w pobliżu miasta miał spaść „ukraiński pocisk”.
Oczywiste jest, że elity zarówno w Waszyngtonie, jak i Berlinie oblewają się zimnym potem na samą myśl, że myśliwce NATO zestrzelą rosyjskie bombowce na niebie nad Ukrainą.
Ale Zełenski mówi nie tyle do nich, co do ich wyborców i społeczeństw w ogóle.
Swoimi przemówieniami w parlamentach i przed tysiącami tłumów na placach największych miast Europy ukraiński przywódca robi coś, czego do czego zdolny nie był żaden z jego poprzedników.
Zełenski nie przekonuje europejskich polityków, by zrobili wszystko dla Ukrainy, przekonuje Europejczyków, którzy wybierają tych polityków.
I te przemówienia, ta wyrafinowana mieszanka mocy, wzruszenia, a czasem rozpaczy, stopniowo osiągają swój cel.
Podczas gdy ten sam Biden kategorycznie sprzeciwia się zamknięciu nieba, to już 70% jego współobywateli popiera ten pomysł.
Choć Paryż czy Bruksela sprzeciwiają się przyspieszeniu wstąpieniu Ukrainy, proces ten już trwa.
Rozumiem Cię, dlatego nie chcemy być uważani za oszustów.
Zebrane przez Ciebie pieniądze lepiej przekazać ludziom w większej potrzebie.
Mogę przyjechać do Ciebie i na miejscu podejmiemy decyzję. W każdym razie chcę pomóc.
Ale powietrze jest czyste, to plus😀
Jest tam napisane, że mam taryfę „Razem dla dwojga bez Internetu”, ale wręcz przeciwnie poprosiłem o założenie Internetu.
Nie rozumiem warunków taryfy
Czy mamy dzisiaj jakieś inne pokoje? Czy tak jak zwykle tylko schody od góry do dołu?
Już jadę, nie, chodź, jadę pociągiem.
Ale nie przestanę cię kochać, znaczysz dla mnie wszystko.
Ta pożyczka jest obsługiwana przez doradcę finansowego.
Trwa to więc kilka dni.
Katya poprosiła o Internet, czy możesz podać jej hasło?
Myślałem, że nie poznałeś Milany.
Świetnie, w takim razie mąż mnie podwiezie, ponieważ ma dzisiaj samochód z firmy budowlanej, w której pracuje.
Jesteśmy bardzo szczęśliwi i wdzięczni, że nasza Nika i wnuki są pod Waszą opieką!
Bardzo dziękuję za zaproszenie!
Mamy też nadzieję, że po wojnie będziemy mogli Was zaprosić na Ukrainę!
jedną należy pokroić na 4 części
jedna z tych części może być używana przez 2-3 dni, ale należy ją płukać co godzinę
Interesuję się architekturą i kolorystyką.
Bardzo się cieszę, że u Ciebie wszystko w porządku.
Prawdopodobnie o 16:20, koncert zaczyna się o 18, a potem znowu jestem wolny.
I teraz mam ochotę zjeść coś słodkiego
więc zrobię herbatę i objem się słodyczami
Weszłam na stronę szkoły i teraz spróbuję zamówić obiad dla Ani na jutro.
Ale uwielbiam dużo chodzić na spacery w weekendy.
Więc możemy tam pojechać jutro i poznać warunki?
Nazywam się Sasza i przyjechałem z Ługańska do Pragi.
Jestem dyplomowaną terapeutką i pielęgniarką z 27-letnim doświadczeniem w dziedzinie neurologii.
Oferuję masaże lecznicze, siłownię rehabilitacyjną dla dzieci i dorosłych.
Rozmawiam po ukraińsku, rosyjsku i czesku oraz intensywnie się uczę.
Kontakt: ------ Prosiłbym też o list, żeby Czesi też mogli do Ciebie pisać przez tłumacza, SMS-y tu nie działają, nie mają ukraińskiej klawiatury, a jak zadzwonią, to nie nie zrozumiecie się nawzajem.
Naprawdę nie chcesz takiej ceny?
Naprawdę pomaga ludziom zobaczyć, ile są warci i co mają za to.
Jeśli nie potrzebujesz cennika, nie podam go.
Powiedz mi, jak to chcesz, a ja to zrobię.
A propos, nie chciałeś dzisiaj do mnie pisać... z jakiegoś powodu
Nie martw się, nie przyszedłem o nic prosić.
Dokładniej, dzisiaj proszę tylko o waszą uwagę.
Mam dziś dużo do powiedzenia, dlatego też proszę o cierpliwość.
Czy dobrze sobie radzisz ze swoją wyobraźnią??
Żyjesz normalnie, chodzisz do pracy, planujesz zakupy, wakacje.
Masz marzenia.
Planujesz kupić sukienkę, którą widziałaś wczoraj w sklepie.
Jutro wieczorem, po pracy.
Twój mózg nie może sobie z tym poradzić.
Trzyma się starej rzeczywistości.
Dzwonisz do pracy, aby dowiedzieć się, czy powinieneś iść dzisiaj do pracy, czy nie.
Decydujesz się zostawić dzieci w domu.
Dopóki coś nie stanie się jasne.
Jest nadzieja... to nie potrwa długo.
Teraz... zgodzą się... coś się stanie.
Mózg odmawia zaakceptowania…
Gdzie iść?? Nie mam nigdzie nikogo.
Mam 50 dolarów w kieszeni. Wszystko co mieliśmy w domu wydaliśmy.
Wiele osób nie otrzymywało wynagrodzenia od swoich menedżerów w pracy.
Gdzie powinienem pójść?? Kto mnie potrzebuje? Jak powinienem zapewnić swoim dzieciom? Gdzie mam mieszkać?
Nie możesz wziąć wielu rzeczy.
Nie zabrałeś prawie nic z domu... masz 1000 kilometrów do przejechania.
Nie wiesz, czy jutro będziesz miał czym je nakarmić, czy nie.
Codziennie, od rana do wieczora ciągniecie dzieci po całej Pradze.
I co dalej? Nie wiadomo. Jak długo? Nie wiadomo. Dzieci proszą o słodycze. I nie możesz im tego dać. To dla ciebie drogie.
A wszędzie mówią – nie mamy.
Mamy wybór - zostać tam i narazić dzieci na niebezpieczeństwo, albo spróbować ratować się tutaj.
Była bardzo zadowolona z serc i rzeczy, które dzieci dały jej, kiedy przyszła do szkoły.
Powinieneś był do mnie zadzwonić, kiedy przyjechałeś.
Napiszę do Ciebie wieczorem
Tak, wierzę tylko w Boga i Jemu powierzam swoje życie.
Nie mam już siły na to wszystko.
Już myślałem, że zakochałeś się w jakiejś Ukraince i nie masz czasu na komunikację
Zrozumiałem menu, nawet złożyłem zamówienie
2. Czy byłbyś zainteresowany dołączeniem do zajęć z czeskimi sąsiadami, przyjaciółmi, społecznością?
Jeśli tak, to jaki rodzaj.
Proszę o przesłanie strony z wizą lub stemplem wjazdowym (czerwony z datą).
Bez wizy uchodźczej nie możemy udzielać pomocy humanitarnej.
Pani Libusche, czy zapłaciła pani za żłobek?
Ponieważ nie mogę zrozumieć.
Robisz dla nas tyle dobrego…..
Wiele Ci zawdzięczamy... dziękujemy!
Tak, rozumiem, że to jest bardzo dobre.
Teraz wyślę Ci zdjęcie wizytówki Pani, którą uczę angielskiego.
No to napisz jutro czy się spotkamy czy nie, może Twoje plany się zmienią...
Dzień dobry. Mamy wystarczająco dużo zasobów. Byłoby bardzo dobrze poznać kogoś z Ukrainy.
Jeśli chcesz, możesz zostać ze mną po pracy.
Czy jesteś jutro zajęty? Nie chcesz się spotkać po 16:00?
Jakie są Twoje ogólne wrażenia z pierwszego tygodnia?
Karina przyniosła nam przedwczoraj lekarstwo i je bierzemy.
Mogę pracować z obłożnie chorymi pacjentami i niepełnosprawnymi dziećmi
Ale trzeba zaznaczyć, że mówię tylko po rosyjsku i ukraińsku.
Nie mam tego
Czy mogę prosić o Twoje mydło do prania?
Ponieważ jest tu tylko żel antybakteryjny.
Nie powiem dokładnie, bo jeszcze nie bardzo orientuję się w mieście... około wpół do jedenastej
Jakie usługi/działania są Twoim zdaniem potrzebne/brakujące osobom starszym?
Nie wiem, bo jeszcze nie dostałem SMSa z banku i jeszcze nie wziąłem karty bankowej, a dzieci skasowały wniosek bankowy, co mnie bardzo zdenerwowało.
to proszę napisz mi kiedy będziesz jechać 🙏🏻
Dziś mamy radość - nasze miasto Bucza zostało wyzwolone od najeźdźców, wkroczyły nasze wojska.
Trwa obława nieprzyjaciela - szukają Rosjan w piwnicach i mieszkaniach.
Całe miasto jest zaminowane, rozpocznie się rozminowywanie.
A Ivan sprawdzał tam czy coś nie musi być naprawione lub czy czegoś jeszcze nie trzeba zrobić.
Diano, jak chcesz. Może będzie czuł się nieśmiały, nie wiem.
Nasz Panas chce zostać w domu, mówi, że jest nami zmęczony i chce być sam, kiedy gdzieś pojedziemy bez niego.
Upieczemy mazanety i zrobimy lekcje.
To mali przedsiębiorcy, którzy w swoich lokalach i sklepach otworzyli siedziby wolontariatu.
To kierowcy traktorów, którzy faktycznie wyjeżdżają na pole pod ostrzałem, bo czas siać.
To kierowcy autobusów, którzy zgadzają się pojechać dziś w konwojach humanitarnych na tereny czasowo okupowane, by nieść pomoc i odbierać stamtąd ludzi.
To bohaterscy konduktorzy, którzy bez strachu jadą do strefy wojny, uspokajają i pomagają uchodźcom w wagonach, a na pokojowych stacjach pomagają wolontariuszom załadować pomoc humanitarną do wagonów.
To pracownicy stacji benzynowych, którzy w pierwszych dniach wojny stali na autostradzie w Żytomierzu i cierpliwie obsługiwali przestraszonych i zdenerwowanych ludzi.
To pracownicy fizyczni, którzy pod odstrzałem usuwają śmieci, naprawiają rury wodociągowe i linie energetyczne, aby zapewnić ludziom niezbędne rzeczy.
To lekarze i pielęgniarki, którzy ratują ludzi 24 godziny na dobę, bez narzekania, a w swoim wolnym czasie są także wolontariuszami, zbierając apteczki na front.
W Ukrainie, sok zatrzymuje się gdy liście są małe.
Powiedz mi, proszę, małe dzieci - jaki wiek masz na myśli?
Moja córka ma 8 lat, czy ten wiek jest akceptowalny?
Szukam zakwaterowania dla mojej córki i dla mnie na 3-4 dni, aby przyjechać do Czech i przekazać nasze paszporty do załatwienia wiz w Kanadzie.
W Warszawie w centrum wizowym jest dużo ludzi, a kolejka online nie działa.
Chciałem przyjechać na jeden dzień, ale to daleko, podróż pociągiem zajmuje dużo czasu, będzie to ciężkie dla dziecka.
Dlatego zdecydowałem się poszukać noclegu w Pradze lub okolicach.
Nie, wszystko nam pasuje
Gdzie umieścić wczorajsze urządzenia?
Ale nie mogę zmienić hasła, gdy klikam na link, ponieważ pojawia się ten błąd:
Jest w mikrofalówce, coś się tam spaliło
W Ukrainie operatorzy największych banków są zawsze w kontakcie z klientami 24 godziny na dobę, a wszystkie problemy rozwiązywane są natychmiast :)
No nic, przyzwyczaję się do nowych realiów
Czuję się źle i chcę, żebyś o tym wiedział
Możesz edytować post. Najważniejsze, że to jest prawda.
Tak, telewizja jest tego pełna
Zgodziliśmy się już na lodówki, jacyś Czesi odpowiedzieli, przyjadą o 13:00 i pomogą je wnieść. 👍👍👍
Chcę do Ciebie przyjść. Przytulić Cię mocno. I pocałować 😘
O 7.30 czytam historię teatru światowego aktorom, reżyserom i znawcom teatru
wieczorem oceniam projekty. Po tym zjem kolację
Grishko jeszcze śpi, dużo płakał w nocy, ząbkuje.
Jestem teraz w kontakcie telefonicznym ze wszystkimi, których znam ze Lwowa, wiele osób zginęło.
Czechy zaczęły wydawać wizy po 22 marca, o ile się nie mylę.
Do tego czasu umieszczano stemple, a następnie znaczki, które utożsamiano z wizami
Zagraniczny Okręg Wyborczy Ukrainy (FED Ukrainy) jest okręgiem wyborczym, który skupia lokale wyborcze znajdujące się poza terytorium Ukrainy i składa się z lokali wyborczych w ambasadach i konsulatach Ukrainy oraz lokali w bazach wojskowych za granicą [przypis 1], w których przebywają ukraińskie kontyngenty pokojowe (Kosowo i DR Kongo).[1] Funkcję obwodowej komisji wyborczej dla zagranicznego okręgu wyborczego pełni Centralna Komisja Wyborcza.
W Zagranicznym okręgu wyborczym odbywają się tylko głosowania ogólnokrajowe: wybory Prezydenta i Deputowanych Ludowych oraz ogólnoukraińskie referendum.
Wybory lokalne nie odbywają się w FED.
Są na stacji w pobliżu pokoju dla matki z dzieckiem.
Mówi, że nie rozumie już, dokąd powinni pójść.
Jesteś na mnie zły?
Usunę zdjęcie w kostiumie kąpielowym.
Nie potrzebuję już pieniędzy, pożyczyłem je od dawnego przyjaciela 😊
Chciałem powiedzieć, że już połączyłem czeski numer komórkowy.
Nie potrzebowałem do tego innego urządzenia, poszedłem do operatora O2 i zrobili mi elektroniczną kartę SIM, którą podłączyłem do mojego telefonu, więc nie potrzebuję innego urządzenia.
Dziękuję. Nie jest to dla mnie wygodne, pracuję tydzień i już nie mogę.
Powiedziałeś, że twoja pralka się zepsuła. Weź to dla siebie. Ty też tego naprawdę potrzebujesz
Nie mamy wystarrczająco kocy, kołder, talerzy. Dzieci nie mają piżam i butów na zmianę.
Dzień dobry, wyjeżdżam o 10... napisz ponownie adres, zgubiłem gdzieś SMSa.
Nie chcę torturować Ciebie ani siebie, jakoś to przeboleję
Tak, byłoby dobrze, ale wiem, że nie było wolnych miejsc i w zasadzie teraz mają wszystkie lekcje zgodnie z planem i są uczeni całkiem nieźle.
Masz maszynkę do mielenia mięsa? My mamy, ale nie działa.
Dobrze, to niech będzie po Wielkanocy
Twoja mama powiedziała wczoraj, że coś cię boli?
Nie może im powiedzieć wszystkiego, co by chciała i nie rozumie wszystkiego, co mówią (Ale wczoraj przyszła w świetnym humorze po targach.
Byłem też dzisiaj w szkole.
Widziałem dzisiaj matkę Christiny, ale nawet się nie przywitała (
Bardzo smaczne jabłka, co to za odmiana?
Szef Kancelarii Prezydenta Andriy Yermak powiedział, że Rosja rozpoczyna „fałszywą operację” dotyczącą broni, którą przekazują nam sojusznicy.
Bezpośrednie przemówienie Yermaka: „Rozumieją, że przegrają wojnę, widzą swoje zacofanie i wszelkimi sposobami starają się „strącić ”dostawy broni.
Na przykład jednym z najnowszych kłamstw/fałszerstw jest rzekome zniszczenie przekazanych przez Słowację systemów obrony powietrznej S-300.
Te informacje zdementował już premier Eduard Heger.
Co się stanie dalej? Znamy scenariusze Rosjan. Wymienię jeden z nich.
Mogą wypuszczać na rynek kłamstwa, że rzekomo ukraińscy żołnierze poddają się wraz z bronią od aliantów i są masowo przerzucani do armii rosyjskiej.
Chcę natychmiast zapobiec takim kłamstwom.
Ponieważ broń w rękach żołnierzy Sił Zbrojnych Ukrainy wyłącznie wysyła wroga na tamten świat.
Przepraszam, zapomniałam zapytać ile będzie kosztowało przedszkole miesięcznie i czy będzie otwarte latem?
Każdemu jest dane zgodnie z jego siłą.
Jest wiele smutniejszych historii, uwierz mi.
Musiałem więc przeżyć takie wydarzenia, aby się zmienić.
W Torze jest napisane, że Bóg stworzył w człowieku zły początek, aby w ciągu życia zmieniał się duchowo, stawał się lepszy
To twój dom, możesz zapraszać kogo chcesz)
Jak znaleźć tą panią w sieci? Chcieliśmy jutro odwiedzić ratusz przed pójściem do szpitala
Posłuchał mamy i nie poszedł z nami
Wiem, że nie było ci łatwo.
I zrobię wszystko, żebyś był szczęśliwy.
Po tym, jak dzisiaj do mnie napisałeś, jestem szczęśliwa.
Mam nadzieję, że mówiłeś poważnie 💞
Patrzę na ogłoszenia, dużo jest już zajętych. Teraz jest trudno, taki jest nasz los.
Przepraszam, nie do końca zrozumiałem pytanie
Nie udało Ci się dzisiaj zadzwonić w sprawie zmiany taryfy operatora komórkowego?
Przepraszam, ale nie mogę polegać na nikim w tym życiu
Dzisiaj zaproponowano mi pracę na każdy dzień.
Przepraszam, ale już zgodziłem się tam pracować.
Dziękuję za odpowiedź i życzę znalezienia dobrej asystentki 😊
Może twój tata powiedział Ci, że niektórzy z nas są Świadkami Jehowy, ale ja nie praktykuję żadnej religii.
Jednakże zostałem ochrzczony w cerkwi prawosławnej.
Szanuję wszystkie religie oparte na miłości.
Czytałem Biblię, Koran, zacząłem czytać Torę.
Wierzę, że nie ma pośredników między człowiekiem a Bogiem.
Możesz też pomyśleć o niestawianiu lodówki obok drzwi do pokoju chłopców.
Dziękuję Ci bardzo, bardzo mi pomogłeś.
Szukamy pomocy od państwa na regularne sprzątanie domu, tutaj we wsi.
Oferta 150 koron/godzinę. Kolejna współpraca z nimi. Ustal datę z Panią.
Farba z amoniakiem dostała mi się do oka. Boję się oparzeń chemicznych. Czy lekarz może mnie zbadać?
Martwię się tylko tym jak będziemy się ze z Tobą komunikować.
Ale możemy po prostu na siebie popatrzeć😄 tylko żartuję
Jechałam sama do mojej mamy, moja siostra i jej przyjaciółka też miały iść, a Anastazja poprosiła, żeby pójść z nimi
A gdzie masz dobrego fryzjera?
Dzień dobry, Wiktor zaakceptował ten dom, ale nie wie, jak pomóc temu panu z dokumentami do otrzymania płatności od państwa i powiedział, że jeśli chodzi o bank mebli to nie ma tam jeszcze dostępnych mebli
Ale jestem bardzo wdzięczny za gościnność z Twojego serca.
My też mamy tu dobrych lekarzy.. Do widzenia
Gotowaliśmy już jedzenie w domu. I nie możemy znaleźć kluczy na strych
Wezmę pościel dla piątego gościa, a czy w apartamencie jest dodatkowa poduszka i koc?
Tak, ale jak się skontaktować z właścicielami? Nie ma żadnego kontaktu, potrzebuję mieszkania na dłuższy czas, pracujemy i możemy zapłacić. Pomóż, jeśli możesz.
Na końcu każdego opisu jest kontakt do właściciela.
Możesz użyć tego tłumacza online z ukraińskiego na ukraiński i odwrotnie żeby się komunikować.
Nie ma to dla mnie znaczenia, obecnie jest nas czterech w jednym łóżku w pokoju, w którym nie ma nawet możliwości poruszania się, bardzo dziękuję.😢
Więc, kliknąłeś w linki, które wysłałem ci powyżej?
W każdym z nich masz darmową ofertę mieszkania, opis, kontakt do właściciela oraz zdjęcie.
Nie mogę znaleźć kontaktu, tylko e-mail, niestety nie mogę nic znaleźć, które zakwaterowanie jest bliżej Český Krumlov, pracujemy w Český Krumlov, a teraz mieszkamy w Pradze
Wtedy ci nie pomogę. W Brnie nie ma szans. Najbliższe i przedostatni nocleg jest w Pereczynie
Dziękuję za pomoc, znaleźliśmy miejsce do zamieszkania, ale potrzebujemy łóżka i sofy. Może powiesz mi, gdzie możemy kupić coś, co nie jest drogie, ponieważ nasz budżet jest mały? Bardzo Ci dziękuję.
Czy można powiedzieć, że źle się odżywia i często boli go brzuch? Rano nie może jeść - ma mdłości.
Widziałem twoją publikację o Music Project.
Jestem dyrygentem chóru Narodowego Uniwersytetu Pedagogicznego imienia Dragomanowa.
Chętnie podejmę współpracę.
Tymczasem Rosja rozmieściła swoje systemy rakietowe na granicy z Finlandią.
Chcą wypróbować nie tylko ukraińskiego penisa, ale też fińskiego.
Będę najszczęśliwszy gdy będę z Tobą.
Kiedy budzę się obok ciebie
Całuję cię i mówię: „Dzień dobry, kochanie, wyglądasz bardzo pięknie”.
Gdzie mogę kupić czapkę z ruszającymi się uszami?
Dzisiaj jest dużo pracy.
Czy nie za bardzo cię powstrzymujemy?
Czyli nie trzeba wysyłać listem poleconym?
Wystarczy, że się z nią komunikujesz, a ja chcę cię zrozumieć
Teraz zajrzę i jej powiem
Ale dobrze, że u Was wszystko dobrze, inaczej być nie może!
Ona leży w łóżku, Saszka dekoruje dla niej kuchnię balonami) może nastrój się poprawi
To bardzo ciężkie ciasto, z lukrem na wierzchu
Tu jest napisane, że to prośba o przyjęcie pomocy humanitarnej.
Wniosek należy wypełnić w Urzędzie Pracy Republiki Czeskiej.
I trzeba pokazać ten kod kreskowy.
Czyli prośbę złożyłem przez internet, ale żeby złożyć wniosek, muszę iść do Urzędu Pracy.
Planuję w poniedziałek.
Kupiłem numer w Vodafone.
W tym dniu bardzo tęsknię za moim Slavikiem (
Gdzie jesteś? Wrócisz jutro?
Dziecko od tygodnia ma wysoką temperaturę i suchy kaszel. Dziś narzeka na ból ucha.
Jak ci dziś mija dzień? Chcemy się z Wami zobaczyć i już za Wami tęsknimy.
Czy interesowałeś się tym, jak wszystko wpływa na nasze mózgi i powstawanie nowych połączeń neuronowych?
Kształtowanie nawyków?
Trwa rekrutacja na sezon zbioru szparagów w okolicach Mělníka. Mieszkanie jest zapewnione, zarobki dobre. Więcej informacji pod numerem telefonu 729 725 522 498 168
Posprzątaliśmy cały pokój i przenieśliśmy się do drugiego. Pokój jest wolny. Bardzo Ci dziękuję 🙏🙏🙏
Społeczność międzynarodowa nadal wyraża szok i oburzenie po tym, jak pojawiły się dowody, że siły rosyjskie dopuściły się okrucieństw wobec ludności cywilnej na Ukrainie, a Moskwa odrzuca doniesienia jako „prowokację”.
„Doniesienia o ukraińskich cywilach zabitych, zgwałconych i ciężko rannych przez rosyjskie siły są godne ubolewania” – 4 kwietnia powiedziała dziennikarzom w Wellington premier Nowej Zelandii, Jacinda Ardern.
„Rosja musi odpowiedzieć światu za to, co zrobiła” – dodała, zauważając, że jej rząd będzie dyskutował o dodatkowych środkach wspierających Ukrainę w walce przeciwko rosyjskiej inwazji.
Premier Japonii Fumio Kishida nazwał te incydenty „pogwałceniem prawa międzynarodowego”.
Oświadczenia pojawiły się po tym, jak pojawiły się informacje, że setki cywilów zostało zastrzelonych i wrzuconych do masowych grobów lub pozostawionych na ulicach na przedmieściach Kijowa, w Buczy przez wojska rosyjskie, które wycofały się z tego obszaru po tygodniach okupacji.
Zdjęcia, które rzekomo przedstawiały ciała straconych cywilów ze związanymi rękami, zszokowały wielu i doprowadziły do wezwań do zwiększania sankcji wobec Rosji i ścigania osób odpowiedzialnych.
Prezydent Francji Emmanuel Macron powiedział 4 kwietnia w wywiadzie radiowym, że istnieją przesłanki, że siły rosyjskie popełniły „zbrodnie wojenne” w Buczy.
„To, co wydarzyło się w Buczy, wymaga nowej rundy sankcji i bardzo jasnych środków” – powiedział Macron, dodając, że dodatkowe sankcje powinny dotyczyć eksportu rosyjskiego węgla i ropy.
Premier Hiszpanii Pedro Sanchez powiedział, że rosyjskie wojska mogą posunąć się nawet do „ludobójstwa” w Buczy.
„Zrobimy wszystko, aby ci, którzy popełnili te zbrodnie wojenne, nie pozostali bezkarni” – powiedział Sanchez w Madrycie.
Przemawiając w telewizji państwowej 3 kwietnia późnym wieczorem, rzeczniczka rosyjskiego Ministerstwa Spraw Zagranicznych Maria Zacharowa odrzuciła zarzuty jako „prowokację”.
Twierdziła, bez dowodów, że Stany Zjednoczone i NATO „zleciły” te obrazki żeby zdyskredytować Rosję.
„W tym przypadku wydaje mi się, że fakt, że te oświadczenia padły w pierwszych minutach po pojawieniu się tych materiałów, nie budzi wątpliwości, kto „zlecił” tę historię” – powiedziała Zacharowa.
Wcześniej, rosyjskie Ministerstwo Obrony stwierdziło bez dowodów również, że wizerunek Buczy był „kolejną inscenizacją kijowskiego reżimu” i że wszystkie wojska rosyjskie opuściły miasto przed 30 marca.
Moskwa poprosiła Radę Bezpieczeństwa ONZ o spotkanie 4 kwietnia w celu przedyskutowania tego, co nazwała „prowokacją ukraińskich radykałów” w Buczy.
4 kwietnia Komitet Śledczy Rosji opublikował oświadczenie, w którym zapowiedział „śledztwo” dotyczące oskarżeń wobec Ukrainy o rozpowszechnianie „świadomie fałszywych informacji” o działaniach wojsk rosyjskich w Buczy.
Prezydent Ukrainy Wołodymyr Zełenski zabrał głos 3 kwietnia, oskarżając rosyjskie wojska o popełnienie „ludobójstwa” w mieście i powiedział przywódcom Kremla, że powinni przyjechać do Buczy, aby zobaczyć, co zrobiło ich wojsko.
„Chcę, aby wszyscy przywódcy Federacji Rosyjskiej zobaczyli, jak wykonywane są ich rozkazy” – powiedział Zełenski w wiadomości wideo, przechodząc z języka ukraińskiego na rosyjski.
I jest wspólna odpowiedzialność.
Za te morderstwa, za te tortury… Za strzały w tył głowy” – powiedział.
Stwierdził, że prezydent Rosji Władimir Putin i rosyjska armia powinni ponosić odpowiedzialność za działania wojsk na Ukrainie.
„Kiedy znajdujemy ludzi ze związanymi z tyłu rękami i ściętymi głowami, nie rozumiem” – powiedział o ofiarach rozsianych na ulicach Buczy, miasta położonego około 35 kilometrów na północny zachód od Kijowa.
2 kwietnia, korespondent ukraińskiego Radia Wolność zauważył na ulicach małego miasteczka ciała osób wyglądających na cywilów.
Tylko w jednym miejscu korespondent zobaczył na ulicy do 10 ciał.
Reporterzy AP widzieli ciała co najmniej 21 osób w różnych miejscach w Buczy.
Ciała jednej grupy składającej się z dziewięciu osób – wszyscy w cywilnych ubraniach – leżały porozrzucane na ziemi w pobliżu miejsca, które według lokalnych mieszkańców było wykorzystywane jako baza przez siły rosyjskie.
Wygląda na to, że ofiary zostały zabite z bliskiej odległości.
W sumie, ukraińskie władze poinformowały, że w obwodzie kijowskim, który do zeszłego tygodnia był kontrolowany przez siły rosyjskie, znaleziono ciała co najmniej 410 cywilów.
Dziękuję, wszystko jest, kupiliśmy wszystko zgodnie z listą.
Powiedziano im: nie ma Kijowa. Jak okupanci nikczemnie deportowali Ukraińców do Rosji i na Białoruś
Rosyjskiej inwazji na Ukrainę towarzyszą rzeczy straszne: kradzieże, gwałty, morderstwa, tortury.
Na tej liście jest jeszcze jedna rzecz, o której obecnie jest znacznie mniej informacji – deportacja miejscowej ludności na terytorium wroga.
Od mniej więcej połowy marca rosyjscy okupanci „ewakuują” Ukraińców z czasowo okupowanych osiedli na swoje terytorium i na terytorium Białorusi, które samozwańczy prezydent Łukaszenka przekazał rosyjskiemu poligonowi wojskowemu.
„Ukraińska Prawda” odszukała deportowanych Ukraińców i ich bliskich, aby zapytać, jak przebiega ta „ewakuacja” i czy są po niej możliwości powrotu na Ukrainę.
Bohaterowie tego tekstu zgodzili się na dobrowolną, przymusową ewakuację poza Ukrainę pod presją psychiczną i z powodu beznadziejności sytuacji.
Na szczęście żyją i są w kontakcie z bliskimi.
Jednakże, według oświadczeń władz ukraińskich wielu obywateli zostało deportowanych do Rosji i na Białoruś pod ścisłym przymusem.
W Melitopolu Rosjanie porwali personel szpitala położniczego nr 2, zabrali dzieci bez rodziców, w tym 12-letnią Myrosławę, córkę byłego mistrza Ukrainy w pływaniu Josypa Zachepińskiego.
Rodzina Oleksandra, Maryny i ich 10-letniej córki Valyi przeniosła się do Gostomela na kilka miesięcy przed wojną.
Oleksandr dostał pracę na lotnisku Antonow, oddalonym o 2,5 km od wsi.
Rodzina osiedliła się na terenie miasta wojskowego, mimo że byli cywilami.
Jak prawdziwi plastunowie, Denys i Marina spakowali swoje apteczki zawczasu, ale nie zdążyli ewakuować się rankiem 24 lutego.
Nie mieli własnego samochodu, a autobusy podmiejskie już nikogo nie zabierały.
Około godziny 12:00, 24 lutego zobaczyli helikoptery z łacińską literą V, a następnie pierwsze pociski.
Jeden z nich uderzył w dom sąsiadów.
Potem rodzina zeszła do piwnicy i przebywała tam przez trzy długie tygodnie, aż do 17 marca, aż rosyjskie wojsko wywiozło ich na Białoruś.
W sumie, w ich piwnicy ukrywało się około 40 osób.
Nie wszyscy zdecydowali się pojechać.
„24 lutego o godzinie 6 wieczorem do wejścia podeszły osoby, które nie mówiły ani po rosyjsku, ani po ukraińsku. Spytali ,,Czy jest tu ktoś?''. Powiedziałem, że tak. ,,Wychodzić!''.
Przeszukali mnie, wypytywali, kto jest w piwnicy, czy nie ma tu żadnej broni.
Wszystkich mężczyzn zapytano, czy służyli w wojsku.
Kobietom powiedziano: „Przybyliśmy z rozkazu Ramzana Kadyrova, aby was chronić”.
To była czeczeńska prewencyjna policja, nawet nie żołnierze, młodzi ludzie w wieku 25-35 lat.
Powiedzieli: „Ukraińcy pomogli nam w wojnie, Saszko Belyy (dowódca oddziału nacjonalistycznego ruchu UNA-UNSO „Viking”, który walczył po stronie Czeczenów w pierwszej wojnie rosyjsko-czeczeńskiej – przypomnienie redakcji), teraz przybyliśmy wam z pomocą”.
Trzeciego dnia zapytali, czego nam brakuje.
Powiedzieliśmy, że wody, był z nią duży problem.
Rozbili sklep, wywieźli stamtąd towar pod pretekstem, że „Rosjanie i tak go wezmą” i dali nam 6 butelek.
W Internecie jest też wideo, w którym dzieci dziękują Kadyrowowi za jedzenie.
Oznacza to, że po splądrowaniu sklepu przynieśli kiełbasę i powiedzieli: „Rozumiemy, że to złe, ale naprawdę potrzebujemy wideo dla Ramzana Achmatowicza”.
Nikt tak naprawdę nie chciał rozmawiać, ale zrobili piękne cięcie.
Tam nasze dziecko mówi: „Macie 7 dni na zwrot naszych telefonów” – śmiali się.
Stale też oddzielali się od Rosjan.
Mówili, jak dobrze, że przyjechali, bo nie chcą wojny, popierają Ukraińców i ogólnie są dobrzy: „Putin to drań, Kadyrow też, ale nic nie możemy zrobić, bo są tam nasze rodziny”.
I przeważnie nie walczyli, tylko rabowali i plądrowali sklepy.
Przywieźli kurczaki, przywiązali wstążkę św. Jerzego do jednej nogi, a białą taśmę klejącą do drugiej i nazwali ją „milicją”.
Przyjechali na Ukrainę zupełnie nieprzygotowani.
Nie wiem, jak działała ich inteligencja... Kiedy ich pobito w Buczy, tak że nawet nie zabrali zabitych, pytali nas: "Macie artylerię?"
Poza tym, my mieliśmy zjednoczone drużyny - Czeczeni się nie znali, w pierwszych dniach prosili o hasła, żeby dowiedzieć się, czy jesteśmy ,,przyjacielem'' czy ,,wrogiem''.
Byli z nami do 13 marca, po czym przybyła rosyjska policja prewencyjna, a następnie desant z Omska.
Między domami umieścili 30-40 sztuk sprzętu – nasi cały czas w niego uderzali z „Bayraktarów”.
Ale przyszli i powiedzieli nam, że AFU już nie istnieje, ale jest Azow, a według nich na Ukrainie jest 100 tysięcy Azowów.
Od początku marca promowana jest narracja, że „Kijów już się poddał”.
Kiedyś przyszedł do nas Rosjanin – albo oficer powietrznodesantowy, albo przedstawiciel FSS – i powiedział, że będzie ewakuacja.
A my słuchaliśmy radia – informowali o Buczy, Gostomelu, myśleliśmy, może nam też dali „zielony korytarz”.
Od samego początku dawaliśmy Czeczenom nasze listy, obiecali skontaktować się z ukraińskim dowództwem.
Ale mówili nam: „Zostaniecie przewiezieni na Białoruś, a potem być może do Rostowa”.
Mówimy, że nie chcemy jechać ani tam, ani tam.
Na co odpowiedzieli: „Więc zlituj się nad psychiką swoich dzieci!”
Jak to działało: wepchnęli nas do piwnicy i zaczęli strzelać spod domu – albo Gradami, albo moździerzami.
A potem to odleciało z powrotem... Sąsiednie domy po prostu spłonęły, niektóre się zawaliły.
Nasz dom został bezpośrednio trafiony w trzecie piętro.
Później zgodzili się wywieźć nas tylko na Białoruś, obiecując oddać w ręce straży granicznej i Czerwonego Krzyża.
Niektórzy nie poszli, mówiąc, że to dla zdrajców ojczyzny – mówili: „tam was rozstrzelają, sprzedadzą na organy”.
Jechaliśmy przez Czarnobyl, po obu stronach drogi leżały popioły, zepsuty sprzęt, choć Białorusini mówili, że Rosjanie od razu zabierają sprzęt.
Dużo kaponierów, zakopanego sprzętu i żołnierzy.
Na białoruskim przejściu "Komar" przeszliśmy prowizoryczną kontrolę, wiele osób było w ogóle bez dokumentów, bo zostały spalone.
Zakwaterowano nas w namiotach Czerwonego Krzyża i dano nam herbatę.
I wtedy słyszymy strzały! Wystrzelono pocisk i widać ślad – to „Iskander” trafił w Kijów.
Chociaż ci z Białoruskiego Czerwonego Krzyża mówili: „Nie, to lecące samoloty, zawracające na granicy”.
Ale my jesteśmy z lotnictwa, mamy wykształcenie, rozumiemy, co to jest.
Następnie wsadzono nas do autobusu i zawieziono do sanatorium „Chonky” blisko Gomel.
Przyszedł jego menadżer Wenger Wasyl Stiepanowicz i powiedział: „Tutaj, jestem chochołem, pochodzę z Czernihowa.
Ale rozumiem, że Putin i Łukaszenka nie spoczną, dopóki ci wasi złodzieje nie będą wykończeni.
Biedni ludzie cierpią!
A nasz Łukaszenka jest taki dobry!
Jak mówi, tak będzie”.
Zaproponowali, że udzielą wywiadu białoruskim dziennikarzom, ale nikt nie chciał.
Administracja sanatorium powiedziała nam: „Ale wy już jesteście zdrajcami!”
A ludzie z Czerwonego Krzyża i przedstawicielstwa ONZ (tak ich przynajmniej nazywano) rozsiewają dezinformację, że mężczyźni nie mogą jechać do Polski.
Wielu w to uwierzyło i bało się wyjeżdżać z Białorusi.
Ale my i tak zdecydowaliśmy się na wyjazd, mimo że mieliśmy problem z dokumentami – moja córka nie miała zagranicznego paszportu.
Mieliśmy go otrzymać w poniedziałek, a wojna zaczęła się w czwartek.
Konsulat ukraiński nam nie pomógł, a na dworcu kolejowym w Mińsku powiedzieli nam, że bez paszportów nikt nikogo nie zabierze do autobusu.
Tu powiem, że dużo nam pomogli białoruscy wolontariusze.
Zostaliśmy zakwaterowani w Mińsku i eskortowani.
W sanatorium nie trzymano nas na siłę.
Przedstawiciel do spraw migracji powiedział naszej drugiej grupie, że można tu mieszkać maksymalnie półtora tygodnia, bo Białoruś to nie Europa, nie ma tu żadnych opłat.
Znaleźliśmy krajowego przewoźnika, który zgłosił się na ochotnika do przewiezienia nas do Warszawy.
Jadąc w pobliżu Mozyrza (około 50 kilometrów od granicy z Ukrainą – przypomnienie redakcji) widzieliśmy nad Ukrainą wystrzelenie rakiety balistycznej: rakieta najpierw startuje, pięknie się świeci, a potem gaśnie.
Osoby, które wsiadały do autobusu w Mozyrzu, opowiadały, że Rosjanie cały czas strzelali z tamtejszych poligonów.
Ale mogę powiedzieć, że Białorusini absolutnie nie chcą walczyć.
Generałowie odchodzą z wojska.
Jedna kobieta powiedziała nam, że złamałaby coś swojemu synowi, gdyby został powołany do wojska.
Jednakże, północna część Białorusi, gdzie leży Mińsk, w ogóle w to nie wierzy.
Mówią: "Kłamiecie, my jesteśmy ludem pokojowym."
Nie dostrzegają, że ich poligon jest wykorzystywany do ostrzału Ukrainy.
Przyjaciele czekali na nas w Polsce i zabrali nas do Estonii.
Teraz przechodzimy rejestrację, decydujemy co dalej.
W Estonii jest prawdopodobnie tyle flag ukraińskich, ile jest flag estońskich”.
Marina mieszkała na terenie wojskowego miasteczka w Gostomelu wraz z rodziną swojego brata – żoną i dwójką dzieci w wieku 18 i 22 lat.
Rankiem 24 lutego zadzwoniła do bratanków i poprosiła ich o zabranie najpotrzebniejszych rzeczy i dokumentów.
Wieczorem udali się na noc do piwnicy sąsiedniego domu.
Sama Marina nie mogła wrócić do domu i w zasadzie nie będzie już mogła – domu już tam nie ma.
Nikt tak naprawdę nie wiedział nic o ewakuacji.
Może gdzieś w centrum w poniedziałek?
Dziękuję, mamy wszystko. I zawsze jesteś tu mile widziany jako gość!
Dziękuję za aranżację, ćmy są piękne
A to małe mieszkanie nie ma Wi-Fi, głównie znam odpowiedzi na wszystkie pytania, ale teraz nie wiem co robić? A dzieci mają zajęcia online od poniedziałku, ale nie ma internetu.
Czyli będę mieszkać z dwiema kobietami z Ukrainy i ich dziećmi? A może jest to rodzina, która jest gotowa nas schronić?
Koran mówi: „Ani jeden liść nie spadnie bez Jego wiedzy”.
Nasze dzieci uczą się online, ja jestem z zawodu sprzedawcą i kucharką, ale mogę też pracować w polu i jako sprzątaczka, czyli pracownik fizyczny. Maryana jest specjalistką od przedłużania rzęs, może pracować w domu, a przyjaciel Maryany nie ma zawodu, jest złotą rączką.
Czy możecie uzgodnić najlepszy sposób na zrobienie tego?
1 kwietnia, burmistrz Buczy Anatolij Fedoruk ogłosił dobrą wiadomość – 31 marca ukraińskie wojsko wyzwoliło miasto spod rosyjskich najeźdźców.
Następnego dnia okupanci zostali wyrzuceni z całego obwodu kijowskiego.
Jednakże, radość, jaką powinni w tym momencie odczuwać Ukraińcy, została przyćmiona przez przerażenie i nienawiść, ponieważ w tym samym czasie wyszło na jaw, że w samej Buczy Rosjanie rozstrzelali co najmniej 280 cywilów.
Zostali zabici na ulicy, niektórzy mieli związane ręce i zostali postrzeleni w tył głowy, część zabitych była nieletnia.
Olha Suchenko, sołtys wsi Motyżyn, jej mąż Igor i syn Oleksandr, którzy zostali porwani 23 marca, zostali znalezieni martwi i mieli ślady tortur.