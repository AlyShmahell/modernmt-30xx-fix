Gratulacje
Dziękuję
Cześć
Dzień dobry
Dobry dzień
Dobry wieczór
Jak się masz?
Do widzenia
Proszę
Jak masz na imię?
Moje imię...
Miło mi cię poznać
Jak się masz?
Bardzo dobrze, dziękuję
Wow
Do zobaczenia wkrótce
Z wyrazami szacunku
Do zobaczenia jutro
Przepraszam
Przepraszam
W porządku
Oczywiście
Bardzo dobrze
Doskonale
Cicho
Bądź zdrów
na zdrowie
Były zdrowe
Spotkajmy się
Czy mówisz po ukraińsku?
nie rozumiem
Nie mówię po ukraińsku
Język jest odczuwalny
Język odtwarza myśli
Doskonale
Fantastycznie
Super
Wow
Może
Zróbmy to
Czy masz jakieś inne pytania?
Nie jestem pewny
Nie wiem
Nie jestem pewien swojej odpowiedzi
Miło mi cię poznać
Jak się masz
Jak się masz?
Co nowego?
Co robisz?
Co robisz w pracy?
Pracuję w...
jestem nauczycielem
jestem studentem
Jestem gospodynią domową
jestem pisarzem
jestem muzykiem
jestem piosenkarzem
jestem aktorem
jestem mistrzem
Jestem rzemieślnikiem
Jestem programistą
jestem biznesmenem
jestem lekarzem
jestem inżynierem
jestem prawnikiem
Mam doświadczenie w...
Mogę...
Lubię...
Nie lubię...
Chciałbym...