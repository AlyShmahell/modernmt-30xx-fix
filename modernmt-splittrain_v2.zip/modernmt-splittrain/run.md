## Remove old image (IF NECESSARY)
```
docker rmi test
```
## Remove new image (IF NECESSARY)
```
docker build -t test . --build-arg MMT_VERSION=v4.9.5
```
## Start image with lots of ram (as much as possible)
```
docker run --rm --name kwolk --cpus=4 --memory=64g -it -v ./host:/opt/mmt/host --gpus all test:latest bash
```
## Train the model
```
python3 host/scripts/trainer.py --datadir host/data --saveto host/engines --language_pair pl:uk --model_name PLEN_SUBCCALCC100k --train_steps 100000 --unifiedmemory -y
```
## Check on memory usage on demand (second terminal windows)
```
awk '$3=="kB"{$2=$2/1024/1024;$3="GB"} 1' /proc/meminfo | column -t | grep MemAvailable && nvidia-smi | grep MiB
```
## Check on memory usage every 10 seconds (second terminal windows)
```
while sleep 10; do awk '$3=="kB"{$2=$2/1024/1024;$3="GB"} 1' /proc/meminfo | column -t | grep MemAvailable && nvidia-smi | grep MiB; done
```